/**
 * Search – Hebrew / English / Latin, tolerant to niqqud, maqaf, final letters, prefixes and typos.
 * Two levels:
 *   1. entity search  ("בייספס", "Biceps brachii", "Squat", "מרפק")
 *   2. query search   ("כל השרירים שעושים כפיפת ברך", "שרירים שמתחברים לפמור", "שרירי הכתף" …)
 */
import { data, MUSCLE_GROUPS, REGION_NAMES, type Entity, type EntityKind, type Id, type Muscle, type Role } from '@/data';

const FINALS: Record<string, string> = { 'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ' };

export function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[֑-ׇ]/g, '') // niqqud & cantillation
    .replace(/[־\-–—_/.,:;!?()"'׳״`]/g, ' ')
    .replace(/[ךםןףץ]/g, (c) => FINALS[c])
    .replace(/\s+/g, ' ')
    .trim();
}

const HEB_PREFIXES = ['וה', 'שה', 'מה', 'לה', 'בה', 'כה', 'ה', 'ב', 'ל', 'ו', 'ש', 'מ', 'כ'];
function variants(token: string): string[] {
  const out = [token];
  if (/^[א-ת]/.test(token)) for (const p of HEB_PREFIXES) if (token.startsWith(p) && token.length - p.length >= 2) out.push(token.slice(p.length));
  return out;
}

function lev(a: string, b: string, max: number): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const dp = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    let rowMin = dp[0];
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
      rowMin = Math.min(rowMin, dp[j]);
    }
    if (rowMin > max) return max + 1;
  }
  return dp[b.length];
}

export type SearchKind = EntityKind | 'unlisted';

export interface SearchHit {
  kind: SearchKind;
  id: Id;
  title: string;
  subtitle: string;
  score: number;
}

interface IndexEntry {
  kind: SearchKind;
  id: Id;
  title: string;
  subtitle: string;
  terms: string[];
}

const KIND_LABEL: Record<EntityKind, string> = {
  muscle: 'שריר', bone: 'עצם', nerve: 'עצב', vessel: 'כלי דם', ligament: 'רצועה', joint: 'מפרק', movement: 'תנועה', exercise: 'תרגיל',
};

let index: IndexEntry[] | null = null;
function buildIndex(): IndexEntry[] {
  const all: Entity[] = [...data.muscles, ...data.movements, ...data.exercises, ...data.joints, ...data.bones, ...data.nerves, ...data.vessels, ...data.ligaments];
  return all.map((e) => ({
    kind: e.kind,
    id: e.id,
    title: e.hebrewName,
    subtitle: `${KIND_LABEL[e.kind]} · ${e.kind === 'exercise' || e.kind === 'movement' ? e.englishName : e.latinName}`,
    terms: [e.hebrewName, e.englishName, e.latinName, ...(e.aliases ?? [])].map(normalize).filter(Boolean),
  }));
}

/**
 * Structures that exist in the 3D model but have no data record yet (e.g. "serratus anterior").
 * They become searchable by their model name; `id` is the model reference.
 */
const UNLISTED_LABEL: Record<string, string> = { muscle: 'שריר במודל', bone: 'עצם במודל', vessel: 'כלי דם במודל', ligament: 'רקמת חיבור במודל' };
export function registerModelStructures(items: { ref: string; label: string; kind: string }[]) {
  index ??= buildIndex();
  const seen = new Set(index.filter((e) => e.kind === 'unlisted').map((e) => e.id));
  for (const it of items) {
    if (seen.has(it.ref)) continue;
    seen.add(it.ref);
    index.push({ kind: 'unlisted', id: it.ref, title: it.label, subtitle: `${UNLISTED_LABEL[it.kind] ?? 'מבנה במודל'} · אין עדיין מידע מפורט`, terms: [normalize(it.label)] });
  }
}

export function searchEntities(q: string, limit = 20, kinds?: EntityKind[]): SearchHit[] {
  index ??= buildIndex();
  const nq = normalize(q);
  if (!nq) return [];
  const qTokens = nq.split(' ').flatMap(variants);
  const hits: SearchHit[] = [];
  for (const e of index) {
    if (kinds && (e.kind === 'unlisted' || !kinds.includes(e.kind))) continue;
    let score = 0;
    for (const t of e.terms) {
      if (t === nq) score = Math.max(score, 100);
      else if (t.startsWith(nq)) score = Math.max(score, 85);
      else if (t.includes(nq)) score = Math.max(score, 65);
      else {
        const words = t.split(' ');
        const all = nq.split(' ').every((qt) => variants(qt).some((v) => words.some((w) => w.startsWith(v))));
        if (all) score = Math.max(score, 55);
        else if (nq.length >= 4) {
          const max = nq.length >= 7 ? 2 : 1;
          if (words.some((w) => lev(w, nq, max) <= max) || lev(t, nq, max) <= max) score = Math.max(score, 35);
          else if (qTokens.some((v) => v.length >= 3 && words.some((w) => w.startsWith(v)))) score = Math.max(score, 20);
        }
      }
    }
    if (score) hits.push({ kind: e.kind, id: e.id, title: e.title, subtitle: e.subtitle, score: score + kindBoost(e.kind) });
  }
  return hits.sort((a, b) => b.score - a.score).slice(0, limit);
}

const kindBoost = (k: SearchKind) => ({ unlisted: -2,  muscle: 3, movement: 2, exercise: 2, joint: 1, bone: 1, nerve: 0, vessel: 0, ligament: 0 })[k];

/* ───────────── advanced queries ───────────── */

export interface QueryGroup {
  label: string;
  role?: Role;
  muscles: { id: Id; note?: string }[];
}

export interface QueryResult {
  title: string;
  groups: QueryGroup[];
  /** Entity the query resolved to (e.g. the movement) so the UI can offer "play". */
  source?: { kind: EntityKind; id: Id };
}

const STOP = new Set(['כל', 'השרירים', 'שרירים', 'שריר', 'שרירי', 'השריר', 'שעושים', 'שעושה', 'עושים', 'שמבצעים', 'מבצעים', 'שמבצע', 'שמתחברים', 'מתחברים', 'שמתחבר', 'שעובדים', 'עובדים', 'שעובד', 'בתנועת', 'משתתפים', 'שמשתתפים', 'של', 'את', 'ב', 'ל', 'אל', 'muscles', 'muscle', 'all', 'that', 'the', 'in', 'of', 'to', 'attach', 'attached', 'which', 'do', 'perform', 'working', 'work'].map(normalize));
const MUSCLE_WORDS = ['שריר', 'muscle'];

const ROLE_LABEL: Record<Role, string> = { agonist: '🔴 אגוניסטים', synergist: '🩷 מסייעים', stabilizer: '🟣 מייצבים', antagonist: '🔵 אנטגוניסטים' };

function rolesToGroups(roles: { muscleId: Id; role: Role; note?: string }[]): QueryGroup[] {
  const g = data.groupRoles(roles as never);
  return (Object.keys(g) as Role[])
    .filter((r) => g[r].length)
    .map((r) => ({ label: ROLE_LABEL[r], role: r, muscles: g[r].map((x) => ({ id: x.muscleId, note: x.note })) }));
}

/** Returns a structured result when the query is a question about *sets of muscles*. */
export function advancedQuery(q: string): QueryResult | null {
  const nq = normalize(q);
  const wantsMuscles = MUSCLE_WORDS.some((w) => nq.includes(w));
  const rest = nq.split(' ').filter((t) => !STOP.has(t)).join(' ');
  if (!rest) return null;

  const hits = searchEntities(rest, 5, ['movement', 'exercise', 'bone', 'joint', 'nerve']);
  // Regions / groups ("שרירי הכתף", "המסטרינג")
  const regionHit = Object.entries(REGION_NAMES).find(([, he]) => variants(rest).some((v) => normalize(he) === v || normalize(he).startsWith(v + ' ')));
  const groupHit = Object.entries(MUSCLE_GROUPS).find(([, g]) => [g.hebrewName, g.englishName, ...g.aliases].map(normalize).some((t) => variants(rest).includes(t)));

  if (groupHit) {
    const ms = data.musclesInGroup(groupHit[0]);
    return { title: groupHit[1].hebrewName, groups: [{ label: `${ms.length} שרירים`, muscles: ms.map((m) => ({ id: m.id })) }] };
  }

  // Only questions about sets of muscles become queries; plain names stay entity searches.
  if (!wantsMuscles && !/^(כל|all)\b/.test(nq)) return null;
  const top = hits[0];

  if (top && top.score >= 50) {
    switch (top.kind) {
      case 'movement': {
        const m = data.movement(top.id)!;
        return { title: `שרירים ב${m.hebrewName}`, groups: rolesToGroups(m.roles), source: { kind: 'movement', id: m.id } };
      }
      case 'exercise': {
        const e = data.exercise(top.id)!;
        return { title: `שרירים ב־${e.englishName}`, groups: rolesToGroups(e.roles), source: { kind: 'exercise', id: e.id } };
      }
      case 'bone': {
        const b = data.bone(top.id)!;
        const att = data.musclesForBone(b.id);
        const origin = att.filter((a) => a.via.includes('origin')).map((a) => ({ id: a.muscle.id }));
        const ins = att.filter((a) => a.via.includes('insertion')).map((a) => ({ id: a.muscle.id }));
        return { title: `שרירים המתחברים ל${b.hebrewName}`, groups: [{ label: 'מוצא בעצם', muscles: origin }, { label: 'אחז בעצם', muscles: ins }].filter((g) => g.muscles.length), source: { kind: 'bone', id: b.id } };
      }
      case 'joint': {
        const j = data.joint(top.id)!;
        const ms = data.muscles.filter((m) => m.relatedJoints.includes(j.id));
        const byRegion = regionHit ? ms.filter((m: Muscle) => m.region === regionHit[0]) : [];
        const groups: QueryGroup[] = [{ label: `פועלים על ${j.hebrewName}`, muscles: ms.map((m) => ({ id: m.id })) }];
        if (byRegion.length && byRegion.length !== ms.length) groups.push({ label: `ממוקמים באזור ה${REGION_NAMES[regionHit![0]]}`, muscles: byRegion.map((m) => ({ id: m.id })) });
        return { title: `שרירי ה${j.hebrewName.replace(/^מפרק(י)? ה?/, '')}`, groups, source: { kind: 'joint', id: j.id } };
      }
      case 'nerve': {
        const n = data.nerve(top.id)!;
        return { title: `שרירים שמעוצבבים ע"י ${n.hebrewName}`, groups: [{ label: n.roots, muscles: data.musclesForNerve(n.id).map((m) => ({ id: m.id })) }], source: { kind: 'nerve', id: n.id } };
      }
    }
  }
  if (regionHit) {
    const ms = data.muscles.filter((m) => m.region === regionHit[0]);
    if (ms.length) return { title: `שרירי ה${REGION_NAMES[regionHit[0]]}`, groups: [{ label: `${ms.length} שרירים`, muscles: ms.map((m) => ({ id: m.id })) }] };
  }
  return null;
}
