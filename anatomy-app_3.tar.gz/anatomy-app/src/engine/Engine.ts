/**
 * Engine – owns the WebGL renderer, scene, camera, touch controls and the loaded AnatomyAsset.
 * It knows nothing about React or about anatomy facts; it is driven through a small API:
 *   applyVisualState · setPose · setView · focusOn · setSection · pick events · frame listeners.
 *
 * Performance (mobile first):
 *  - render-on-demand: a frame is drawn only when something changed (camera, pose, style);
 *  - pixel ratio capped (2, or 1 in low-power mode); no shadows; one light rig;
 *  - hidden layers are `visible=false` (skipped entirely by the renderer and the raycaster);
 *  - deformable geometry updated only when the pose changes.
 */
import {
  Color, DoubleSide, FrontSide, HemisphereLight, DirectionalLight, MathUtils, Mesh, MeshBasicMaterial,
  MeshStandardMaterial, PerspectiveCamera, Plane, PlaneGeometry, Raycaster, Scene, Vector2, Vector3, WebGLRenderer,
  CircleGeometry, Box3,
} from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ACESFilmicToneMapping, PMREMGenerator } from 'three';
import { TOUCH, MOUSE } from 'three';
import type { Clip, Pose } from '@/data';
import { instanceKey, type AnatomyAsset, type AnatomyAssetProvider, type AnatomyPart } from '@/assets';
import { applyPose, type PoseOptions } from './PoseDriver';
import type { CameraState, SectionState, ViewPreset, VisualState } from './visualState';

export interface PickResult {
  part: AnatomyPart;
  key: string; // instance key
  point: Vector3;
}

type FrameListener = (dt: number) => void;

const SELECT_EMISSIVE = new Color(0xffc24a);
const HIGHLIGHT_EMISSIVE = new Color(0x7fd1ff);
const DIM_COLOR = new Color(0x6e6466);
const _c = new Color();

const VIEWS: Record<ViewPreset, [number, number, number]> = {
  front: [0, 0, 1], back: [0, 0, -1], left: [1, 0, 0], right: [-1, 0, 0],
  top: [0, 1, 0.001], bottom: [0, -1, 0.001], threeQuarter: [0.62, 0.32, 0.72],
};

export class Engine {
  readonly renderer: WebGLRenderer;
  readonly scene = new Scene();
  readonly camera = new PerspectiveCamera(38, 1, 0.03, 50);
  readonly controls: OrbitControls;
  asset: AnatomyAsset | null = null;

  private needsRender = true;
  private raf = 0;
  private lastT = performance.now();
  private frameListeners = new Set<FrameListener>();
  private pickListeners = new Set<(r: PickResult | null, double: boolean) => void>();
  private raycaster = new Raycaster();
  private camAnim: { from: CameraState; to: CameraState; t: number; dur: number } | null = null;
  private sectionPlane = new Plane(new Vector3(-1, 0, 0), 0);
  private sectionIndicator: Mesh;
  private section: SectionState = { enabled: false, axis: 'sagittal', position: 0 };
  private resizeObs: ResizeObserver;
  private lastVS: VisualState | null = null;
  private pickableMeshes: Mesh[] = [];
  private lowPower = false;
  private occl = { top: 0, bottom: 0 };
  /** Post-processing: ambient occlusion darkens creases between muscles, giving real depth. */
  private composer: EffectComposer;
  private aoPass: GTAOPass;
  private aoWanted = true;

  constructor(private container: HTMLElement) {
    this.renderer = new WebGLRenderer({ antialias: window.devicePixelRatio < 2, powerPreference: 'high-performance', alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.localClippingEnabled = true;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.touchAction = 'none';

    this.renderer.toneMapping = ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.9;
    this.scene.background = new Color(0x0b0f14);
    // Image-based lighting from a neutral studio room (generated in code, no external file).
    const pmrem = new PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.38;
    pmrem.dispose();
    this.scene.add(new HemisphereLight(0xe8eeff, 0x241c18, 0.45));
    const key = new DirectionalLight(0xfff4ea, 2.0);
    key.position.set(1.6, 3.2, 2.4);
    const fill = new DirectionalLight(0xd6e4ff, 0.55);
    fill.position.set(-2.2, 1.2, 1.5);
    const rim = new DirectionalLight(0x9ec5ff, 1.1);
    rim.position.set(-1.5, 2.2, -2.8);
    this.scene.add(key, fill, rim);

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.aoPass = new GTAOPass(this.scene, this.camera, 1, 1);
    this.aoPass.updateGtaoMaterial({ radius: 0.06, distanceExponent: 1.2, thickness: 0.08, scale: 1.0, samples: 12 });
    this.aoPass.blendIntensity = 0.85;
    this.composer.addPass(this.aoPass);
    this.composer.addPass(new OutputPass());
    const floor = new Mesh(new CircleGeometry(0.75, 48), new MeshBasicMaterial({ color: 0x7f8ea3, transparent: true, opacity: 0.08, depthWrite: false }));
    floor.rotation.x = -Math.PI / 2;
    floor.name = 'floor';
    this.scene.add(floor);

    this.sectionIndicator = new Mesh(
      new PlaneGeometry(1, 1),
      new MeshBasicMaterial({ color: 0x4fc3f7, transparent: true, opacity: 0.12, side: DoubleSide, depthWrite: false }),
    );
    this.sectionIndicator.visible = false;
    this.scene.add(this.sectionIndicator);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.12;
    this.controls.rotateSpeed = 0.9;
    this.controls.zoomSpeed = 1.1;
    this.controls.panSpeed = 0.9;
    this.controls.screenSpacePanning = true;
    this.controls.minDistance = 0.35;
    this.controls.maxDistance = 7;
    this.controls.touches = { ONE: TOUCH.ROTATE, TWO: TOUCH.DOLLY_PAN };
    this.controls.mouseButtons = { LEFT: MOUSE.ROTATE, MIDDLE: MOUSE.DOLLY, RIGHT: MOUSE.PAN };
    this.controls.addEventListener('change', () => this.invalidate());
    this.controls.addEventListener('start', () => (this.camAnim = null));

    this.setView('front', false);
    this.installTapHandling();
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(container);
    this.resize();
    this.loop();
  }

  /* ───────────── lifecycle ───────────── */

  async load(provider: AnatomyAssetProvider, onProgress?: (f: number) => void) {
    const asset = await provider.load(onProgress);
    this.asset = asset;
    this.scene.add(asset.scene);
    this.pickableMeshes = asset.parts.filter((p) => p.pickable).flatMap((p) => p.meshes);
    if (this.lastVS) this.applyVisualState(this.lastVS);
    this.invalidate();
    return asset;
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.resizeObs.disconnect();
    this.controls.dispose();
    this.asset?.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  invalidate() {
    this.needsRender = true;
  }

  /** Ambient occlusion on/off (off in low-power mode and while an anatomical section is shown). */
  setAmbientOcclusion(on: boolean) {
    this.aoWanted = on;
    this.updateAo();
  }

  private updateAo() {
    this.aoPass.enabled = this.aoWanted && !this.lowPower && !this.section.enabled;
    this.invalidate();
  }

  setLowPower(low: boolean) {
    this.lowPower = low;
    this.updateAo();
    this.renderer.setPixelRatio(low ? 1 : Math.min(window.devicePixelRatio, 2));
    this.resize();
  }

  setBackground(hex: number) {
    (this.scene.background as Color).setHex(hex);
    this.invalidate();
  }

  onFrame(fn: FrameListener) {
    this.frameListeners.add(fn);
    return () => this.frameListeners.delete(fn);
  }

  onPick(fn: (r: PickResult | null, double: boolean) => void) {
    this.pickListeners.add(fn);
    return () => this.pickListeners.delete(fn);
  }

  private resize() {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.composer.setPixelRatio(this.renderer.getPixelRatio());
    this.composer.setSize(w, h);
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.camera.aspect = w / h;
    this.applyViewOffset(w, h);
    this.invalidate();
  }

  /**
   * Tell the engine how many CSS px at the top/bottom are covered by UI (top bar, sheet, nav),
   * so the camera target is centred in the *visible* part of the canvas.
   */
  setOcclusion(top: number, bottom: number) {
    if (this.occl.top === top && this.occl.bottom === bottom) return;
    this.occl = { top, bottom };
    this.applyViewOffset(this.container.clientWidth || 1, this.container.clientHeight || 1);
    this.invalidate();
  }

  private applyViewOffset(w: number, h: number) {
    const shift = Math.max(-h * 0.35, Math.min(h * 0.35, (this.occl.bottom - this.occl.top) / 2));
    if (Math.abs(shift) < 1) this.camera.clearViewOffset();
    else this.camera.setViewOffset(w, h, 0, shift, w, h);
    this.camera.updateProjectionMatrix();
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.lastT) / 1000);
    this.lastT = now;
    for (const fn of this.frameListeners) fn(dt);
    if (this.camAnim) this.stepCameraAnim(dt);
    if (this.controls.update()) this.needsRender = true;
    if (this.needsRender) {
      this.needsRender = false;
      this.composer.render();
    }
  };

  /* ───────────── pose ───────────── */

  setPose(pose: Pose, opts?: PoseOptions) {
    if (!this.asset) return;
    applyPose(this.asset.rig, pose, opts);
    this.asset.updateDeformation();
    this.invalidate();
  }

  /* ───────────── visual state ───────────── */

  applyVisualState(vs: VisualState) {
    this.lastVS = vs;
    if (!this.asset) return;
    const has = (set: Set<string> | null, p: AnatomyPart) => !!set && (set.has(p.ref) || (!!p.side && set.has(instanceKey(p.ref, p.side))));

    for (const p of this.asset.parts) {
      const layerOn = vs.layers[p.layer] || vs.forceLayers.has(p.layer);
      const hidden = has(vs.hidden, p);
      const isolated = vs.isolate ? has(vs.isolate, p) : true;
      let visible = layerOn && !hidden;
      let opacity = p.baseOpacity;
      let ghost = false;
      if (vs.isolate) {
        if (isolated) visible = !hidden;
        else if (vs.isolateMode === 'hide' || p.kind === 'shell') visible = false;
        else if (visible) { ghost = true; opacity = 0.07; }
      }
      const tint = vs.tints.get(p.ref);
      const selected = has(vs.selected, p);
      const highlighted = has(vs.highlight, p);

      _c.setHex(p.baseColor);
      if (tint && p.subpart !== 'tendon') {
        _c.lerp(new Color(tint.color), 0.55 + 0.45 * tint.strength);
        if (tint.opacity !== undefined && !ghost) opacity = tint.opacity;
      } else if (vs.dimUntinted && p.kind === 'muscle' && !ghost) {
        // Uninvolved muscles stay fully visible, just slightly muted so the role colours stand out.
        _c.lerp(DIM_COLOR, 0.5);
      }

      for (const m of p.meshes) {
        m.visible = visible;
        const mat = m.material as MeshStandardMaterial;
        mat.color.copy(_c);
        const transparent = opacity < 0.999;
        if (mat.transparent !== transparent) { mat.transparent = transparent; mat.needsUpdate = true; }
        mat.opacity = opacity;
        mat.depthWrite = !transparent;
        if (mat.emissive) {
          if (selected) { mat.emissive.copy(SELECT_EMISSIVE); mat.emissiveIntensity = 0.45; }
          else if (highlighted) { mat.emissive.copy(HIGHLIGHT_EMISSIVE); mat.emissiveIntensity = 0.55; }
          else if (tint && p.subpart !== 'tendon') { mat.emissive.setHex(tint.color); mat.emissiveIntensity = 0.12 + 0.28 * tint.strength; }
          else if (p.kind === 'nerve') { mat.emissive.setHex(p.baseColor); mat.emissiveIntensity = 0.15; }
          else { mat.emissive.setHex(0x000000); mat.emissiveIntensity = 0; }
        }
        m.userData.pickable = p.pickable && visible && !ghost && opacity > 0.15;
      }
    }
    this.invalidate();
  }

  /* ───────────── picking ───────────── */

  pickAt(clientX: number, clientY: number): PickResult | null {
    if (!this.asset) return null;
    const r = this.renderer.domElement.getBoundingClientRect();
    const ndc = new Vector2(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.camera);
    const candidates = this.pickableMeshes.filter((m) => m.userData.pickable && this.isVisibleInTree(m));
    const hits = this.raycaster.intersectObjects(candidates, false);
    for (const h of hits) {
      if (this.section.enabled && this.sectionPlane.distanceToPoint(h.point) < 0) continue;
      const part = this.asset.parts[h.object.userData.partIndex as number];
      if (part) return { part, key: instanceKey(part.ref, part.side), point: h.point.clone() };
    }
    return null;
  }

  private isVisibleInTree(o: { visible: boolean; parent: unknown }) {
    let n: { visible: boolean; parent: unknown } | null = o;
    while (n) { if (!n.visible) return false; n = n.parent as typeof n; }
    return true;
  }

  private installTapHandling() {
    const el = this.renderer.domElement;
    let down: { x: number; y: number; t: number; id: number } | null = null;
    let pointers = 0;
    let multi = false;
    let lastTap: { x: number; y: number; t: number } | null = null;
    el.addEventListener('pointerdown', (e) => {
      pointers++;
      if (pointers > 1) multi = true;
      if (pointers === 1) { multi = false; down = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId }; }
    });
    const end = (e: PointerEvent) => {
      pointers = Math.max(0, pointers - 1);
      if (!down || e.pointerId !== down.id || multi) { if (pointers === 0) down = null; return; }
      const dist = Math.hypot(e.clientX - down.x, e.clientY - down.y);
      const dur = performance.now() - down.t;
      down = null;
      if (dist > 9 || dur > 400) return;
      const now = performance.now();
      const isDouble = !!lastTap && now - lastTap.t < 320 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 30;
      lastTap = isDouble ? null : { x: e.clientX, y: e.clientY, t: now };
      const res = this.pickAt(e.clientX, e.clientY);
      for (const fn of this.pickListeners) fn(res, isDouble);
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', (e) => { pointers = Math.max(0, pointers - 1); if (down?.id === e.pointerId) down = null; });
  }

  /* ───────────── camera ───────────── */

  getCameraState(): CameraState {
    return { position: this.camera.position.toArray() as CameraState['position'], target: this.controls.target.toArray() as CameraState['target'] };
  }

  setCameraState(s: CameraState, animate = true) {
    if (!animate) {
      this.camera.position.fromArray(s.position);
      this.controls.target.fromArray(s.target);
      this.controls.update();
      this.invalidate();
      return;
    }
    this.camAnim = { from: this.getCameraState(), to: s, t: 0, dur: 0.55 };
  }

  private bodyCenter() {
    const c = new Vector3(0, 0.95, 0);
    if (this.asset) this.asset.rig.segments.torso.getWorldPosition(c);
    return c;
  }

  setView(v: ViewPreset, animate = true, distance = 3.4, target?: Vector3) {
    const t = target ?? this.bodyCenter();
    const dir = new Vector3(...VIEWS[v]).normalize();
    const pos = t.clone().addScaledVector(dir, distance);
    this.setCameraState({ position: pos.toArray() as CameraState['position'], target: t.toArray() as CameraState['target'] }, animate);
  }

  resetCamera() {
    if (this.asset) this.frameBox(this.rigBounds(), new Vector3(0, 0.08, 1), 1.0);
    else this.setView('front', true, 3.4, new Vector3(0, 0.95, 0));
  }

  /** Frame a set of structures (by ref or instance key). */
  /**
   * Frame structures. mode 'keep' keeps the current viewing direction; 'face' turns the camera to the
   * side of the body the structures are on (front for the biceps, back for the hamstrings, …).
   */
  focusOn(keys: string[], mode: 'keep' | 'face' = 'keep') {
    if (!this.asset || !keys.length) return;
    const box = new Box3();
    for (const p of this.asset.parts) {
      if (!(keys.includes(p.ref) || (p.side && keys.includes(instanceKey(p.ref, p.side))))) continue;
      for (const m of p.meshes) box.expandByObject(m);
    }
    if (box.isEmpty()) return;
    let dir: Vector3;
    if (mode === 'keep') dir = this.camera.position.clone().sub(this.controls.target).normalize();
    else {
      const c = box.getCenter(new Vector3());
      const axis = this.asset.rig.segments.torso.getWorldPosition(new Vector3());
      const h = new Vector3(c.x - axis.x, 0, c.z - axis.z);
      const bilateral = box.min.x < axis.x - 0.05 && box.max.x > axis.x + 0.05;
      if (bilateral || h.length() < 0.03) h.set(0, 0, h.z < -0.01 ? -1 : 1);
      dir = h.normalize().add(new Vector3(0, 0.15, 0));
    }
    this.frameBox(box, dir, 1.9);
  }

  /** +1 if the structures lie mostly on the front of the body, −1 if mostly at the back (rest geometry). */
  sideOf(keys: string[]): number {
    if (!this.asset || !keys.length) return 1;
    const axisZ = this.asset.rig.segments.torso.getWorldPosition(new Vector3()).z;
    let sum = 0;
    for (const p of this.asset.parts) {
      if (!keys.includes(p.ref)) continue;
      for (const m of p.meshes) {
        m.geometry.computeBoundingBox();
        const bb = m.geometry.boundingBox!;
        const dz = (bb.min.z + bb.max.z) / 2 - axisZ;
        if (Math.abs(dz) > 0.02) sum += Math.sign(dz); // count structures, so one large muscle doesn't outvote several
      }
    }
    return sum < 0 ? -1 : 1;
  }

  /** Bounding box of the rig (optionally restricted to some segments) in the current pose. */
  rigBounds(segments?: string[]): Box3 {
    const box = new Box3();
    if (!this.asset) return box;
    const rig = this.asset.rig;
    rig.root.updateMatrixWorld(true);
    const v = new Vector3();
    for (const [id, o] of Object.entries(rig.segments)) {
      if (id === 'root' || (segments && !segments.includes(id))) continue;
      box.expandByPoint(o.getWorldPosition(v));
      if (id === 'head') box.expandByPoint(o.localToWorld(v.set(0, 0.24, 0)));
    }
    for (const c of rig.contacts) if (!segments || segments.includes(c.segment)) box.expandByPoint(rig.segments[c.segment].localToWorld(v.copy(c.local)));
    return box;
  }

  /** Fit a box into the visible (non-occluded) part of the canvas, looking from `dir`. */
  frameBox(box: Box3, dir: Vector3, margin = 1.15) {
    if (box.isEmpty()) return;
    const center = box.getCenter(new Vector3());
    const radius = Math.max(0.15, box.getSize(new Vector3()).length() / 2);
    const h = this.container.clientHeight || 1;
    const visibleFrac = MathUtils.clamp((h - this.occl.top - this.occl.bottom) / h, 0.3, 1);
    const vFov = MathUtils.degToRad(this.camera.fov) / 2;
    const hFov = Math.atan(Math.tan(vFov) * this.camera.aspect);
    const dist = (radius * margin) / Math.sin(Math.min(vFov * visibleFrac, hFov));
    const pos = center.clone().addScaledVector(dir.clone().normalize(), MathUtils.clamp(dist, 0.5, 6.5));
    this.setCameraState({ position: pos.toArray() as CameraState['position'], target: center.toArray() as CameraState['target'] });
  }

  focusRegion(focus: Clip['focus']) {
    const c = this.bodyCenter();
    const presets: Record<Clip['focus'], { off: [number, number, number]; dir: [number, number, number]; dist: number }> = {
      arm: { off: [0.24, 0.05, 0.05], dir: [0.8, 0.12, 0.6], dist: 1.6 },
      shoulder: { off: [0, 0.35, 0], dir: [0.55, 0.25, 0.8], dist: 2.2 },
      trunk: { off: [0, 0.1, 0], dir: [0.85, 0.15, 0.5], dist: 2.6 },
      leg: { off: [0.05, -0.45, 0], dir: [0.8, 0.12, 0.6], dist: 2.2 },
      full: { off: [0, -0.15, 0], dir: [0.6, 0.22, 0.76], dist: 3.1 },
    };
    const p = presets[focus];
    const t = c.add(new Vector3(...p.off));
    const pos = t.clone().addScaledVector(new Vector3(...p.dir).normalize(), p.dist);
    this.setCameraState({ position: pos.toArray() as CameraState['position'], target: t.toArray() as CameraState['target'] });
  }

  private stepCameraAnim(dt: number) {
    const a = this.camAnim!;
    a.t = Math.min(1, a.t + dt / a.dur);
    const k = a.t < 0.5 ? 4 * a.t ** 3 : 1 - (-2 * a.t + 2) ** 3 / 2;
    const lerp3 = (f: number[], t: number[]) => f.map((v, i) => v + (t[i] - v) * k) as [number, number, number];
    this.camera.position.fromArray(lerp3(a.from.position, a.to.position));
    this.controls.target.fromArray(lerp3(a.from.target, a.to.target));
    this.needsRender = true;
    if (a.t >= 1) this.camAnim = null;
  }

  /* ───────────── anatomical section ───────────── */

  setSection(s: SectionState) {
    this.section = s;
    this.updateAo();
    if (!this.asset) return;
    const half = { sagittal: 0.4, coronal: 0.2, transverse: 0.95 }[s.axis];
    const center = this.bodyCenter();
    const ind = this.sectionIndicator;
    ind.visible = s.enabled;
    ind.rotation.set(0, 0, 0);
    if (s.axis === 'sagittal') {
      const x = s.position * half;
      this.sectionPlane.set(new Vector3(-1, 0, 0), x); // keep x <= pos
      ind.rotation.y = Math.PI / 2; ind.scale.set(0.8, 2.1, 1); ind.position.set(x, center.y - 0.05, 0);
    } else if (s.axis === 'coronal') {
      const z = s.position * half;
      this.sectionPlane.set(new Vector3(0, 0, -1), z); // keep z <= pos (front removed)
      ind.scale.set(1.0, 2.1, 1); ind.position.set(0, center.y - 0.05, z);
    } else {
      const y = center.y - 0.05 + s.position * half;
      this.sectionPlane.set(new Vector3(0, -1, 0), y); // keep y <= pos
      ind.rotation.x = Math.PI / 2; ind.scale.set(1.1, 0.8, 1); ind.position.set(0, y, 0);
    }
    for (const p of this.asset.parts) {
      for (const m of p.meshes) {
        const mat = m.material as MeshStandardMaterial;
        mat.clippingPlanes = s.enabled ? [this.sectionPlane] : null;
        if (p.kind !== 'shell') mat.side = s.enabled ? DoubleSide : FrontSide;
        mat.needsUpdate = true;
      }
    }
    this.invalidate();
  }

  get isLowPower() {
    return this.lowPower;
  }
}
