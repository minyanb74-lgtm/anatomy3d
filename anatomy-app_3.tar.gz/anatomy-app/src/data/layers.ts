import type { LayerId } from './types';

export interface LayerDef {
  id: LayerId;
  hebrewName: string;
  defaultVisible: boolean;
  /** Order from outside (0) to inside – used for the layers sheet. */
  order: number;
}

export const LAYERS: LayerDef[] = [
  { id: 'skin', hebrewName: 'עור', defaultVisible: false, order: 0 },
  { id: 'fat', hebrewName: 'שומן תת־עורי', defaultVisible: false, order: 1 },
  { id: 'fascia', hebrewName: 'פאשיה', defaultVisible: false, order: 2 },
  { id: 'superficialMuscles', hebrewName: 'שרירים שטחיים', defaultVisible: true, order: 3 },
  { id: 'deepMuscles', hebrewName: 'שרירים עמוקים', defaultVisible: true, order: 4 },
  { id: 'tendons', hebrewName: 'גידים', defaultVisible: true, order: 5 },
  { id: 'ligaments', hebrewName: 'רצועות', defaultVisible: false, order: 6 },
  { id: 'bones', hebrewName: 'עצמות', defaultVisible: true, order: 7 },
  { id: 'nerves', hebrewName: 'עצבים', defaultVisible: false, order: 8 },
  { id: 'vessels', hebrewName: 'כלי דם', defaultVisible: false, order: 9 },
];

export const REGION_NAMES: Record<string, string> = {
  shoulder: 'כתף', arm: 'זרוע', forearm: 'אמה', chest: 'חזה', back: 'גב', core: 'בטן וגו',
  hip: 'אגן וירך עליונה', thigh: 'ירך', leg: 'שוק', head: 'ראש', trunk: 'גו', hand: 'כף יד', foot: 'כף רגל',
};

export const ROLE_META = {
  agonist: { hebrew: 'אגוניסטים', single: 'אגוניסט', emoji: '🔴', color: '#ff3b3b' },
  synergist: { hebrew: 'מסייעים', single: 'מסייע', emoji: '🩷', color: '#ff7eb6' },
  stabilizer: { hebrew: 'מייצבים', single: 'מייצב', emoji: '🟣', color: '#9b4dff' },
  antagonist: { hebrew: 'אנטגוניסטים', single: 'אנטגוניסט', emoji: '🔵', color: '#2fb4ff' },
} as const;
