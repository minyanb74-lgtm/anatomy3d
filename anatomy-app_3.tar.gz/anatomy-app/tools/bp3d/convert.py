"""
BodyParts3D → mobile GLB converter.

Source: BodyParts3D, © The Database Center for Life Science, licensed CC BY-SA 2.1 Japan
        (mirror: github.com/Kevin-Mattheus-Moerman/BodyParts3D).

Usage:
    python3 tools/bp3d/convert.py <stl_dir> <selection.json> <out_dir>

Produces:
    <out_dir>/bp3d.raw.glb        – one mesh node per structure ("p0", "p1", …)
    <out_dir>/bp3d.manifest.json  – per-node metadata (ref, kind, layer, side, label) + rig joints

Only musculoskeletal structures and great vessels are converted; organs, skin and hair are excluded
upstream by the selection allowlist.

Coordinate mapping: BP3D is millimetres, Z up, figure's left = +X, anterior = −Y.
App convention:      metres,      Y up, figure's left = +X, anterior = +Z.  → (x, z, −y) / 1000
"""
import json
import os
import re
import sys

import fast_simplification
import numpy as np
import trimesh

STL_DIR, SEL_PATH, OUT_DIR = sys.argv[1:4]
TOTAL_TRIS = int(os.environ.get("TOTAL_TRIS", "360000"))

sel = json.load(open(SEL_PATH))

# ───────────── mapping BP3D names → app data references ─────────────

MUSCLE_MAP = [
    (r"biceps brachii", "muscle.biceps_brachii"),
    (r"^brachialis$", "muscle.brachialis"),
    (r"brachioradialis", "muscle.brachioradialis"),
    (r"triceps brachii", "muscle.triceps_brachii"),
    (r"deltoid", "muscle.deltoid"),
    (r"supraspinatus", "muscle.supraspinatus"),
    (r"pectoralis major", "muscle.pectoralis_major"),
    (r"latissimus dorsi", "muscle.latissimus_dorsi"),
    (r"trapezius", "muscle.trapezius"),
    (r"rectus abdominis", "muscle.rectus_abdominis"),
    (r"^(iliocostalis|longissimus|spinalis) ", "muscle.erector_spinae"),
    (r"gluteus maximus", "muscle.gluteus_maximus"),
    (r"gluteus medius", "muscle.gluteus_medius"),
    (r"(iliacus|psoas major)", "muscle.iliopsoas"),
    (r"sartorius", "muscle.sartorius"),
    (r"rectus femoris", "muscle.rectus_femoris"),
    (r"vastus lateralis", "muscle.vastus_lateralis"),
    (r"vastus medialis", "muscle.vastus_medialis"),
    (r"vastus intermedius", "muscle.vastus_intermedius"),
    (r"biceps femoris", "muscle.biceps_femoris"),
    (r"semitendinosus", "muscle.semitendinosus"),
    (r"gastrocnemius", "muscle.gastrocnemius"),
    (r"^soleus$", "muscle.soleus"),
    (r"tibialis anterior", "muscle.tibialis_anterior"),
]

BONE_MAP = [
    (r"(frontal bone|parietal|occipital bone|temporal bone|sphenoid|ethmoid|mandible|maxilla|zygomatic bone|nasal bone|lacrimal|palatine|vomer|concha)", "bone.skull", "head"),
    (r"(vertebra$|^atlas$|^axis$|intervertebral disk)", "bone.vertebrae", "spine"),
    (r"sacrum", "bone.sacrum", "pelvis"),
    (r"(\brib$|costal cartilage)", "bone.ribs", "torso"),
    (r"(sternum|manubrium|xiphoid)", "bone.sternum", "torso"),
    (r"clavicle", "bone.clavicle", "torso"),
    (r"scapula", "bone.scapula", "torso"),
    (r"humerus", "bone.humerus", "upperArm"),
    (r"radius", "bone.radius", "forearm"),
    (r"ulna", "bone.ulna", "forearm"),
    (r"(metacarpal|phalanx of (index|middle|ring|little) finger|phalanx of thumb|scaphoid|lunate|triquetral|pisiform|trapezium|trapezoid|capitate|hamate)", "bone.hand", "hand"),
    (r"hip bone", "bone.pelvis", "pelvis"),
    (r"femur", "bone.femur", "thigh"),
    (r"patella", "bone.patella", "shank"),
    (r"tibia", "bone.tibia", "shank"),
    (r"fibula", "bone.fibula", "shank"),
    (r"calcaneus", "bone.calcaneus", "foot"),
    (r"(talus|cuneiform|cuboid|navicular|metatarsal|phalanx of (big|second|third|fourth|little) toe|sesamoid bone of foot)", "bone.foot", "foot"),
    (r"hyoid bone", "bone.x.hyoid_bone", "head"),
]

# Unlisted muscles that lie deep to others (for the "deep muscles" layer).
DEEP = r"(diaphragm|coccygeus|levator ani|puborectalis|iliococcygeus|intercostal|rotator|multifidus|interspinales|intertransvers|levatores|longus colli|longus capitis|rectus capitis|obliquus capitis|semispinalis|pectoralis minor|subclavius|transversus|internal oblique|quadratus lumborum|gluteus minimus|piriformis|gemellus|obturator|quadratus femoris|adductor (brevis|magnus|minimus)|popliteus|tibialis posterior|flexor digitorum longus|flexor hallucis longus|supinator|pronator quadratus|flexor digitorum profundus|flexor pollicis longus|extensor indicis|lumbrical|inteross|infraspinatus|teres minor|subscapularis|rhomboid|levator scapulae|serratus posterior|coracobrachialis|scalenus|pterygoid|flexor accessorius|splenius)"

HIGH_DETAIL = {ref for _, ref in MUSCLE_MAP}


def side_of(name):
    if re.search(r"\bleft\b", name):
        return "L"
    if re.search(r"\bright\b", name):
        return "R"
    return None


def slug(name):
    n = re.sub(r"\b(left|right)\b", "", name)
    n = re.sub(r"[^a-z0-9]+", "_", n.lower()).strip("_")
    return n


BONE_NAME = r"(\bbone$|vertebra$|\brib$|cartilage$|^intervertebral disk|sternum$|manubrium$|xiphoid process$|clavicle$|scapula$|humerus$|radius$|ulna$|femur$|tibia$|fibula$|patella$|calcaneus$|talus$|scaphoid$|lunate$|triquetral$|pisiform$|trapezium$|trapezoid$|capitate$|hamate$|sacrum$|atlas$|axis$|mandible$|maxilla$|ethmoid$|vomer$|concha$|phalanx of )"


def classify(name, kind):
    # side words may appear mid-name ("distal phalanx of left index finger")
    l = re.sub(r"\b(left|right) ", "", name.lower()).replace(", nsn", "")
    if kind in ("muscle", "bone"):
        kind = "bone" if re.search(BONE_NAME, l) else "muscle"
    if kind == "muscle":
        for pat, ref in MUSCLE_MAP:
            if re.search(pat, l):
                depth = "deepMuscles" if ref in ("muscle.brachialis", "muscle.supraspinatus", "muscle.erector_spinae",
                                                 "muscle.gluteus_medius", "muscle.iliopsoas", "muscle.vastus_intermedius",
                                                 "muscle.soleus") else "superficialMuscles"
                return ref, "muscle", depth, None
        return f"muscle.x.{slug(name)}", "muscle", "deepMuscles" if re.search(DEEP, l) else "superficialMuscles", None
    if kind == "bone":
        for pat, ref, seg in BONE_MAP:
            if re.search(pat, l):
                return ref, "bone", "bones", seg
        return f"bone.x.{slug(name)}", "bone", "bones", None
    if kind == "vessel":
        if "aorta" in l:
            return "vessel.aorta", "vessel", "vessels", None
        return f"vessel.x.{slug(name)}", "vessel", "vessels", None
    # connective tissue
    if re.search(r"(calcaneal tendon|iliotibial tract|intermediate tendon|linea alba)", l):
        return f"tendon.x.{slug(name)}", "ligament", "tendons", None
    if re.search(r"ligament", l):
        return f"ligament.x.{slug(name)}", "ligament", "ligaments", None
    return f"fascia.x.{slug(name)}", "ligament", "fascia", None


PELVIC_FLOOR = r"(pubococcygeus|puborectalis|iliococcygeus|coccygeus|levator ani)"


def display_label(name):
    l = re.sub(r"\b(left|right) ", "", name).replace(", nsn", "")
    return "pelvic floor muscle" if re.search(PELVIC_FLOOR, l.lower()) else l


# ───────────── load ─────────────

items = []
for fid, info in sel.items():
    path = os.path.join(STL_DIR, fid + ".stl")
    if not os.path.exists(path):
        print("missing", fid, info["name"])
        continue
    m = trimesh.load(path, force="mesh", process=True)
    if m.faces.shape[0] == 0:
        continue
    v = m.vertices / 1000.0
    v = np.stack([v[:, 0], v[:, 2], -v[:, 1]], axis=1)  # → Y up, anterior +Z
    ref, kind, layer, seg = classify(info["name"], info["kind"])
    items.append(dict(fid=fid, name=info["name"], ref=ref, kind=kind, layer=layer, seg=seg,
                      side=side_of(info["name"]), v=v, f=m.faces.astype(np.int64)))
print("loaded", len(items))

# ground the model: lowest foot point at y = 0, centred on x/z by the pelvis
all_min_y = min(it["v"][:, 1].min() for it in items)
pel = [it for it in items if it["ref"] == "bone.pelvis"]
pv = np.concatenate([it["v"] for it in pel])
cx, cz = (pv[:, 0].min() + pv[:, 0].max()) / 2, (pv[:, 2].min() + pv[:, 2].max()) / 2
for it in items:
    it["v"] = it["v"] - np.array([cx, all_min_y, cz])

# ───────────── triangle budget ─────────────

def weight(it):
    w = it["f"].shape[0] ** 0.6
    if it["ref"] in HIGH_DETAIL:
        w *= 2.2
    if it["kind"] == "bone":
        w *= 0.8
    return w

total_w = sum(weight(it) for it in items)
for it in items:
    target = int(TOTAL_TRIS * weight(it) / total_w)
    it["target"] = max(120, min(target, it["f"].shape[0]))

# ───────────── decimate ─────────────

out_tris = 0
for it in items:
    n = it["f"].shape[0]
    if it["target"] < n:
        ratio = 1 - it["target"] / n
        v, f = fast_simplification.simplify(it["v"].astype(np.float32), it["f"].astype(np.int32), target_reduction=ratio, agg=6)
        it["v"], it["f"] = v, f
    out_tris += it["f"].shape[0]
print("triangles after decimation", out_tris)

# ───────────── rig joints from bone geometry ─────────────

def verts(ref, side=None):
    vs = [it["v"] for it in items if it["ref"] == ref and (side is None or it["side"] == side)]
    return np.concatenate(vs) if vs else None


def band_center(v, axis, frac, top=True):
    """Centroid of the vertices in the top (or bottom) `frac` of the extent along `axis`."""
    lo, hi = v[:, axis].min(), v[:, axis].max()
    t = hi - (hi - lo) * frac if top else lo + (hi - lo) * frac
    sel_v = v[v[:, axis] >= t] if top else v[v[:, axis] <= t]
    return sel_v.mean(axis=0)


joints = {}
for s in ("L", "R"):
    fem = verts("bone.femur", s)
    # femoral head = the most medial part of the top of the femur
    top = fem[fem[:, 1] >= fem[:, 1].max() - 0.06]
    med = top[np.argsort(np.abs(top[:, 0]))[: max(10, len(top) // 3)]]
    joints[f"hip{s}"] = med.mean(axis=0)
    tib = verts("bone.tibia", s)
    joints[f"knee{s}"] = (band_center(fem, 1, 0.03, top=False) + band_center(tib, 1, 0.03, top=True)) / 2
    fib = verts("bone.fibula", s)
    ank = np.concatenate([tib[tib[:, 1] <= tib[:, 1].min() + 0.02], fib[fib[:, 1] <= fib[:, 1].min() + 0.02]])
    joints[f"ankle{s}"] = ank.mean(axis=0)
    hum = verts("bone.humerus", s)
    joints[f"shoulder{s}"] = band_center(hum, 1, 0.06, top=True)
    joints[f"elbow{s}"] = band_center(hum, 1, 0.04, top=False)
    fore = np.concatenate([verts("bone.radius", s), verts("bone.ulna", s)])
    joints[f"wrist{s}"] = band_center(fore, 1, 0.03, top=False)
    hand = verts("bone.hand", s)
    joints[f"handTip{s}"] = band_center(hand, 1, 0.05, top=False)
    foot = np.concatenate([verts("bone.foot", s), verts("bone.calcaneus", s)])
    joints[f"heel{s}"] = foot[np.argmin(foot[:, 2])]
    joints[f"toe{s}"] = foot[np.argmax(foot[:, 2])]

joints["pelvis"] = (joints["hipL"] + joints["hipR"]) / 2
lum = [it for it in items if it["name"].endswith("third lumbar vertebra")]
joints["lumbar"] = lum[0]["v"].mean(axis=0) if lum else joints["pelvis"] + np.array([0, 0.12, 0])
c7 = [it for it in items if it["name"].endswith("seventh cervical vertebra")]
joints["neck"] = c7[0]["v"].mean(axis=0) if c7 else joints["lumbar"] + np.array([0, 0.45, 0])
skull = verts("bone.skull")
joints["headTop"] = np.array([0, skull[:, 1].max(), skull[:, 2].mean()])

# ───────────── write GLB + manifest ─────────────

scene = trimesh.Scene()
manifest = {
    "source": "BodyParts3D, © The Database Center for Life Science (DBCLS), CC BY-SA 2.1 Japan",
    "units": "m",
    "joints": {k: [round(float(x), 5) for x in v] for k, v in joints.items()},
    "parts": [],
}
for i, it in enumerate(items):
    mesh = trimesh.Trimesh(vertices=it["v"], faces=it["f"], process=False)
    mesh.fix_normals()
    node = f"p{i}"
    scene.add_geometry(mesh, node_name=node, geom_name=node)
    manifest["parts"].append(dict(node=node, ref=it["ref"], kind=it["kind"], layer=it["layer"], side=it["side"],
                                  seg=it["seg"], label=display_label(it["name"])))

os.makedirs(OUT_DIR, exist_ok=True)
scene.export(os.path.join(OUT_DIR, "bp3d.raw.glb"))
json.dump(manifest, open(os.path.join(OUT_DIR, "bp3d.manifest.json"), "w"), ensure_ascii=False)
print("joints", {k: [round(float(x), 3) for x in v] for k, v in joints.items()})
print("parts", len(manifest["parts"]))
