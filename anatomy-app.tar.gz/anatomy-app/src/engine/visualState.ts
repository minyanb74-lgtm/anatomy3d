/**
 * The engine-facing description of how the model should look.
 * Produced by business logic (src/logic/visualState.ts); consumed by Engine.applyVisualState.
 * Keys are either a model reference ("muscle.deltoid") – matching both sides – or an
 * instance key ("muscle.deltoid#L").
 */
import type { LayerId } from '@/data';

export interface Tint {
  color: number;
  /** 0..1 – how strongly the tint replaces the base colour. */
  strength: number;
  opacity?: number;
}

export interface VisualState {
  layers: Record<LayerId, boolean>;
  hidden: Set<string>;
  isolate: Set<string> | null;
  isolateMode: 'ghost' | 'hide';
  selected: Set<string>;
  tints: Map<string, Tint>;
  /** De-emphasise muscles without a tint (used while showing a movement). */
  dimUntinted: boolean;
  /** Extra glow (e.g. innervating nerve, muscles attached to a bone, quiz feedback). */
  highlight: Set<string>;
  /** Layers forced on so highlighted structures are visible. */
  forceLayers: Set<LayerId>;
}

export type ViewPreset = 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom' | 'threeQuarter';

export interface CameraState {
  position: [number, number, number];
  target: [number, number, number];
}

export interface SectionState {
  enabled: boolean;
  axis: 'sagittal' | 'coronal' | 'transverse';
  /** -1..1 across the body. */
  position: number;
}
