/**
 * PoseDriver – maps an anatomical Pose (degrees per DOF) onto rig segments, then grounds the body.
 * Works for any AnatomyAsset whose rig follows the segment convention (procedural or glTF).
 */
import { MathUtils, Vector3 } from 'three';
import type { Clip, Pose } from '@/data';
import type { Rig, Side } from '@/assets';

const D = MathUtils.degToRad;
const _v = new Vector3();

export interface PoseOptions {
  grounding: Clip['grounding'];
  rootHeight?: number;
  flatFeet?: Clip['flatFeet'];
}

export function applyPose(rig: Rig, pose: Pose, opts: PoseOptions = { grounding: 'feet' }) {
  const s = rig.segments;
  const g = (k: keyof Pose) => pose[k] ?? 0;
  const rootPitch = g('rootPitch');
  const pelvisTilt = g('pelvisTilt');

  s.root.rotation.set(D(rootPitch), 0, 0);
  s.pelvis.rotation.set(D(pelvisTilt), 0, 0);
  s.torso.rotation.set(D(g('trunkFlex')), 0, 0);

  for (const side of ['L', 'R'] as Side[]) {
    const m = side === 'L' ? 1 : -1;
    const k = (n: string) => g((n + side) as keyof Pose);
    s[`upperArm${side}`].rotation.set(-D(k('shoulderFlex')), 0, m * D(k('shoulderAbd')));
    s[`forearm${side}`].rotation.set(-D(k('elbowFlex')), -m * D(k('forearmSup')), 0);
    s[`thigh${side}`].rotation.set(-D(k('hipFlex')), 0, m * D(k('hipAbd')));
    s[`shank${side}`].rotation.set(D(k('kneeFlex')), 0, 0);
    let ankle = k('anklePlantar');
    if (opts.flatFeet === 'both' || opts.flatFeet === side) {
      // keep the sole parallel to the floor: sum of sagittal rotations along the chain = 0
      ankle = k('hipFlex') - k('kneeFlex') - pelvisTilt - rootPitch;
    }
    s[`foot${side}`].rotation.set(D(ankle), 0, 0);
  }

  // Grounding
  s.root.position.y = opts.grounding === 'feet' ? rig.restRootHeight : opts.rootHeight ?? rig.restRootHeight;
  s.root.updateMatrixWorld(true);
  if (opts.grounding === 'feet') {
    let minY = Infinity;
    for (const c of rig.contacts) minY = Math.min(minY, s[c.segment].localToWorld(_v.copy(c.local)).y);
    s.root.position.y -= minY;
  } else if (opts.grounding === 'hands') {
    let maxY = -Infinity;
    for (const c of rig.contacts) if (c.kind === 'hand') maxY = Math.max(maxY, s[c.segment].localToWorld(_v.copy(c.local)).y);
    s.root.position.y += (opts.rootHeight ?? 2.2) - maxY;
  }
  s.root.updateMatrixWorld(true);
}
