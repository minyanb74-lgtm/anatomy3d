/**
 * Quiz generator – questions are generated from the data layer, so every new muscle that is
 * added to the data automatically becomes quiz material.
 */
import { data, type Id, type Muscle } from '@/data';

export type QuestionType = 'find' | 'action' | 'innervation' | 'origin' | 'insertion' | 'antagonist' | 'movement';

export interface Question {
  type: QuestionType;
  muscleId: Id;
  prompt: string;
  /** For multiple choice. */
  options?: string[];
  correctIndex?: number;
}

export interface QuizAnswer {
  question: Question;
  correct: boolean;
  given?: string;
}

export interface QuizState {
  questions: Question[];
  index: number;
  answers: QuizAnswer[];
  /** Feedback for the last answer, shown until the user taps "next". */
  feedback: { correct: boolean; text: string } | null;
}

const shuffle = <T>(a: T[]) => {
  const x = [...a];
  for (let i = x.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [x[i], x[j]] = [x[j], x[i]];
  }
  return x;
};
const pick = <T>(a: T[]) => a[Math.floor(Math.random() * a.length)];

function mcq(m: Muscle, type: QuestionType, prompt: string, correct: string, pool: string[]): Question | null {
  const wrong = shuffle([...new Set(pool.filter((p) => p !== correct))]).slice(0, 3);
  if (wrong.length < 2) return null;
  const options = shuffle([correct, ...wrong]);
  return { type, muscleId: m.id, prompt, options, correctIndex: options.indexOf(correct) };
}

const nameOf = (m: Muscle) => `${m.hebrewName} (${m.latinName})`;

function makeQuestion(m: Muscle, type: QuestionType): Question | null {
  const others = data.muscles.filter((x) => x.id !== m.id);
  switch (type) {
    case 'find':
      return { type, muscleId: m.id, prompt: `מצא במודל את: ${nameOf(m)}` };
    case 'action':
      return mcq(m, type, `מה הפעולה העיקרית של ${nameOf(m)}?`, m.primaryActions[0].text, others.map((o) => o.primaryActions[0].text));
    case 'innervation': {
      const nerve = data.nerve(m.innervation[0].nerveId)!;
      return mcq(m, type, `איזה עצב מעצבב את ${nameOf(m)}?`, nerve.hebrewName, data.nerves.map((n) => n.hebrewName));
    }
    case 'origin':
      return mcq(m, type, `מה המוצא של ${nameOf(m)}?`, m.origin[0].text, others.flatMap((o) => o.origin.map((x) => x.text)));
    case 'insertion':
      return mcq(m, type, `מה האחז של ${nameOf(m)}?`, m.insertion[0].text, others.flatMap((o) => o.insertion.map((x) => x.text)));
    case 'antagonist': {
      if (!m.antagonists.length) return null;
      const correct = data.muscle(pick(m.antagonists))!.hebrewName;
      const exclude = new Set([...m.antagonists, m.id]);
      return mcq(m, type, `איזה שריר הוא אנטגוניסט של ${nameOf(m)}?`, correct, data.muscles.filter((x) => !exclude.has(x.id)).map((x) => x.hebrewName));
    }
    case 'movement': {
      const mv = data.movementsForMuscle(m.id).filter((x) => x.role.role === 'agonist');
      if (!mv.length) return null;
      const correct = pick(mv).movement.hebrewName;
      const own = new Set(data.movementsForMuscle(m.id).map((x) => x.movement.hebrewName));
      return mcq(m, type, `באיזו תנועה ${m.hebrewName} משמש כאגוניסט?`, correct, data.movements.map((x) => x.hebrewName).filter((n) => !own.has(n)));
    }
  }
}

export function generateQuiz(count = 10, types: QuestionType[] = ['find', 'action', 'innervation', 'origin', 'insertion', 'antagonist', 'movement']): QuizState {
  const questions: Question[] = [];
  let guard = 0;
  while (questions.length < count && guard++ < 200) {
    const q = makeQuestion(pick(data.muscles), pick(types));
    if (q && !questions.some((x) => x.muscleId === q.muscleId && x.type === q.type)) questions.push(q);
  }
  return { questions, index: 0, answers: [], feedback: null };
}

export function quizStats(q: QuizState) {
  const correct = q.answers.filter((a) => a.correct).length;
  const answered = q.answers.length;
  return {
    correct,
    wrong: answered - correct,
    answered,
    total: q.questions.length,
    score: correct * 10,
    percent: answered ? Math.round((correct / answered) * 100) : 0,
    done: answered >= q.questions.length,
  };
}
