/**
 * Playback – samples the active clip at the current time and drives the engine pose.
 */
import { MathUtils } from 'three';
import type { Clip, Dof, Pose } from '@/data';

const ease = (t: number) => t * t * (3 - 2 * t);

/** Sample a clip at normalised time t (0..1) with smooth easing between keyframes. */
export function sampleClip(clip: Clip, t: number): Pose {
  const kf = clip.keyframes;
  if (!kf.length) return {};
  if (t <= kf[0].t) return kf[0].pose;
  for (let i = 0; i < kf.length - 1; i++) {
    const a = kf[i];
    const b = kf[i + 1];
    if (t >= a.t && t <= b.t) {
      const u = ease((t - a.t) / Math.max(1e-6, b.t - a.t));
      const keys = new Set([...Object.keys(a.pose), ...Object.keys(b.pose)]) as Set<Dof>;
      const out: Pose = {};
      for (const k of keys) out[k] = MathUtils.lerp(a.pose[k] ?? 0, b.pose[k] ?? 0, u);
      return out;
    }
  }
  return kf[kf.length - 1].pose;
}

export const SPEEDS = [0.25, 0.5, 1, 1.5] as const;
