/**
 * Saved views (requirement #26) – persisted in localStorage on the device.
 */
import type { LayerId } from '@/data';
import type { CameraState, SectionState } from '@/engine/visualState';
import type { ActiveMotion, Selection } from './store';

export interface SavedView {
  id: string;
  name: string;
  createdAt: number;
  layers: Record<LayerId, boolean>;
  hidden: string[];
  isolated: string[] | null;
  selection: Selection | null;
  camera: CameraState;
  motion: { source: ActiveMotion['source']; id: string } | null;
  /** Only for custom (built) motions, which are not in the library. */
  customMotion?: ActiveMotion | null;
  time: number;
  section: SectionState;
}

const KEY = 'anatomy.savedViews.v1';

export function listViews(): SavedView[] {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
}

function write(v: SavedView[]) {
  try { localStorage.setItem(KEY, JSON.stringify(v)); return true; } catch { return false; }
}

export function saveView(v: Omit<SavedView, 'id' | 'createdAt'>): SavedView {
  const view: SavedView = { ...v, id: Math.random().toString(36).slice(2, 10), createdAt: Date.now() };
  write([view, ...listViews()]);
  return view;
}

export function deleteView(id: string) {
  write(listViews().filter((v) => v.id !== id));
}
