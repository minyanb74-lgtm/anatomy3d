/**
 * AppController – the business-logic layer. UI components call these actions; the controller
 * updates the store and drives the engine. It is the only module that knows both.
 */
import { Vector3 } from 'three';
import { data, type EntityKind, type Id, type LayerId } from '@/data';
import { createAssetProvider, instanceKey } from '@/assets';
import { Engine, type PickResult } from '@/engine/Engine';
import type { SectionState, ViewPreset } from '@/engine/visualState';
import { store, defaultLayers, type AppState, type Modal, type SheetSnap, type Tab, type Selection, type ActiveMotion } from './store';
import { buildVisualState } from './visualState';
import { sampleClip } from './playback';
import { generateQuiz, quizStats } from './quiz';
import { buildMotion } from './motionBuilder';
import { saveView, type SavedView } from './savedViews';
import type { QueryResult } from './search';

const THEME_BG = { dark: 0x0b0f14, light: 0xeef1f5 };

class AppController {
  engine: Engine | null = null;
  private unsub: (() => void)[] = [];
  private toastTimer = 0;

  /* ───────────── lifecycle ───────────── */

  async mount(container: HTMLElement) {
    if (this.engine) return;
    const engine = new Engine(container);
    this.engine = engine;
    engine.setBackground(THEME_BG[store.getState().theme]);
    this.unsub.push(engine.onPick((r, d) => this.handlePick(r, d)));
    this.unsub.push(engine.onFrame((dt) => this.tick(dt)));
    this.unsub.push(store.subscribe((s, p) => this.sync(s, p)));
    const asset = await engine.load(createAssetProvider(), (f) => store.setState({ loadProgress: f }));
    store.setState({ ready: true, loadProgress: 1, isPlaceholderModel: asset.isPlaceholder, modelAttribution: asset.attribution });
    engine.applyVisualState(buildVisualState(store.getState()));
    engine.setPose({}, { grounding: 'feet' });
    engine.resetCamera();
  }

  unmount() {
    this.unsub.forEach((u) => u());
    this.unsub = [];
    this.engine?.dispose();
    this.engine = null;
  }

  /** Keep the engine in sync with the store. */
  private sync(s: AppState, p: AppState) {
    const e = this.engine;
    if (!e) return;
    if (s.layers !== p.layers || s.hidden !== p.hidden || s.isolated !== p.isolated || s.selection !== p.selection || s.motion !== p.motion || s.highlight !== p.highlight || s.quiz !== p.quiz) {
      e.applyVisualState(buildVisualState(s));
    }
    if (s.motion !== p.motion || (s.motion && s.playback.time !== p.playback.time)) {
      if (s.motion) {
        const c = s.motion.clip;
        e.setPose(sampleClip(c, s.playback.time), { grounding: c.grounding, rootHeight: c.rootHeight, flatFeet: c.flatFeet });
      } else e.setPose({}, { grounding: 'feet' });
    }
    if (s.section !== p.section) e.setSection(s.section);
    if (s.theme !== p.theme) {
      e.setBackground(THEME_BG[s.theme]);
      try { localStorage.setItem('anatomy.theme', s.theme); } catch { /* storage unavailable */ }
    }
    if (s.lowPower !== p.lowPower) e.setLowPower(s.lowPower);
  }

  private tick(dt: number) {
    const s = store.getState();
    if (!s.motion || !s.playback.playing) return;
    let t = s.playback.time + (dt * s.playback.speed) / s.motion.clip.duration;
    if (t >= 1) t -= 1;
    store.setState({ playback: { ...s.playback, time: t } });
  }

  /* ───────────── navigation / chrome ───────────── */

  setTab(tab: Tab) {
    const s = store.getState();
    const patch: Partial<AppState> = { tab, modal: null, detail: null, query: null, highlight: null };
    // The learn tab keeps the selection (it teaches the selected muscle); other tabs start clean.
    if (tab !== 'learn' && tab !== 'home') patch.selection = null;
    if (tab !== 'movements' && tab !== 'exercises' && s.motion) { patch.motion = null; patch.playback = { ...s.playback, playing: false, time: 0 }; }
    if (tab === 'home') patch.sheet = s.selection ? 'peek' : 'closed';
    else patch.sheet = 'half';
    if (tab !== 'learn' && s.quiz) patch.quiz = null;
    store.setState(patch);
    if (s.motion && !store.getState().motion) this.resetCamera();
    if (tab === 'learn' && s.selection?.ref) requestAnimationFrame(() => this.engine?.focusOn([s.selection!.ref!]));
  }
  setSheet(sheet: SheetSnap) { store.setState({ sheet }); }
  setOcclusion(top: number, bottom: number) { this.engine?.setOcclusion(top, bottom); }
  openModal(modal: Modal) { store.setState({ modal }); }
  closeModal() { store.setState({ modal: null }); }
  setTheme(theme: 'dark' | 'light') { store.setState({ theme }); }
  setLowPower(lowPower: boolean) { store.setState({ lowPower }); }

  toast(msg: string) {
    store.setState({ toast: msg });
    clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => store.setState({ toast: null }), 2200);
  }

  /* ───────────── selection ───────────── */

  private handlePick(r: PickResult | null, double: boolean) {
    const s = store.getState();
    if (s.quiz) return this.answerFind(r);
    if (!r || r.part.kind === 'shell') {
      if (!double && s.selection && !s.isolated) store.setState({ selection: null, highlight: null, sheet: s.tab === 'home' ? 'closed' : s.sheet });
      return;
    }
    const ent = data.byModelReference(r.part.ref);
    if (!ent) return;
    this.select(ent.kind, ent.id, { ref: r.part.ref, side: r.part.side, focus: false });
    if (double) this.isolate([r.key]);
  }

  select(kind: EntityKind, id: Id, opts: { ref?: string; side?: 'L' | 'R'; focus?: boolean } = {}) {
    const ent = data.get(kind, id) as { modelReference?: string } | undefined;
    if (!ent) return;
    if (kind === 'movement') return this.playMovement(id);
    if (kind === 'exercise') return this.playExercise(id);
    if (kind === 'joint') { store.setState({ detail: { kind: 'joint', id }, sheet: 'half', modal: null }); return; }
    const ref = opts.ref ?? ent.modelReference;
    const sel: Selection = { kind, id, ref, side: opts.side };
    const s = store.getState();
    // Make sure the structure is visible: turn on its layer if needed.
    let layers = s.layers;
    const layer = this.layerOf(kind, id);
    if (layer && !layers[layer]) layers = { ...layers, [layer]: true };
    store.setState({
      selection: sel, layers, highlight: null, modal: null, detail: null, query: null,
      sheet: s.sheet === 'closed' || s.tab === 'home' ? 'peek' : s.sheet,
      hidden: s.hidden.filter((k) => k !== ref && k !== instanceKey(ref!, opts.side)),
    });
    if (opts.focus !== false && ref) requestAnimationFrame(() => this.engine?.focusOn([ref]));
  }

  clearSelection() {
    const s = store.getState();
    store.setState({ selection: null, highlight: null, sheet: s.tab === 'home' ? 'closed' : s.sheet });
  }

  private layerOf(kind: EntityKind, id: Id): LayerId | null {
    if (kind === 'muscle') return data.muscle(id)!.depth === 'deep' ? 'deepMuscles' : 'superficialMuscles';
    return ({ bone: 'bones', nerve: 'nerves', vessel: 'vessels', ligament: 'ligaments' } as Record<string, LayerId>)[kind] ?? null;
  }

  /** Hide the selected instance (or both sides if selected from a list). */
  hideSelected() {
    const s = store.getState();
    if (!s.selection?.ref) return;
    const key = s.selection.side ? instanceKey(s.selection.ref, s.selection.side) : s.selection.ref;
    store.setState({ hidden: [...new Set([...s.hidden, key])], selection: null, sheet: s.tab === 'home' ? 'closed' : s.sheet, isolated: null });
    this.toast('המבנה הוסתר · "הצג הכול" מחזיר');
  }

  showAll() {
    store.setState({ hidden: [], isolated: null, highlight: null });
  }

  isolate(keys: string[]) {
    store.setState({ isolated: keys });
    this.engine?.focusOn(keys);
  }

  isolateSelected() {
    const s = store.getState();
    if (!s.selection?.ref) return;
    this.isolate([s.selection.side ? instanceKey(s.selection.ref, s.selection.side) : s.selection.ref]);
  }

  exitIsolation() { store.setState({ isolated: null }); }

  /* ───────────── layers ───────────── */

  toggleLayer(id: LayerId) {
    const s = store.getState();
    store.setState({ layers: { ...s.layers, [id]: !s.layers[id] } });
  }
  setLayers(layers: Record<LayerId, boolean>) { store.setState({ layers }); }
  resetLayers() { store.setState({ layers: defaultLayers() }); }
  skeletonMode() {
    const l = Object.fromEntries(Object.keys(defaultLayers()).map((k) => [k, k === 'bones' || k === 'ligaments'])) as Record<LayerId, boolean>;
    store.setState({ layers: l, motion: null, isolated: null, detail: null });
    this.resetCamera();
    this.toast('מצב שלד');
  }

  /* ───────────── relations / highlights ───────────── */

  showInnervation(muscleId: Id) {
    const m = data.muscle(muscleId);
    if (!m) return;
    const keys = m.innervation.map((i) => data.nerve(i.nerveId)?.modelReference).filter(Boolean) as string[];
    store.setState({ highlight: { label: `עצבוב: ${m.innervation.map((i) => data.nerve(i.nerveId)?.hebrewName).join(', ')}`, keys: [...keys, m.modelReference], forceLayers: ['nerves'] } });
    this.engine?.focusOn([...keys, m.modelReference]);
  }

  showBoneMuscles(boneId: Id) {
    const b = data.bone(boneId);
    if (!b) return;
    const keys = data.musclesForBone(boneId).map((x) => x.muscle.modelReference);
    store.setState({ highlight: { label: `שרירים המחוברים ל${b.hebrewName}`, keys: [...keys, b.modelReference], forceLayers: ['superficialMuscles', 'deepMuscles', 'bones'] } });
  }

  clearHighlight() { store.setState({ highlight: null }); }

  /* ───────────── motions ───────────── */

  private startMotion(m: ActiveMotion, detail: AppState['detail']) {
    store.setState({ motion: m, playback: { ...store.getState().playback, time: 0, playing: true }, detail, sheet: 'peek', modal: null, query: null, isolated: null, selection: null, highlight: null });
    // Wait one frame so the sheet/timeline occlusion is known, then frame the whole motion.
    requestAnimationFrame(() => this.frameMotion(m));
  }

  /** Frame the camera on the space the body occupies during the whole clip. */
  private frameMotion(m: ActiveMotion) {
    const e = this.engine;
    if (!e) return;
    const segs: Record<string, string[] | undefined> = {
      arm: ['upperArmL', 'forearmL', 'handL', 'torso'],
      leg: ['pelvis', 'thighL', 'shankL', 'footL', 'thighR', 'shankR', 'footR'],
      shoulder: undefined, trunk: undefined, full: undefined,
    };
    const dirs: Record<string, [number, number, number]> = {
      arm: [0.85, 0.15, 0.5], leg: [0.85, 0.15, 0.5], shoulder: [0.55, 0.25, 0.8], trunk: [0.9, 0.2, 0.4], full: [0.75, 0.22, 0.62],
    };
    const c = m.clip;
    const opts = { grounding: c.grounding, rootHeight: c.rootHeight, flatFeet: c.flatFeet };
    const box = e.rigBounds(segs[c.focus]).makeEmpty();
    for (const t of [0, 0.2, 0.35, 0.5, 0.65, 0.8]) {
      e.setPose(sampleClip(c, t), opts);
      box.union(e.rigBounds(segs[c.focus]));
    }
    const s = store.getState();
    if (s.motion) e.setPose(sampleClip(s.motion.clip, s.playback.time), opts);
    e.frameBox(box, new Vector3(...dirs[c.focus]), c.focus === 'arm' ? 1.35 : 1.12);
  }

  playMovement(id: Id) {
    const mv = data.movement(id);
    const clip = mv && data.clip(mv.clipId);
    if (!mv || !clip) return;
    if (store.getState().tab !== 'movements') store.setState({ tab: 'movements' });
    this.startMotion({ source: 'movement', id, title: mv.hebrewName, clip, roles: mv.roles }, { kind: 'movement', id });
  }

  playExercise(id: Id) {
    const ex = data.exercise(id);
    const clip = ex && data.clip(ex.clipId);
    if (!ex || !clip) return;
    if (store.getState().tab !== 'exercises') store.setState({ tab: 'exercises' });
    this.startMotion({ source: 'exercise', id, title: ex.hebrewName, clip, roles: ex.roles }, { kind: 'exercise', id });
  }

  playCustom(jointId: Id, movementId: Id, angle: number) {
    const b = buildMotion(jointId, movementId, angle);
    if (!b) return;
    this.startMotion({ source: 'custom', id: movementId, title: b.title, clip: b.clip, roles: b.roles }, { kind: 'movement', id: movementId });
  }

  /** Leave the movement/exercise analysis and return to the tab's list. */
  closeMotionDetail() {
    store.setState({ motion: null, detail: null, selection: null, highlight: null, sheet: 'half', playback: { ...store.getState().playback, playing: false, time: 0 } });
    this.resetCamera();
  }

  stopMotion() {
    store.setState({ motion: null, playback: { ...store.getState().playback, playing: false, time: 0 } });
  }

  setPlaying(playing: boolean) { const s = store.getState(); store.setState({ playback: { ...s.playback, playing } }); }
  setTime(time: number) { const s = store.getState(); store.setState({ playback: { ...s.playback, time: Math.max(0, Math.min(0.9999, time)) } }); }
  setSpeed(speed: AppState['playback']['speed']) { const s = store.getState(); store.setState({ playback: { ...s.playback, speed } }); }
  replay() { const s = store.getState(); store.setState({ playback: { ...s.playback, time: 0, playing: true } }); }

  /* ───────────── camera / section ───────────── */

  setView(v: ViewPreset) { this.engine?.setView(v); }
  resetCamera() { this.engine?.resetCamera(); }
  setSection(section: SectionState) { store.setState({ section }); }

  /* ───────────── queries ───────────── */

  showQuery(q: QueryResult) {
    const s = store.getState();
    const keys = q.groups.flatMap((g) => g.muscles.map((m) => data.muscle(m.id)!.modelReference));
    store.setState({ query: q, detail: null, selection: null, motion: null, modal: null, sheet: 'half', tab: s.tab === 'home' ? 'anatomy' : s.tab, highlight: { label: q.title, keys } });
    requestAnimationFrame(() => this.engine?.focusOn(keys, false));
  }

  closeQuery() {
    store.setState({ query: null, highlight: null });
  }

  /* ───────────── quiz ───────────── */

  startQuiz() {
    store.setState({ quiz: generateQuiz(10), selection: null, isolated: null, motion: null, highlight: null, tab: 'learn', sheet: 'half', layers: defaultLayers(), modal: null });
    this.resetCamera();
  }

  private answerFind(r: PickResult | null) {
    const s = store.getState();
    const q = s.quiz!;
    const cur = q.questions[q.index];
    if (!cur || cur.type !== 'find' || q.feedback) return;
    if (!r || r.part.kind !== 'muscle') return;
    const target = data.muscle(cur.muscleId)!;
    const correct = r.part.ref === target.modelReference;
    const tapped = data.byModelReference(r.part.ref);
    store.setState({
      quiz: { ...q, answers: [...q.answers, { question: cur, correct, given: tapped?.hebrewName }], feedback: { correct, text: correct ? `נכון! זה ${target.hebrewName}` : `לא נכון – בחרת ${tapped?.hebrewName ?? '?'}. השריר הנכון מודגש.` } },
      highlight: { label: target.hebrewName, keys: [target.modelReference] },
    });
  }

  answerChoice(index: number) {
    const q = store.getState().quiz;
    if (!q || q.feedback) return;
    const cur = q.questions[q.index];
    const correct = index === cur.correctIndex;
    const m = data.muscle(cur.muscleId)!;
    store.setState({
      quiz: { ...q, answers: [...q.answers, { question: cur, correct, given: cur.options?.[index] }], feedback: { correct, text: correct ? 'תשובה נכונה' : `התשובה הנכונה: ${cur.options?.[cur.correctIndex!]}` } },
      highlight: { label: m.hebrewName, keys: [m.modelReference] },
    });
  }

  skipQuestion() {
    const q = store.getState().quiz;
    if (!q || q.feedback) return;
    const cur = q.questions[q.index];
    const m = data.muscle(cur.muscleId)!;
    store.setState({ quiz: { ...q, answers: [...q.answers, { question: cur, correct: false }], feedback: { correct: false, text: `דילגת. התשובה: ${cur.type === 'find' ? m.hebrewName : cur.options?.[cur.correctIndex!]}` } }, highlight: { label: m.hebrewName, keys: [m.modelReference] } });
  }

  nextQuestion() {
    const q = store.getState().quiz;
    if (!q) return;
    store.setState({ quiz: { ...q, index: Math.min(q.index + 1, q.questions.length), feedback: null }, highlight: null });
  }

  endQuiz() { store.setState({ quiz: null, highlight: null }); }
  quizStats() { const q = store.getState().quiz; return q ? quizStats(q) : null; }

  /* ───────────── saved views ───────────── */

  saveCurrentView(name: string) {
    const s = store.getState();
    if (!this.engine) return;
    saveView({
      name, layers: s.layers, hidden: s.hidden, isolated: s.isolated, selection: s.selection,
      camera: this.engine.getCameraState(),
      motion: s.motion ? { source: s.motion.source, id: s.motion.id } : null,
      customMotion: s.motion?.source === 'custom' ? s.motion : null,
      time: s.playback.time, section: s.section,
    });
    this.toast(`התצוגה "${name}" נשמרה`);
  }

  loadView(v: SavedView) {
    let motion: ActiveMotion | null = null;
    if (v.customMotion) motion = v.customMotion;
    else if (v.motion?.source === 'movement') { const m = data.movement(v.motion.id); const c = m && data.clip(m.clipId); if (m && c) motion = { source: 'movement', id: m.id, title: m.hebrewName, clip: c, roles: m.roles }; }
    else if (v.motion?.source === 'exercise') { const x = data.exercise(v.motion.id); const c = x && data.clip(x.clipId); if (x && c) motion = { source: 'exercise', id: x.id, title: x.hebrewName, clip: c, roles: x.roles }; }
    const s = store.getState();
    store.setState({
      layers: v.layers, hidden: v.hidden, isolated: v.isolated, selection: v.selection, motion, section: v.section,
      playback: { ...s.playback, time: v.time, playing: false }, modal: null, highlight: null,
      detail: motion ? { kind: motion.source === 'exercise' ? 'exercise' : 'movement', id: motion.id } : null,
      tab: motion ? (motion.source === 'exercise' ? 'exercises' : 'movements') : s.tab,
      sheet: motion || v.selection ? 'peek' : 'closed',
    });
    this.engine?.setCameraState(v.camera);
  }
}

export const controller = new AppController();
