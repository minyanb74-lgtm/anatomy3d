/**
 * "Build a movement" – turns (joint, motion, angle) into an animation clip + muscle roles.
 * Built on the same Clip/RoleEntry types as the library, so complex multi-joint movements can be
 * added later by composing several `JointMotion`s into one clip (see `composeMotions`).
 */
import { data, type Clip, type Id, type JointMotion, type Keyframe, type Pose, type RoleEntry } from '@/data';

const LEG_DOFS = ['hipFlex', 'hipAbd', 'kneeFlex', 'anklePlantar'];

/** Base posture that makes a single-joint motion visible (e.g. lift the leg for ankle motion). */
function basePose(m: JointMotion): Record<string, number> {
  if (m.dof === 'anklePlantar') return { hipFlexL: 30, kneeFlexL: 40 };
  if (m.dof === 'kneeFlex' && m.reverse) return { hipFlexL: 70 };
  if (m.dof === 'forearmSup') return { elbowFlexL: 90, elbowFlexR: 90 };
  return {};
}

function dofKeys(m: JointMotion): string[] {
  if (m.dof === 'trunkFlex') return ['trunkFlex'];
  if (LEG_DOFS.includes(m.dof)) return [m.dof + 'L'];
  return [m.dof + 'L', m.dof + 'R'];
}

export function composeMotions(parts: { motion: JointMotion; angle: number }[], duration = 2.6): Clip {
  const rest: Record<string, number> = {};
  const peak: Record<string, number> = {};
  for (const { motion, angle } of parts) {
    Object.assign(rest, basePose(motion));
    const v = motion.sign * angle;
    const from = motion.dof === 'forearmSup' ? -80 : 0;
    for (const k of dofKeys(motion)) {
      if (motion.reverse) { rest[k] = v; peak[k] = 0; }
      else { rest[k] = rest[k] ?? from; peak[k] = v; }
    }
  }
  const kf: Keyframe[] = [
    { t: 0, pose: rest as Pose },
    { t: 0.5, pose: { ...rest, ...peak } as Pose },
    { t: 1, pose: rest as Pose },
  ];
  const leg = parts.some((p) => LEG_DOFS.includes(p.motion.dof));
  const arm = parts.some((p) => ['elbowFlex', 'forearmSup'].includes(p.motion.dof));
  return { id: 'clip.custom', duration, keyframes: kf, grounding: 'feet', focus: leg ? 'leg' : arm ? 'arm' : parts.some((p) => p.motion.dof === 'trunkFlex') ? 'trunk' : 'shoulder' };
}

export function buildMotion(jointId: Id, movementId: Id, angle: number): { clip: Clip; roles: RoleEntry[]; title: string } | null {
  const joint = data.joint(jointId);
  const motion = joint?.motions.find((m) => m.movementId === movementId);
  const movement = data.movement(movementId);
  if (!joint || !motion || !movement) return null;
  const a = Math.max(motion.typicalRange[0], Math.min(motion.typicalRange[1], angle));
  return { clip: composeMotions([{ motion, angle: a }]), roles: movement.roles, title: `${movement.hebrewName} · ${Math.round(a)}°` };
}
