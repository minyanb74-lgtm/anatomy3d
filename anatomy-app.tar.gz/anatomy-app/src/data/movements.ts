/**
 * Joint movements and the muscle roles in them.
 *
 * `involvement` values are ESTIMATES used only to scale colour intensity on the model
 * (KnowledgeKind = 'estimate'). Role classification follows common kinesiology texts and
 * refers to the concentric phase of the movement against resistance.
 */
import type { Movement, RoleEntry } from './types';

const A = (muscleId: string, involvement = 1, note?: string): RoleEntry => ({ muscleId, role: 'agonist', involvement, note });
const S = (muscleId: string, involvement = 0.6, note?: string): RoleEntry => ({ muscleId, role: 'synergist', involvement, note });
const ST = (muscleId: string, involvement = 0.5, note?: string): RoleEntry => ({ muscleId, role: 'stabilizer', involvement, note });
const AN = (muscleId: string, involvement = 0.5, note?: string): RoleEntry => ({ muscleId, role: 'antagonist', involvement, note });

export const MOVEMENTS: Movement[] = [
  {
    id: 'elbow_flexion', kind: 'movement', jointId: 'elbow', plane: 'sagittal',
    hebrewName: 'כפיפת מרפק', englishName: 'Elbow flexion', latinName: 'Flexio cubiti', aliases: ['כיפוף מרפק', 'כפיפה מרפק'],
    description: 'קירוב האמה אל הזרוע.',
    roles: [A('brachialis', 1), A('biceps_brachii', 0.95), S('brachioradialis', 0.7), ST('deltoid', 0.35, 'ייצוב הכתף'), ST('supraspinatus', 0.3), AN('triceps_brachii')],
    clipId: 'clip.elbow_flexion',
  },
  {
    id: 'elbow_extension', kind: 'movement', jointId: 'elbow', plane: 'sagittal',
    hebrewName: 'יישור מרפק', englishName: 'Elbow extension', latinName: 'Extensio cubiti', aliases: ['פשיטת מרפק'],
    description: 'הרחקת האמה מהזרוע עד ליישור.',
    roles: [A('triceps_brachii', 1), ST('deltoid', 0.35), ST('supraspinatus', 0.3), AN('biceps_brachii'), AN('brachialis'), AN('brachioradialis', 0.4)],
    modelGaps: 'השריר Anconeus (מסייע קטן) עדיין לא קיים במודל.',
    clipId: 'clip.elbow_extension',
  },
  {
    id: 'forearm_supination', kind: 'movement', jointId: 'radioulnar', plane: 'transverse',
    hebrewName: 'סופינציה', englishName: 'Forearm supination', latinName: 'Supinatio', aliases: ['סיבוב אמה החוצה'],
    description: 'סיבוב האמה כך שכף היד פונה קדימה/למעלה.',
    roles: [A('biceps_brachii', 1, 'חזק במיוחד כשהמרפק כפוף'), { muscleId: 'brachioradialis', role: 'synergist', involvement: 0.3, certainty: 'debated', note: 'רק מפרונציה למצב ביניים; שנוי במחלוקת' }],
    modelGaps: 'השריר Supinator ושרירי הפרונציה (האנטגוניסטים) עדיין לא קיימים במודל.',
    clipId: 'clip.forearm_supination',
  },
  {
    id: 'shoulder_flexion', kind: 'movement', jointId: 'shoulder', plane: 'sagittal',
    hebrewName: 'כפיפת כתף', englishName: 'Shoulder flexion', latinName: 'Flexio humeri', aliases: ['הרמת יד קדימה'],
    description: 'הרמת הזרוע קדימה.',
    roles: [A('deltoid', 1, 'החלק הקדמי'), A('pectoralis_major', 0.6, 'הראש הבריחי'), S('biceps_brachii', 0.3), S('trapezius', 0.5, 'סיבוב השכמה מעלה'), ST('supraspinatus', 0.5), AN('latissimus_dorsi', 0.5), AN('triceps_brachii', 0.2, 'הראש הארוך')],
    clipId: 'clip.shoulder_flexion',
  },
  {
    id: 'shoulder_extension', kind: 'movement', jointId: 'shoulder', plane: 'sagittal',
    hebrewName: 'יישור כתף', englishName: 'Shoulder extension', latinName: 'Extensio humeri', aliases: ['פשיטת כתף'],
    description: 'הורדת הזרוע אחורה.',
    roles: [A('latissimus_dorsi', 1), S('deltoid', 0.6, 'החלק האחורי'), S('triceps_brachii', 0.4, 'הראש הארוך'), ST('trapezius', 0.4), AN('pectoralis_major', 0.4, 'הראש הבריחי')],
    clipId: 'clip.shoulder_extension',
  },
  {
    id: 'shoulder_abduction', kind: 'movement', jointId: 'shoulder', plane: 'frontal',
    hebrewName: 'הרחקת כתף', englishName: 'Shoulder abduction', latinName: 'Abductio humeri', aliases: ['הרמת יד לצד', 'הרחקה כתף'],
    description: 'הרמת הזרוע לצד.',
    roles: [A('deltoid', 1, 'החלק האמצעי'), A('supraspinatus', 0.7), S('trapezius', 0.6, 'סיבוב השכמה מעלה'), AN('latissimus_dorsi', 0.5), AN('pectoralis_major', 0.4)],
    modelGaps: 'שרירי השרוול המסובב האחרים (מייצבים) ו־Serratus anterior עדיין לא קיימים במודל.',
    clipId: 'clip.shoulder_abduction',
  },
  {
    id: 'trunk_flexion', kind: 'movement', jointId: 'spine', plane: 'sagittal',
    hebrewName: 'כפיפת הגו', englishName: 'Trunk flexion', latinName: 'Flexio trunci', aliases: ['כפיפת בטן', 'כפיפת גב'],
    description: 'כפיפת עמוד השדרה קדימה.',
    roles: [A('rectus_abdominis', 1), S('iliopsoas', 0.3, 'בעיקר כשהתנועה ממשיכה לכפיפת ירך'), AN('erector_spinae', 0.5)],
    modelGaps: 'השרירים האלכסוניים של הבטן עדיין לא קיימים במודל.',
    clipId: 'clip.trunk_flexion',
  },
  {
    id: 'trunk_extension', kind: 'movement', jointId: 'spine', plane: 'sagittal',
    hebrewName: 'יישור הגו', englishName: 'Trunk extension', latinName: 'Extensio trunci', aliases: ['פשיטת גב'],
    description: 'יישור עמוד השדרה אחורה.',
    roles: [A('erector_spinae', 1), S('gluteus_maximus', 0.4, 'יישור הירך המצטרף'), AN('rectus_abdominis', 0.5)],
    clipId: 'clip.trunk_extension',
  },
  {
    id: 'hip_flexion', kind: 'movement', jointId: 'hip', plane: 'sagittal',
    hebrewName: 'כפיפת ירך', englishName: 'Hip flexion', latinName: 'Flexio coxae', aliases: ['הרמת ברך'],
    description: 'הרמת הירך קדימה.',
    roles: [A('iliopsoas', 1), A('rectus_femoris', 0.7), S('sartorius', 0.4), ST('rectus_abdominis', 0.5, 'ייצוב האגן'), AN('gluteus_maximus', 0.5), AN('biceps_femoris', 0.4), AN('semitendinosus', 0.4)],
    clipId: 'clip.hip_flexion',
  },
  {
    id: 'hip_extension', kind: 'movement', jointId: 'hip', plane: 'sagittal',
    hebrewName: 'יישור ירך', englishName: 'Hip extension', latinName: 'Extensio coxae', aliases: ['פשיטת ירך'],
    description: 'הובלת הירך אחורה.',
    roles: [A('gluteus_maximus', 1), A('biceps_femoris', 0.7), A('semitendinosus', 0.7), ST('erector_spinae', 0.5), ST('gluteus_medius', 0.4), AN('iliopsoas', 0.5), AN('rectus_femoris', 0.4)],
    clipId: 'clip.hip_extension',
  },
  {
    id: 'hip_abduction', kind: 'movement', jointId: 'hip', plane: 'frontal',
    hebrewName: 'הרחקת ירך', englishName: 'Hip abduction', latinName: 'Abductio coxae', aliases: ['הרחקה ירך', 'הרמת רגל לצד'],
    description: 'הרמת הרגל לצד.',
    roles: [A('gluteus_medius', 1), S('gluteus_maximus', 0.4, 'סיבים עליונים'), S('sartorius', 0.2), ST('rectus_abdominis', 0.3), ST('erector_spinae', 0.3)],
    modelGaps: 'שרירי הקירוב של הירך (האנטגוניסטים), Gluteus minimus ו־TFL עדיין לא קיימים במודל.',
    clipId: 'clip.hip_abduction',
  },
  {
    id: 'knee_extension', kind: 'movement', jointId: 'knee', plane: 'sagittal',
    hebrewName: 'יישור ברך', englishName: 'Knee extension', latinName: 'Extensio genus', aliases: ['פשיטת ברך'],
    description: 'יישור השוק מול הירך.',
    roles: [A('vastus_lateralis', 1), A('vastus_medialis', 1), A('vastus_intermedius', 1), A('rectus_femoris', 0.85), AN('biceps_femoris', 0.5), AN('semitendinosus', 0.5), AN('gastrocnemius', 0.3), AN('sartorius', 0.2)],
    clipId: 'clip.knee_extension',
  },
  {
    id: 'knee_flexion', kind: 'movement', jointId: 'knee', plane: 'sagittal',
    hebrewName: 'כפיפת ברך', englishName: 'Knee flexion', latinName: 'Flexio genus', aliases: ['כיפוף ברך'],
    description: 'כפיפת השוק לאחור.',
    roles: [A('biceps_femoris', 1), A('semitendinosus', 1), S('gastrocnemius', 0.5), S('sartorius', 0.3), AN('vastus_lateralis', 0.5), AN('vastus_medialis', 0.5), AN('vastus_intermedius', 0.5), AN('rectus_femoris', 0.5)],
    modelGaps: 'Semimembranosus, Gracilis ו־Popliteus עדיין לא קיימים במודל.',
    clipId: 'clip.knee_flexion',
  },
  {
    id: 'ankle_plantarflexion', kind: 'movement', jointId: 'ankle', plane: 'sagittal',
    hebrewName: 'כפיפה כפית', englishName: 'Ankle plantarflexion', latinName: 'Flexio plantaris', aliases: ['פלנטר פלקשן', 'עמידה על בהונות', 'plantarflexion'],
    description: 'הפניית כף הרגל כלפי מטה.',
    roles: [A('gastrocnemius', 1), A('soleus', 1), AN('tibialis_anterior', 0.5)],
    clipId: 'clip.ankle_plantarflexion',
  },
  {
    id: 'ankle_dorsiflexion', kind: 'movement', jointId: 'ankle', plane: 'sagittal',
    hebrewName: 'כפיפה גבית', englishName: 'Ankle dorsiflexion', latinName: 'Flexio dorsalis', aliases: ['דורסי פלקשן', 'dorsiflexion'],
    description: 'הרמת כף הרגל כלפי מעלה.',
    roles: [A('tibialis_anterior', 1), AN('gastrocnemius', 0.5), AN('soleus', 0.5)],
    modelGaps: 'Extensor digitorum longus ו־Extensor hallucis longus עדיין לא קיימים במודל.',
    clipId: 'clip.ankle_dorsiflexion',
  },
];
