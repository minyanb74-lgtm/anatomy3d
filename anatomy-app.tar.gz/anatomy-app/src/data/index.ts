/**
 * DataRepository – the single entry point to anatomical data.
 * Builds id indexes and derived (reverse) relations once, so adding hundreds of structures
 * only requires adding records to the data files.
 */
import { MUSCLES, MUSCLE_GROUPS } from './muscles';
import { BONES, LIGAMENTS } from './bones';
import { NERVES, VESSELS } from './nerves';
import { JOINTS } from './joints';
import { MOVEMENTS } from './movements';
import { EXERCISES } from './exercises';
import { CLIPS } from './kinematics';
import type { Bone, Clip, Exercise, Id, Joint, Ligament, Movement, Muscle, Nerve, Role, RoleEntry, Vessel } from './types';

export * from './types';
export { LAYERS, REGION_NAMES, ROLE_META } from './layers';
export { MUSCLE_GROUPS };

export type Entity = Muscle | Bone | Nerve | Vessel | Ligament | Joint | Movement | Exercise;
export type EntityKind = Entity['kind'];

const byId = <T extends { id: Id }>(arr: T[]) => new Map(arr.map((x) => [x.id, x]));

class DataRepository {
  readonly muscles = MUSCLES;
  readonly bones = BONES;
  readonly ligaments = LIGAMENTS;
  readonly nerves = NERVES;
  readonly vessels = VESSELS;
  readonly joints = JOINTS;
  readonly movements = MOVEMENTS;
  readonly exercises = EXERCISES;
  readonly clips = CLIPS;
  readonly groups = MUSCLE_GROUPS;

  private muscleMap = byId(MUSCLES);
  private boneMap = byId(BONES);
  private ligamentMap = byId(LIGAMENTS);
  private nerveMap = byId(NERVES);
  private vesselMap = byId(VESSELS);
  private jointMap = byId(JOINTS);
  private movementMap = byId(MOVEMENTS);
  private exerciseMap = byId(EXERCISES);
  private clipMap = byId(CLIPS);
  private refMap = new Map<string, Entity>();

  constructor() {
    for (const e of [...MUSCLES, ...BONES, ...LIGAMENTS, ...NERVES, ...VESSELS] as (Entity & { modelReference: string })[]) {
      this.refMap.set(e.modelReference, e);
    }
    this.validate();
  }

  muscle = (id: Id) => this.muscleMap.get(id);
  bone = (id: Id) => this.boneMap.get(id);
  ligament = (id: Id) => this.ligamentMap.get(id);
  nerve = (id: Id) => this.nerveMap.get(id);
  vessel = (id: Id) => this.vesselMap.get(id);
  joint = (id: Id) => this.jointMap.get(id);
  movement = (id: Id) => this.movementMap.get(id);
  exercise = (id: Id) => this.exerciseMap.get(id);
  clip = (id: Id) => this.clipMap.get(id);

  get(kind: EntityKind, id: Id): Entity | undefined {
    switch (kind) {
      case 'muscle': return this.muscle(id);
      case 'bone': return this.bone(id);
      case 'ligament': return this.ligament(id);
      case 'nerve': return this.nerve(id);
      case 'vessel': return this.vessel(id);
      case 'joint': return this.joint(id);
      case 'movement': return this.movement(id);
      case 'exercise': return this.exercise(id);
    }
  }

  /** Model reference → entity (used by picking). */
  byModelReference = (ref: string) => this.refMap.get(ref);

  /** Movements in which a muscle has any role. */
  movementsForMuscle(muscleId: Id): { movement: Movement; role: RoleEntry }[] {
    const out: { movement: Movement; role: RoleEntry }[] = [];
    for (const m of MOVEMENTS) {
      const r = m.roles.find((x) => x.muscleId === muscleId);
      if (r) out.push({ movement: m, role: r });
    }
    return out.sort((a, b) => order(a.role.role) - order(b.role.role) || b.role.involvement - a.role.involvement);
  }

  exercisesForMuscle(muscleId: Id): { exercise: Exercise; role: RoleEntry }[] {
    const out: { exercise: Exercise; role: RoleEntry }[] = [];
    for (const e of EXERCISES) {
      const r = e.roles.find((x) => x.muscleId === muscleId);
      if (r) out.push({ exercise: e, role: r });
    }
    return out.sort((a, b) => order(a.role.role) - order(b.role.role) || b.role.involvement - a.role.involvement);
  }

  /** Muscles attached (origin or insertion) to a bone. */
  musclesForBone(boneId: Id): { muscle: Muscle; via: ('origin' | 'insertion')[] }[] {
    const out: { muscle: Muscle; via: ('origin' | 'insertion')[] }[] = [];
    for (const m of MUSCLES) {
      const via: ('origin' | 'insertion')[] = [];
      if (m.originBones.includes(boneId)) via.push('origin');
      if (m.insertionBones.includes(boneId)) via.push('insertion');
      if (via.length) out.push({ muscle: m, via });
    }
    return out;
  }

  musclesForNerve(nerveId: Id): Muscle[] {
    return MUSCLES.filter((m) => m.innervation.some((i) => i.nerveId === nerveId));
  }

  musclesInGroup(groupId: Id): Muscle[] {
    return MUSCLES.filter((m) => m.groups?.includes(groupId));
  }

  movementsForJoint(jointId: Id): Movement[] {
    return MOVEMENTS.filter((m) => m.jointId === jointId);
  }

  /** Group role entries by role, sorted by involvement. */
  groupRoles(roles: RoleEntry[]): Record<Role, RoleEntry[]> {
    const g: Record<Role, RoleEntry[]> = { agonist: [], synergist: [], stabilizer: [], antagonist: [] };
    for (const r of roles) g[r.role].push(r);
    for (const k of Object.keys(g) as Role[]) g[k].sort((a, b) => b.involvement - a.involvement);
    return g;
  }

  /** Dev-time integrity check: every reference points to an existing record. */
  private validate() {
    if (!import.meta.env.DEV) return;
    const problems: string[] = [];
    for (const m of MUSCLES) {
      for (const id of [...m.agonists, ...m.synergists, ...m.stabilizers, ...m.antagonists]) if (!this.muscleMap.has(id)) problems.push(`${m.id} → muscle ${id}`);
      for (const id of [...m.originBones, ...m.insertionBones]) if (!this.boneMap.has(id)) problems.push(`${m.id} → bone ${id}`);
      for (const i of m.innervation) if (!this.nerveMap.has(i.nerveId)) problems.push(`${m.id} → nerve ${i.nerveId}`);
      for (const j of m.relatedJoints) if (!this.jointMap.has(j)) problems.push(`${m.id} → joint ${j}`);
    }
    for (const x of [...MOVEMENTS, ...EXERCISES]) {
      for (const r of x.roles) if (!this.muscleMap.has(r.muscleId)) problems.push(`${x.id} → muscle ${r.muscleId}`);
      if (!this.clipMap.has(x.clipId)) problems.push(`${x.id} → clip ${x.clipId}`);
    }
    if (problems.length) console.warn('[data] broken references:', problems);
  }
}

const order = (r: Role) => ({ agonist: 0, synergist: 1, stabilizer: 2, antagonist: 3 })[r];

export const data = new DataRepository();
export type { Clip };
