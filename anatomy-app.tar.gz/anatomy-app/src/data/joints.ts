/**
 * Joints. `typicalRange` values are *estimates* of normal active ROM;
 * different reference sources (AAOS, AMA etc.) quote slightly different numbers.
 */
import type { Joint } from './types';

export const JOINTS: Joint[] = [
  {
    id: 'shoulder', kind: 'joint', hebrewName: 'מפרק הכתף', englishName: 'Shoulder (glenohumeral) joint', latinName: 'Articulatio humeri',
    aliases: ['כתף', 'shoulder'], jointType: 'מפרק כדור ומכתש', bones: ['humerus', 'scapula'],
    summary: 'המפרק הנייד ביותר בגוף; היציבות נשענת בעיקר על השרירים.',
    motions: [
      { movementId: 'shoulder_flexion', hebrewLabel: 'כפיפה', dof: 'shoulderFlex', sign: 1, typicalRange: [0, 180] },
      { movementId: 'shoulder_extension', hebrewLabel: 'יישור', dof: 'shoulderFlex', sign: -1, typicalRange: [0, 60] },
      { movementId: 'shoulder_abduction', hebrewLabel: 'הרחקה', dof: 'shoulderAbd', sign: 1, typicalRange: [0, 180] },
    ],
  },
  {
    id: 'scapulothoracic', kind: 'joint', hebrewName: 'החיבור השכמתי־חזי', englishName: 'Scapulothoracic articulation', latinName: 'Articulatio scapulothoracica',
    aliases: ['שכמה'], jointType: 'חיבור תפקודי (לא מפרק אמיתי)', bones: ['scapula', 'ribs'],
    summary: 'החלקת השכמה על בית החזה; תורמת כשליש מטווח הרמת הזרוע.',
    motions: [],
  },
  {
    id: 'elbow', kind: 'joint', hebrewName: 'מפרק המרפק', englishName: 'Elbow joint', latinName: 'Articulatio cubiti',
    aliases: ['מרפק', 'elbow'], jointType: 'מפרק ציר', bones: ['humerus', 'ulna', 'radius'],
    summary: 'מפרק ציר בין הזרוע לאמה.',
    motions: [
      { movementId: 'elbow_flexion', hebrewLabel: 'כפיפה', dof: 'elbowFlex', sign: 1, typicalRange: [0, 145] },
      { movementId: 'elbow_extension', hebrewLabel: 'יישור', dof: 'elbowFlex', sign: 1, typicalRange: [0, 145], reverse: true },
    ],
  },
  {
    id: 'radioulnar', kind: 'joint', hebrewName: 'מפרקי החישור־גומד', englishName: 'Radioulnar joints', latinName: 'Articulationes radioulnares',
    aliases: ['אמה', 'סופינציה', 'פרונציה'], jointType: 'מפרק סיבוב', bones: ['radius', 'ulna'],
    summary: 'מאפשרים פרונציה וסופינציה של האמה.',
    motions: [{ movementId: 'forearm_supination', hebrewLabel: 'סופינציה', dof: 'forearmSup', sign: 1, typicalRange: [0, 80] }],
  },
  {
    id: 'spine', kind: 'joint', hebrewName: 'מפרקי עמוד השדרה', englishName: 'Spinal joints', latinName: 'Articulationes columnae vertebralis',
    aliases: ['גו', 'עמוד שדרה', 'trunk'], jointType: 'סדרת מפרקים בין־חולייתיים', bones: ['vertebrae', 'sacrum'],
    summary: 'תנועת הגו היא סכום תנועות קטנות בין חוליות רבות.',
    motions: [
      { movementId: 'trunk_flexion', hebrewLabel: 'כפיפת הגו', dof: 'trunkFlex', sign: 1, typicalRange: [0, 80] },
      { movementId: 'trunk_extension', hebrewLabel: 'יישור הגו', dof: 'trunkFlex', sign: -1, typicalRange: [0, 25] },
    ],
  },
  {
    id: 'hip', kind: 'joint', hebrewName: 'מפרק הירך', englishName: 'Hip joint', latinName: 'Articulatio coxae',
    aliases: ['ירך', 'hip'], jointType: 'מפרק כדור ומכתש', bones: ['pelvis', 'femur'],
    summary: 'מפרק עמוק ויציב הנושא את משקל הגוף.',
    motions: [
      { movementId: 'hip_flexion', hebrewLabel: 'כפיפה', dof: 'hipFlex', sign: 1, typicalRange: [0, 120] },
      { movementId: 'hip_extension', hebrewLabel: 'יישור', dof: 'hipFlex', sign: -1, typicalRange: [0, 20] },
      { movementId: 'hip_abduction', hebrewLabel: 'הרחקה', dof: 'hipAbd', sign: 1, typicalRange: [0, 45] },
    ],
  },
  {
    id: 'knee', kind: 'joint', hebrewName: 'מפרק הברך', englishName: 'Knee joint', latinName: 'Articulatio genus',
    aliases: ['ברך', 'knee'], jointType: 'מפרק ציר (עם מעט סיבוב)', bones: ['femur', 'tibia', 'patella'],
    summary: 'המפרק הגדול בגוף; נשען מאוד על רצועות ומניסקוסים.',
    motions: [
      { movementId: 'knee_flexion', hebrewLabel: 'כפיפה', dof: 'kneeFlex', sign: 1, typicalRange: [0, 135] },
      { movementId: 'knee_extension', hebrewLabel: 'יישור', dof: 'kneeFlex', sign: 1, typicalRange: [0, 135], reverse: true },
    ],
  },
  {
    id: 'ankle', kind: 'joint', hebrewName: 'מפרק הקרסול', englishName: 'Ankle (talocrural) joint', latinName: 'Articulatio talocruralis',
    aliases: ['קרסול', 'ankle'], jointType: 'מפרק ציר', bones: ['tibia', 'fibula', 'foot'],
    summary: 'מאפשר כפיפה כפית וגבית של כף הרגל.',
    motions: [
      { movementId: 'ankle_plantarflexion', hebrewLabel: 'כפיפה כפית', dof: 'anklePlantar', sign: 1, typicalRange: [0, 50] },
      { movementId: 'ankle_dorsiflexion', hebrewLabel: 'כפיפה גבית', dof: 'anklePlantar', sign: -1, typicalRange: [0, 20] },
    ],
  },
];
