/**
 * Exercise library. Roles describe the concentric (lifting) phase.
 * Ranges are approximate (estimate) and depend on technique, equipment and the individual.
 */
import type { Exercise, RoleEntry } from './types';

const A = (muscleId: string, involvement = 1, note?: string): RoleEntry => ({ muscleId, role: 'agonist', involvement, note });
const S = (muscleId: string, involvement = 0.6, note?: string): RoleEntry => ({ muscleId, role: 'synergist', involvement, note });
const ST = (muscleId: string, involvement = 0.5, note?: string): RoleEntry => ({ muscleId, role: 'stabilizer', involvement, note });
const AN = (muscleId: string, involvement = 0.4, note?: string): RoleEntry => ({ muscleId, role: 'antagonist', involvement, note });

const QUADS = (inv = 1): RoleEntry[] => [A('vastus_lateralis', inv), A('vastus_medialis', inv), A('vastus_intermedius', inv), A('rectus_femoris', inv * 0.6, 'דו־מפרקי – תרומה מוגבלת כשהירך כפופה')];
const PHASE = 'התפקידים מתארים את שלב ההרמה (הכיווץ המקצר).';

export const EXERCISES: Exercise[] = [
  {
    id: 'squat', kind: 'exercise', category: 'lower', hebrewName: 'סקוואט', englishName: 'Squat', latinName: 'Squat', aliases: ['כפיפות ברכיים', 'סקווט'],
    joints: [
      { jointId: 'hip', action: 'כפיפה ← יישור', range: 'כ־0°–110°' },
      { jointId: 'knee', action: 'כפיפה ← יישור', range: 'כ־0°–120°' },
      { jointId: 'ankle', action: 'כפיפה גבית ← חזרה', range: 'כ־0°–30° גבית' },
    ],
    roles: [...QUADS(1), A('gluteus_maximus', 1), S('biceps_femoris', 0.4), S('semitendinosus', 0.4), S('soleus', 0.4), ST('erector_spinae', 0.7), ST('rectus_abdominis', 0.5), ST('gluteus_medius', 0.5), AN('iliopsoas', 0.3), AN('tibialis_anterior', 0.2)],
    phaseNote: PHASE, movementIds: ['hip_extension', 'knee_extension', 'ankle_plantarflexion'],
    modelGaps: 'שרירי הקירוב של הירך (Adductor magnus) – מסייע חשוב – עדיין לא קיימים במודל.',
    clipId: 'clip.squat',
  },
  {
    id: 'deadlift', kind: 'exercise', category: 'full', hebrewName: 'דדליפט', englishName: 'Deadlift', latinName: 'Deadlift', aliases: ['הרמה מתה', 'דד ליפט'],
    joints: [
      { jointId: 'hip', action: 'יישור', range: 'כ־90° ← 0°' },
      { jointId: 'knee', action: 'יישור', range: 'כ־60° ← 0°' },
      { jointId: 'spine', action: 'ייצוב איזומטרי', range: '—' },
    ],
    roles: [A('gluteus_maximus', 1), A('biceps_femoris', 0.8), A('semitendinosus', 0.8), S('vastus_lateralis', 0.6), S('vastus_medialis', 0.6), S('vastus_intermedius', 0.6), ST('erector_spinae', 1, 'עבודה איזומטרית חזקה'), ST('trapezius', 0.6), ST('latissimus_dorsi', 0.5), ST('rectus_abdominis', 0.5), AN('iliopsoas', 0.3)],
    phaseNote: PHASE, movementIds: ['hip_extension', 'knee_extension', 'trunk_extension'],
    modelGaps: 'שרירי האמה (אחיזה) ו־Adductor magnus עדיין לא קיימים במודל.',
    clipId: 'clip.deadlift',
  },
  {
    id: 'bench_press', kind: 'exercise', category: 'upper-push', hebrewName: 'לחיצת חזה', englishName: 'Bench Press', latinName: 'Bench press', aliases: ['בנץ׳', 'בנץ', 'לחיצת חזה בשכיבה'],
    joints: [
      { jointId: 'shoulder', action: 'קירוב אופקי / כפיפה', range: 'כ־70°–90°' },
      { jointId: 'elbow', action: 'יישור', range: 'כ־90° ← 0°' },
    ],
    roles: [A('pectoralis_major', 1), S('deltoid', 0.6, 'החלק הקדמי'), S('triceps_brachii', 0.7), ST('supraspinatus', 0.4), ST('trapezius', 0.4, 'ייצוב השכמות'), ST('latissimus_dorsi', 0.3), ST('biceps_brachii', 0.2)],
    phaseNote: PHASE + ' האנימציה מציגה את התנועה בשכיבה ללא ספסל.', movementIds: ['shoulder_flexion', 'elbow_extension'],
    modelGaps: 'האנטגוניסטים העיקריים (Rhomboids, Posterior rotator cuff) ו־Serratus anterior עדיין לא קיימים במודל.',
    clipId: 'clip.bench_press',
  },
  {
    id: 'overhead_press', kind: 'exercise', category: 'upper-push', hebrewName: 'לחיצת כתפיים בעמידה', englishName: 'Overhead Press', latinName: 'Overhead press', aliases: ['OHP', 'מיליטרי פרס', 'military press'],
    joints: [
      { jointId: 'shoulder', action: 'כפיפה / הרחקה', range: 'כ־30° ← 170°' },
      { jointId: 'elbow', action: 'יישור', range: 'כ־140° ← 0°' },
      { jointId: 'scapulothoracic', action: 'סיבוב השכמה מעלה', range: '—' },
    ],
    roles: [A('deltoid', 1), S('triceps_brachii', 0.7), S('trapezius', 0.6, 'סיבוב השכמה מעלה'), S('supraspinatus', 0.4), S('pectoralis_major', 0.3, 'הראש הבריחי בתחילת התנועה'), ST('rectus_abdominis', 0.5), ST('erector_spinae', 0.5), ST('gluteus_maximus', 0.3), AN('latissimus_dorsi', 0.3)],
    phaseNote: PHASE, movementIds: ['shoulder_flexion', 'shoulder_abduction', 'elbow_extension'],
    clipId: 'clip.overhead_press',
  },
  {
    id: 'pull_up', kind: 'exercise', category: 'upper-pull', hebrewName: 'מתח', englishName: 'Pull-up', latinName: 'Pull-up', aliases: ['עליות מתח', 'pullup', 'chin up'],
    joints: [
      { jointId: 'shoulder', action: 'קירוב / יישור', range: 'כ־170° ← 60°' },
      { jointId: 'elbow', action: 'כפיפה', range: 'כ־10° ← 130°' },
    ],
    roles: [A('latissimus_dorsi', 1), S('biceps_brachii', 0.7), S('brachialis', 0.7), S('brachioradialis', 0.5), S('trapezius', 0.5, 'חלק תחתון'), S('pectoralis_major', 0.3, 'הראש החזי־צלעי'), ST('rectus_abdominis', 0.5), AN('deltoid', 0.3, 'החלק האמצעי'), AN('supraspinatus', 0.2)],
    phaseNote: PHASE, movementIds: ['shoulder_extension', 'elbow_flexion'],
    modelGaps: 'Teres major, Rhomboids ושרירי האחיזה עדיין לא קיימים במודל.',
    clipId: 'clip.pull_up',
  },
  {
    id: 'push_up', kind: 'exercise', category: 'upper-push', hebrewName: 'שכיבת סמיכה', englishName: 'Push-up', latinName: 'Push-up', aliases: ['שכיבות סמיכה', 'pushup'],
    joints: [
      { jointId: 'shoulder', action: 'קירוב אופקי / כפיפה', range: 'כ־60°–90°' },
      { jointId: 'elbow', action: 'יישור', range: 'כ־90° ← 0°' },
    ],
    roles: [A('pectoralis_major', 1), S('triceps_brachii', 0.7), S('deltoid', 0.5, 'החלק הקדמי'), ST('rectus_abdominis', 0.7), ST('erector_spinae', 0.4), ST('gluteus_maximus', 0.3), ST('supraspinatus', 0.3), ST('trapezius', 0.3)],
    phaseNote: PHASE, movementIds: ['elbow_extension', 'shoulder_flexion'],
    modelGaps: 'Serratus anterior – מייצב מרכזי – עדיין לא קיים במודל.',
    clipId: 'clip.push_up',
  },
  {
    id: 'barbell_row', kind: 'exercise', category: 'upper-pull', hebrewName: 'חתירה במוט', englishName: 'Barbell Row', latinName: 'Barbell row', aliases: ['חתירה', 'row'],
    joints: [
      { jointId: 'shoulder', action: 'יישור', range: 'כ־60° ← -20°' },
      { jointId: 'elbow', action: 'כפיפה', range: 'כ־0° ← 100°' },
      { jointId: 'hip', action: 'החזקה בכפיפה (איזומטרי)', range: 'כ־60°–80°' },
    ],
    roles: [A('latissimus_dorsi', 1), A('trapezius', 0.8, 'חלק אמצעי – קירוב השכמות'), S('deltoid', 0.6, 'החלק האחורי'), S('biceps_brachii', 0.5), S('brachialis', 0.5), S('brachioradialis', 0.4), ST('erector_spinae', 0.8), ST('gluteus_maximus', 0.4), ST('biceps_femoris', 0.4), ST('semitendinosus', 0.4), AN('pectoralis_major', 0.3)],
    phaseNote: PHASE, movementIds: ['shoulder_extension', 'elbow_flexion'],
    modelGaps: 'Rhomboids ו־Teres major עדיין לא קיימים במודל.',
    clipId: 'clip.barbell_row',
  },
  {
    id: 'biceps_curl', kind: 'exercise', category: 'arms', hebrewName: 'כפיפת מרפקים (בייספס)', englishName: 'Biceps Curl', latinName: 'Biceps curl', aliases: ['כפיפת מרפקים', 'בייספס קרל', 'curl'],
    joints: [{ jointId: 'elbow', action: 'כפיפה', range: 'כ־0° ← 140°' }],
    roles: [A('biceps_brachii', 1), A('brachialis', 1), S('brachioradialis', 0.6), ST('deltoid', 0.3, 'החלק הקדמי'), ST('trapezius', 0.3), ST('rectus_abdominis', 0.2), AN('triceps_brachii', 0.4)],
    phaseNote: PHASE, movementIds: ['elbow_flexion', 'forearm_supination'],
    clipId: 'clip.biceps_curl',
  },
  {
    id: 'triceps_extension', kind: 'exercise', category: 'arms', hebrewName: 'פשיטת מרפקים מעל הראש', englishName: 'Triceps Extension', latinName: 'Overhead triceps extension', aliases: ['טרייספס', 'פשיטת מרפקים', 'פרנץ׳ פרס'],
    joints: [
      { jointId: 'elbow', action: 'יישור', range: 'כ־150° ← 0°' },
      { jointId: 'shoulder', action: 'החזקה בכפיפה', range: 'כ־170°' },
    ],
    roles: [A('triceps_brachii', 1, 'הראש הארוך במתיחה'), ST('deltoid', 0.4), ST('supraspinatus', 0.3), ST('rectus_abdominis', 0.3), AN('biceps_brachii', 0.4), AN('brachialis', 0.4)],
    phaseNote: PHASE, movementIds: ['elbow_extension'],
    clipId: 'clip.triceps_extension',
  },
  {
    id: 'leg_extension', kind: 'exercise', category: 'lower', hebrewName: 'פשיטת ברכיים במכונה', englishName: 'Leg Extension', latinName: 'Leg extension', aliases: ['פשיטת ברכיים', 'לג אקסטנשן'],
    joints: [
      { jointId: 'knee', action: 'יישור', range: 'כ־90° ← 0°' },
      { jointId: 'hip', action: 'החזקה בכפיפה (ישיבה)', range: 'כ־90°' },
    ],
    roles: [...QUADS(1), AN('biceps_femoris', 0.3), AN('semitendinosus', 0.3)],
    phaseNote: PHASE, movementIds: ['knee_extension'],
    clipId: 'clip.leg_extension',
  },
  {
    id: 'leg_curl', kind: 'exercise', category: 'lower', hebrewName: 'כפיפת ברכיים במכונה', englishName: 'Leg Curl', latinName: 'Leg curl', aliases: ['כפיפת ברכיים', 'לג קרל'],
    joints: [{ jointId: 'knee', action: 'כפיפה', range: 'כ־0° ← 110°' }],
    roles: [A('biceps_femoris', 1), A('semitendinosus', 1), S('gastrocnemius', 0.5), S('sartorius', 0.3), ST('gluteus_maximus', 0.2), AN('vastus_lateralis', 0.3), AN('vastus_medialis', 0.3), AN('vastus_intermedius', 0.3), AN('rectus_femoris', 0.3)],
    phaseNote: PHASE + ' האנימציה מציגה גרסה בשכיבה על הבטן.', movementIds: ['knee_flexion'],
    clipId: 'clip.leg_curl',
  },
  {
    id: 'calf_raise', kind: 'exercise', category: 'lower', hebrewName: 'הרמת עקבים', englishName: 'Calf Raise', latinName: 'Calf raise', aliases: ['עמידה על בהונות', 'תאומים'],
    joints: [{ jointId: 'ankle', action: 'כפיפה כפית', range: 'כ־0° ← 40°' }],
    roles: [A('gastrocnemius', 1), A('soleus', 0.9), ST('tibialis_anterior', 0.2, 'שליטה ואיזון'), ST('gluteus_medius', 0.2), AN('tibialis_anterior', 0.3)],
    phaseNote: PHASE, movementIds: ['ankle_plantarflexion'],
    clipId: 'clip.calf_raise',
  },
  {
    id: 'lateral_raise', kind: 'exercise', category: 'upper-push', hebrewName: 'הרחקת כתפיים לצדדים', englishName: 'Lateral Raise', latinName: 'Lateral raise', aliases: ['הרחקה לצדדים', 'לטרל רייז'],
    joints: [{ jointId: 'shoulder', action: 'הרחקה', range: 'כ־0° ← 90°' }],
    roles: [A('deltoid', 1, 'החלק האמצעי'), A('supraspinatus', 0.6), S('trapezius', 0.6), ST('rectus_abdominis', 0.2), AN('latissimus_dorsi', 0.3), AN('pectoralis_major', 0.3)],
    phaseNote: PHASE, movementIds: ['shoulder_abduction'],
    clipId: 'clip.lateral_raise',
  },
  {
    id: 'shoulder_press', kind: 'exercise', category: 'upper-push', hebrewName: 'לחיצת כתפיים בישיבה', englishName: 'Shoulder Press', latinName: 'Seated shoulder press', aliases: ['לחיצת כתפיים', 'שולדר פרס'],
    joints: [
      { jointId: 'shoulder', action: 'הרחקה', range: 'כ־90° ← 170°' },
      { jointId: 'elbow', action: 'יישור', range: 'כ־90° ← 0°' },
    ],
    roles: [A('deltoid', 1), S('triceps_brachii', 0.7), S('trapezius', 0.5), S('supraspinatus', 0.4), ST('rectus_abdominis', 0.2), AN('latissimus_dorsi', 0.3)],
    phaseNote: PHASE + ' בישיבה עם משענת – פחות דרישת ייצוב מהגו לעומת עמידה.', movementIds: ['shoulder_abduction', 'elbow_extension'],
    clipId: 'clip.shoulder_press',
  },
  {
    id: 'lunge', kind: 'exercise', category: 'lower', hebrewName: 'מכרע', englishName: 'Lunge', latinName: 'Lunge', aliases: ['לאנג׳', 'לאנג'],
    joints: [
      { jointId: 'hip', action: 'כפיפה ← יישור (רגל קדמית)', range: 'כ־0°–90°' },
      { jointId: 'knee', action: 'כפיפה ← יישור', range: 'כ־0°–90°' },
      { jointId: 'ankle', action: 'כפיפה גבית', range: 'כ־0°–25°' },
    ],
    roles: [A('gluteus_maximus', 1), ...QUADS(0.9), S('biceps_femoris', 0.4), S('semitendinosus', 0.4), S('soleus', 0.3), ST('gluteus_medius', 0.7, 'ייצוב האגן'), ST('erector_spinae', 0.4), ST('rectus_abdominis', 0.4), AN('iliopsoas', 0.3, 'נמתח ברגל האחורית')],
    phaseNote: PHASE, movementIds: ['hip_extension', 'knee_extension'],
    clipId: 'clip.lunge',
  },
  {
    id: 'leg_press', kind: 'exercise', category: 'lower', hebrewName: 'לחיצת רגליים', englishName: 'Leg Press', latinName: 'Leg press', aliases: ['לג פרס', 'מכונת רגליים'],
    joints: [
      { jointId: 'hip', action: 'יישור', range: 'כ־100° ← 20°' },
      { jointId: 'knee', action: 'יישור', range: 'כ־100° ← 10°' },
    ],
    roles: [...QUADS(1), A('gluteus_maximus', 0.8), S('biceps_femoris', 0.3), S('semitendinosus', 0.3), S('soleus', 0.3), ST('gluteus_medius', 0.3), AN('iliopsoas', 0.3)],
    phaseNote: PHASE + ' הגב נתמך במשענת ולכן דרישת הייצוב מהגו קטנה לעומת סקוואט.', movementIds: ['hip_extension', 'knee_extension'],
    clipId: 'clip.leg_press',
  },
];
