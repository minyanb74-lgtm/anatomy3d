/**
 * Kinematic clips (KnowledgeKind = 'model').
 *
 * These are simplified joint-angle animations for the rig, not motion-capture data.
 * Angles are in anatomical degrees:
 *   +shoulderFlex = flexion, +shoulderAbd = abduction, +elbowFlex = flexion,
 *   +forearmSup = supination (0 = anatomical position), +hipFlex = flexion, +hipAbd = abduction,
 *   +kneeFlex = flexion, +anklePlantar = plantarflexion (negative = dorsiflexion),
 *   +trunkFlex = spinal flexion, +pelvisTilt = whole pelvis pitched forward (hip hinge),
 *   +rootPitch = whole body pitched forward (90 = prone, -90 = supine).
 */
import type { Clip, Keyframe, Pose } from './types';

const SIDED = ['shoulderFlex', 'shoulderAbd', 'elbowFlex', 'forearmSup', 'hipFlex', 'hipAbd', 'kneeFlex', 'anklePlantar'];

/** Expand bilateral keys ("elbowFlex") to both sides; sided keys ("elbowFlexL") are kept. */
export function bi(p: Record<string, number>): Pose {
  const out: Record<string, number> = {};
  for (const [k, v] of Object.entries(p)) {
    if (SIDED.includes(k)) {
      out[k + 'L'] = v;
      out[k + 'R'] = v;
    } else out[k] = v;
  }
  return out as Pose;
}

/** Three-key "there and back" helper: rest → peak → rest. */
const loop = (rest: Record<string, number>, peak: Record<string, number>): Keyframe[] => [
  { t: 0, pose: bi(rest) },
  { t: 0.5, pose: bi({ ...rest, ...peak }) },
  { t: 1, pose: bi(rest) },
];

const c = (id: string, duration: number, keyframes: Keyframe[], opts: Partial<Clip> = {}): Clip => ({
  id, duration, keyframes, grounding: 'feet', focus: 'full', ...opts,
});

export const CLIPS: Clip[] = [
  /* ── joint movements ── */
  c('clip.elbow_flexion', 2.4, loop({}, { elbowFlex: 140 }), { focus: 'arm' }),
  c('clip.elbow_extension', 2.4, loop({ elbowFlex: 140 }, { elbowFlex: 0 }), { focus: 'arm' }),
  c('clip.forearm_supination', 2.4, loop({ elbowFlex: 90, forearmSup: -80 }, { forearmSup: 0 }), { focus: 'arm' }),
  c('clip.shoulder_flexion', 3, loop({}, { shoulderFlex: 170 }), { focus: 'shoulder' }),
  c('clip.shoulder_extension', 2.4, loop({}, { shoulderFlex: -50 }), { focus: 'shoulder' }),
  c('clip.shoulder_abduction', 3, loop({}, { shoulderAbd: 170 }), { focus: 'shoulder' }),
  c('clip.trunk_flexion', 3, loop({}, { trunkFlex: 70 }), { focus: 'trunk' }),
  c('clip.trunk_extension', 2.4, loop({}, { trunkFlex: -25 }), { focus: 'trunk' }),
  c('clip.hip_flexion', 2.6, loop({}, { hipFlexL: 110, kneeFlexL: 90 }), { focus: 'leg' }),
  c('clip.hip_extension', 2.6, loop({ hipFlexL: 60, kneeFlexL: 30 }, { hipFlexL: -15, kneeFlexL: 10 }), { focus: 'leg' }),
  c('clip.hip_abduction', 2.6, loop({}, { hipAbdL: 40 }), { focus: 'leg' }),
  c('clip.knee_extension', 2.4, loop({ hipFlexL: 70, kneeFlexL: 100 }, { kneeFlexL: 0 }), { focus: 'leg' }),
  c('clip.knee_flexion', 2.4, loop({}, { kneeFlexL: 120 }), { focus: 'leg' }),
  c('clip.ankle_plantarflexion', 2.2, loop({ hipFlexL: 30, kneeFlexL: 40 }, { anklePlantarL: 45 }), { focus: 'leg' }),
  c('clip.ankle_dorsiflexion', 2.2, loop({ hipFlexL: 30, kneeFlexL: 40 }, { anklePlantarL: -20 }), { focus: 'leg' }),

  /* ── exercises ── */
  c('clip.squat', 3.2, loop(
    { shoulderAbd: 75, shoulderFlex: 20, elbowFlex: 110 },
    { pelvisTilt: 30, hipFlex: 110, kneeFlex: 115 },
  ), { flatFeet: 'both' }),
  c('clip.deadlift', 3.4, [
    { t: 0, pose: bi({ pelvisTilt: 60, hipFlex: 85, kneeFlex: 55, shoulderFlex: 60 }) },
    { t: 0.5, pose: bi({}) },
    { t: 1, pose: bi({ pelvisTilt: 60, hipFlex: 85, kneeFlex: 55, shoulderFlex: 60 }) },
  ], { flatFeet: 'both' }),
  c('clip.bench_press', 2.8, loop(
    { rootPitch: -90, hipFlex: 80, kneeFlex: 90, shoulderFlex: 15, shoulderAbd: 70, elbowFlex: 90 },
    { shoulderFlex: 90, shoulderAbd: 15, elbowFlex: 0 },
  ), { grounding: 'none', rootHeight: 0.55, focus: 'shoulder' }),
  c('clip.overhead_press', 3, loop(
    { shoulderFlex: 40, shoulderAbd: 30, elbowFlex: 140 },
    { shoulderFlex: 165, shoulderAbd: 10, elbowFlex: 5 },
  ), { focus: 'shoulder' }),
  c('clip.pull_up', 3, loop(
    { shoulderFlex: 170, elbowFlex: 5, kneeFlex: 40, hipFlex: 10 },
    { shoulderFlex: 40, elbowFlex: 130 },
  ), { grounding: 'hands', rootHeight: 2.3, focus: 'shoulder' }),
  c('clip.push_up', 2.6, loop(
    { rootPitch: 75, shoulderFlex: 75, anklePlantar: -60 },
    { rootPitch: 85, shoulderFlex: 35, elbowFlex: 95 },
  ), { focus: 'shoulder' }),
  c('clip.barbell_row', 2.6, loop(
    { pelvisTilt: 55, hipFlex: 75, kneeFlex: 25, shoulderFlex: 55 },
    { shoulderFlex: -5, elbowFlex: 100 },
  ), { flatFeet: 'both' }),
  c('clip.biceps_curl', 2.4, loop({}, { elbowFlex: 140 }), { focus: 'arm' }),
  c('clip.triceps_extension', 2.6, loop({ shoulderFlex: 170, elbowFlex: 150 }, { elbowFlex: 0 }), { focus: 'arm' }),
  c('clip.leg_extension', 2.4, loop(
    { hipFlex: 90, kneeFlex: 90, shoulderFlex: 20, elbowFlex: 30 },
    { kneeFlex: 0 },
  ), { grounding: 'none', rootHeight: 0.6, focus: 'leg' }),
  c('clip.leg_curl', 2.4, loop(
    { rootPitch: 90, shoulderFlex: 160, elbowFlex: 60 },
    { kneeFlex: 110 },
  ), { grounding: 'none', rootHeight: 0.5, focus: 'full' }),
  c('clip.calf_raise', 2, loop({}, { anklePlantar: 35 }), { focus: 'leg' }),
  c('clip.lateral_raise', 2.6, loop({ elbowFlex: 15 }, { shoulderAbd: 85 }), { focus: 'shoulder' }),
  c('clip.shoulder_press', 3, loop(
    { hipFlex: 90, kneeFlex: 90, shoulderFlex: 70, shoulderAbd: 40, elbowFlex: 110 },
    { shoulderFlex: 165, shoulderAbd: 15, elbowFlex: 5 },
  ), { focus: 'shoulder' }),
  c('clip.lunge', 3, loop({}, {
    hipFlexL: 90, kneeFlexL: 90, hipFlexR: -15, kneeFlexR: 95, anklePlantarR: 35,
  }), { flatFeet: 'L' }),
  c('clip.leg_press', 2.8, loop(
    { rootPitch: -45, hipFlex: 100, kneeFlex: 100, shoulderFlex: 15 },
    { hipFlex: 20, kneeFlex: 10 },
  ), { grounding: 'none', rootHeight: 0.7, focus: 'full' }),
];
