/**
 * Data-layer types.
 *
 * The data layer holds *facts* (anatomy, biomechanics) and is completely independent of the UI
 * and of the 3D asset. The link to the 3D model is only `modelReference` – a stable string id
 * that an AssetProvider maps to meshes.
 *
 * Epistemic labelling (requirement #33):
 *  - `Fact`        : a statement with a `certainty` flag and an optional note about variation.
 *  - `kind` on roles/ranges distinguishes anatomy / biomechanics / estimate / model.
 */

export type Id = string;

/** How confident the literature is about a statement. */
export type Certainty = 'established' | 'variable' | 'debated';

/** What sort of knowledge a statement is. */
export type KnowledgeKind = 'anatomy' | 'biomechanics' | 'estimate' | 'model';

export interface Fact {
  text: string;
  certainty?: Certainty; // default 'established'
  note?: string; // e.g. anatomical variation
}

export type LayerId =
  | 'skin'
  | 'fat'
  | 'fascia'
  | 'superficialMuscles'
  | 'deepMuscles'
  | 'tendons'
  | 'ligaments'
  | 'bones'
  | 'nerves'
  | 'vessels';

export type StructureKind = 'muscle' | 'bone' | 'nerve' | 'vessel' | 'ligament' | 'joint';

export type RegionId =
  | 'shoulder'
  | 'arm'
  | 'forearm'
  | 'chest'
  | 'back'
  | 'core'
  | 'hip'
  | 'thigh'
  | 'leg';

export interface Names {
  hebrewName: string;
  englishName: string;
  latinName: string;
  /** Additional search terms: transliterations, slang, abbreviations. */
  aliases?: string[];
}

export interface Muscle extends Names {
  id: Id;
  kind: 'muscle';
  depth: 'superficial' | 'deep';
  region: RegionId;
  groups?: Id[]; // e.g. 'quadriceps'
  origin: Fact[];
  insertion: Fact[];
  innervation: { nerveId: Id; text: string; certainty?: Certainty; note?: string }[];
  primaryActions: Fact[];
  secondaryActions: Fact[];
  /** Bones the muscle attaches to (derived lookups "muscles attached to bone"). */
  originBones: Id[];
  insertionBones: Id[];
  relatedJoints: Id[];
  /** Muscles that typically share its main action (anatomical agonists). */
  agonists: Id[];
  synergists: Id[];
  stabilizers: Id[];
  antagonists: Id[];
  /** Short plain description for "teach me" cards. */
  summary: string;
  location: string;
  modelReference: string;
}

export interface Bone extends Names {
  id: Id;
  kind: 'bone';
  region: RegionId | 'head' | 'trunk' | 'hand' | 'foot';
  summary: string;
  facts: Fact[];
  ligaments: Id[];
  modelReference: string;
}

export interface Ligament extends Names {
  id: Id;
  kind: 'ligament';
  connects: Id[]; // bones
  jointId: Id;
  summary: string;
  modelReference: string;
}

export interface Nerve extends Names {
  id: Id;
  kind: 'nerve';
  roots: string; // e.g. "C5–C6"
  summary: string;
  modelReference: string;
}

export interface Vessel extends Names {
  id: Id;
  kind: 'vessel';
  vesselType: 'artery' | 'vein';
  summary: string;
  modelReference: string;
}

/** A rotational degree of freedom of the rig. */
export type Dof =
  | 'rootPitch'
  | 'pelvisTilt'
  | 'trunkFlex'
  | 'shoulderFlexL' | 'shoulderFlexR'
  | 'shoulderAbdL' | 'shoulderAbdR'
  | 'elbowFlexL' | 'elbowFlexR'
  | 'forearmSupL' | 'forearmSupR'
  | 'hipFlexL' | 'hipFlexR'
  | 'hipAbdL' | 'hipAbdR'
  | 'kneeFlexL' | 'kneeFlexR'
  | 'anklePlantarL' | 'anklePlantarR';

export interface JointMotion {
  /** Movement id that this motion corresponds to. */
  movementId: Id;
  hebrewLabel: string;
  /** Rig degree-of-freedom (left side; right side mirrored by the engine). */
  dof: 'shoulderFlex' | 'shoulderAbd' | 'elbowFlex' | 'forearmSup' | 'hipFlex' | 'hipAbd' | 'kneeFlex' | 'anklePlantar' | 'trunkFlex';
  /** sign applied to the dof value (e.g. extension = negative flexion). */
  sign: 1 | -1;
  /** Typical active range in degrees – an estimate; norms vary between sources. */
  typicalRange: [number, number];
  /** Motion is performed *from* the chosen angle back to neutral (e.g. elbow extension). */
  reverse?: boolean;
}

export interface Joint extends Names {
  id: Id;
  kind: 'joint';
  jointType: string;
  bones: Id[];
  motions: JointMotion[];
  summary: string;
}

export type Role = 'agonist' | 'synergist' | 'stabilizer' | 'antagonist';

export interface RoleEntry {
  muscleId: Id;
  role: Role;
  /** 0..1 – relative involvement. ALWAYS an estimate for visualisation. */
  involvement: number;
  note?: string;
  certainty?: Certainty;
}

export interface Movement extends Names {
  id: Id;
  kind: 'movement';
  jointId: Id;
  plane: 'sagittal' | 'frontal' | 'transverse';
  description: string;
  roles: RoleEntry[];
  /** Gaps in the current model (e.g. relevant muscles that are not modelled yet). */
  modelGaps?: string;
  clipId: Id;
}

export interface ExerciseJoint {
  jointId: Id;
  action: string; // e.g. "כפיפה ← יישור"
  /** Approximate range in degrees – estimate; depends on technique and individual. */
  range: string;
}

export interface Exercise extends Names {
  id: Id;
  kind: 'exercise';
  category: 'lower' | 'upper-push' | 'upper-pull' | 'arms' | 'full';
  joints: ExerciseJoint[];
  roles: RoleEntry[];
  /** What phase the roles describe. */
  phaseNote: string;
  movementIds: Id[];
  modelGaps?: string;
  clipId: Id;
}

/* ───────────── Kinematic clips (model, not anatomy) ───────────── */

export type Pose = Partial<Record<Dof, number>>; // degrees

export interface Keyframe {
  t: number; // 0..1 normalised
  pose: Pose;
}

export type Grounding = 'feet' | 'none' | 'hands';

export interface Clip {
  id: Id;
  duration: number; // seconds at 1x
  keyframes: Keyframe[];
  grounding: Grounding;
  /** Fixed root height (m) when grounding = 'none' | 'hands'. */
  rootHeight?: number;
  /** Keep the feet flat on the floor by solving ankle angle each frame. */
  flatFeet?: 'both' | 'L' | 'R';
  /** Which part of the body the camera should frame. */
  focus: 'arm' | 'shoulder' | 'trunk' | 'leg' | 'full';
}

export type AnyStructure = Muscle | Bone | Nerve | Vessel | Ligament | Joint;
