import { useSyncExternalStore } from 'react';
import { store, type AppState } from '@/logic/store';

/** Subscribe to a slice of the store; re-renders only when the selected value changes (Object.is). */
export function useStore<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(store.subscribe as (cb: () => void) => () => void, () => selector(store.getState()));
}
