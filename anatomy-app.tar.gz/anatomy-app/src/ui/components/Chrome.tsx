/** Screen chrome: top bar, side tools, status chips, bottom navigation, timeline, toast, loader. */
import { useState } from 'react';
import { controller } from '@/logic/controller';
import { SPEEDS } from '@/logic/playback';
import type { Tab } from '@/logic/store';
import type { ViewPreset } from '@/engine/visualState';
import { useStore } from '../hooks/useStore';
import { Icon } from './Common';

export function TopBar() {
  return (
    <div className="topbar">
      <button className="icon-btn" aria-label="תפריט" onClick={() => controller.openModal('menu')}>{Icon.menu}</button>
      <button className="search-pill" onClick={() => controller.openModal('search')} aria-label="חיפוש">
        {Icon.search}
        <span className="ph">חיפוש שריר, תנועה, תרגיל…</span>
      </button>
      <button className="icon-btn" aria-label="הגדרות" onClick={() => controller.openModal('settings')}>{Icon.settings}</button>
    </div>
  );
}

const VIEWS: { id: ViewPreset; label: string }[] = [
  { id: 'front', label: 'קדמי' }, { id: 'back', label: 'אחורי' },
  { id: 'right', label: 'ימין' }, { id: 'left', label: 'שמאל' },
  { id: 'top', label: 'עליון' }, { id: 'bottom', label: 'תחתון' },
  { id: 'threeQuarter', label: '3/4' },
];

export function SideTools() {
  const [open, setOpen] = useState(false);
  return (
    <div className="side-tools">
      <div style={{ position: 'relative' }}>
        <button className={`mini-btn${open ? ' active' : ''}`} onClick={() => setOpen(!open)} aria-expanded={open} aria-label="זוויות צפייה">👁</button>
        {open && (
          <div className="views-pop">
            {VIEWS.map((v) => (
              <button key={v.id} onClick={() => { controller.setView(v.id); setOpen(false); }}>{v.label}</button>
            ))}
          </div>
        )}
      </div>
      <button className="mini-btn" onClick={() => controller.resetCamera()} aria-label="איפוס מצלמה" style={{ padding: 0 }}>
        <span style={{ width: 20, height: 20, display: 'block' }}>{Icon.reset}</span>
      </button>
      <button className="mini-btn" onClick={() => controller.openModal('layers')} aria-label="שכבות">🧬</button>
      <button className="mini-btn" onClick={() => controller.openModal('section')} aria-label="חתך אנטומי">✂️</button>
    </div>
  );
}

export function StatusChips() {
  const hidden = useStore((s) => s.hidden.length);
  const isolated = useStore((s) => s.isolated);
  const highlight = useStore((s) => s.highlight);
  const section = useStore((s) => s.section.enabled);
  const quiz = useStore((s) => !!s.quiz);
  return (
    <div className="fab-row">
      {isolated && <button className="chip accent" onClick={() => controller.exitIsolation()}>✕ יציאה מבידוד</button>}
      {hidden > 0 && <button className="chip" onClick={() => controller.showAll()}>↺ הצג הכול ({hidden})</button>}
      {highlight && !quiz && <button className="chip warn" onClick={() => controller.clearHighlight()}>✕ {highlight.label.length > 26 ? highlight.label.slice(0, 26) + '…' : highlight.label}</button>}
      {section && <button className="chip" onClick={() => controller.openModal('section')}>✂️ חתך פעיל</button>}
    </div>
  );
}

const TABS: { id: Tab; ico: string; label: string }[] = [
  { id: 'home', ico: '🏠', label: 'בית' },
  { id: 'anatomy', ico: '🧬', label: 'אנטומיה' },
  { id: 'movements', ico: '🔄', label: 'תנועות' },
  { id: 'exercises', ico: '🏋️', label: 'תרגילים' },
  { id: 'learn', ico: '🧠', label: 'לימוד' },
];

export function BottomNav() {
  const tab = useStore((s) => s.tab);
  return (
    <nav className="bottom-nav" aria-label="ניווט ראשי">
      {TABS.map((t) => (
        <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => controller.setTab(t.id)} aria-current={tab === t.id ? 'page' : undefined}>
          <span className="ico" aria-hidden>{t.ico}</span>
          {t.label}
        </button>
      ))}
    </nav>
  );
}

export function Timeline() {
  const motion = useStore((s) => s.motion);
  const pb = useStore((s) => s.playback);
  if (!motion) return null;
  const secs = (pb.time * motion.clip.duration).toFixed(1);
  return (
    <div className="timeline">
      <div className="row1">
        <button className="play" onClick={() => controller.setPlaying(!pb.playing)} aria-label={pb.playing ? 'השהה' : 'נגן'}>{pb.playing ? '❚❚' : '▶'}</button>
        <button className="back-btn" style={{ width: 40, height: 40 }} onClick={() => controller.replay()} aria-label="מהתחלה">↺</button>
        <input
          type="range" min={0} max={1000} value={Math.round(pb.time * 1000)} aria-label="ציר זמן"
          onPointerDown={() => controller.setPlaying(false)}
          onChange={(e) => controller.setTime(Number(e.target.value) / 1000)}
        />
        <span className="ttl">{motion.title} · {secs}s</span>
        <button className="back-btn" style={{ width: 40, height: 40 }} onClick={() => controller.stopMotion()} aria-label="סגור תנועה">✕</button>
      </div>
      <div className="speeds">
        {SPEEDS.map((sp) => (
          <button key={sp} className={pb.speed === sp ? 'on' : ''} onClick={() => controller.setSpeed(sp)}>{sp}x</button>
        ))}
      </div>
    </div>
  );
}

export function Toast() {
  const t = useStore((s) => s.toast);
  return t ? <div className="toast" role="status">{t}</div> : null;
}

export function Loader() {
  const ready = useStore((s) => s.ready);
  const p = useStore((s) => s.loadProgress);
  if (ready) return null;
  return (
    <div className="loading">
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 40 }}>🧬</div>
        <div style={{ fontWeight: 700 }}>טוען מודל תלת־ממדי…</div>
        <div className="bar"><i style={{ width: `${Math.round(p * 100)}%` }} /></div>
      </div>
    </div>
  );
}
