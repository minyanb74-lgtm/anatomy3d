import type { ReactNode } from 'react';
import { data, ROLE_META, type Fact, type Role, type RoleEntry } from '@/data';
import { controller } from '@/logic/controller';

export const Icon = {
  search: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>,
  menu: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg>,
  settings: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" /></svg>,
  close: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>,
  reset: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" /></svg>,
};

export const certaintyTag = (c?: Fact['certainty']) =>
  c === 'variable' ? <span className="tag variable">וריאציה</span> : c === 'debated' ? <span className="tag debated">שנוי במחלוקת</span> : null;

export function Facts({ items }: { items: Fact[] }) {
  if (!items.length) return <div className="fact note">—</div>;
  return (
    <>
      {items.map((f, i) => (
        <div className="fact" key={i}>
          • {f.text} {certaintyTag(f.certainty)}
          {f.note && <div className="note">{f.note}</div>}
        </div>
      ))}
    </>
  );
}

export function Accordion({ title, open, children }: { title: ReactNode; open?: boolean; children: ReactNode }) {
  return (
    <details className="acc" open={open}>
      <summary>{title}</summary>
      <div className="acc-body">{children}</div>
    </details>
  );
}

export function SheetTop({ onBack, children }: { onBack?: () => void; children: ReactNode }) {
  return (
    <div className="sheet-top">
      {onBack && <button className="back-btn" aria-label="חזרה" onClick={onBack}>→</button>}
      <div style={{ flex: 1, minWidth: 0 }}>{children}</div>
    </div>
  );
}

export function MusclePill({ id, entry, onClick }: { id: string; entry?: RoleEntry; onClick?: () => void }) {
  const m = data.muscle(id);
  if (!m) return null;
  return (
    <button className="pill" onClick={onClick ?? (() => controller.select('muscle', id))}>
      {entry && (
        <span className="bar" title="הערכת מעורבות">
          <i style={{ width: `${Math.round(entry.involvement * 100)}%`, background: ROLE_META[entry.role].color }} />
        </span>
      )}
      {m.hebrewName}
      {entry?.certainty === 'debated' && <span className="tag debated">?</span>}
    </button>
  );
}

/** Role groups (agonists / synergists / stabilizers / antagonists) – each muscle tappable. */
export function RoleGroups({ roles }: { roles: RoleEntry[] }) {
  const g = data.groupRoles(roles);
  return (
    <>
      {(Object.keys(g) as Role[]).map((r) =>
        g[r].length ? (
          <div className="role-group" key={r}>
            <div className="role-head">
              <span className="role-dot" style={{ background: ROLE_META[r].color, opacity: r === 'antagonist' ? 0.6 : 1 }} />
              {ROLE_META[r].hebrew}
            </div>
            <div className="pill-wrap">
              {g[r].map((e) => <MusclePill key={e.muscleId} id={e.muscleId} entry={e} />)}
            </div>
          </div>
        ) : null,
      )}
    </>
  );
}

export function ColorLegend() {
  return (
    <div className="legend">
      {(Object.keys(ROLE_META) as Role[]).map((r) => (
        <span key={r}><span className="role-dot" style={{ background: ROLE_META[r].color }} />{ROLE_META[r].hebrew}</span>
      ))}
      <span><span className="tag estimate">הערכה</span> עוצמת הצבע = מעורבות משוערת</span>
    </div>
  );
}
