import { useEffect, useRef, useState, type ReactNode } from 'react';
import type { SheetSnap } from '@/logic/store';

/**
 * Draggable bottom sheet with snap points (peek / half / full).
 * Drag the handle (or the header area) up/down; release snaps to the nearest point.
 * In landscape the CSS turns it into a fixed side panel.
 */
const SIDE_PANEL_MQ = '(orientation: landscape) and (max-height: 560px), (min-width: 900px) and (orientation: landscape)';

export function BottomSheet({ snap, onSnap, onHeight, children, peekHeight = 190 }: { snap: SheetSnap; onSnap: (s: SheetSnap) => void; onHeight?: (h: number) => void; children: ReactNode; peekHeight?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<number | null>(null);
  const start = useRef<{ y: number; h: number } | null>(null);

  const avail = () => (ref.current?.parentElement?.clientHeight ?? window.innerHeight) - 64 - 76;
  const heights = (): Record<Exclude<SheetSnap, 'closed'>, number> => {
    const a = avail();
    return { peek: Math.min(peekHeight, a * 0.45), half: a * 0.52, full: a * 0.94 };
  };

  useEffect(() => setDrag(null), [snap]);

  const h = snap === 'closed' ? 0 : drag ?? heights()[snap];
  // Report how much of the canvas the sheet covers (0 when it is a side panel in landscape).
  useEffect(() => {
    const report = () => onHeight?.(matchMedia(SIDE_PANEL_MQ).matches ? 0 : h);
    report();
    window.addEventListener('resize', report);
    return () => window.removeEventListener('resize', report);
  }, [h, onHeight]);

  if (snap === 'closed') return null;

  const onDown = (e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    start.current = { y: e.clientY, h };
  };
  const onMove = (e: React.PointerEvent) => {
    if (!start.current) return;
    const nh = Math.max(80, Math.min(heights().full, start.current.h + (start.current.y - e.clientY)));
    setDrag(nh);
  };
  const onUp = (e: React.PointerEvent) => {
    if (!start.current) return;
    const moved = Math.abs(start.current.y - e.clientY);
    const cur = drag ?? start.current.h;
    start.current = null;
    if (moved < 6) {
      // tap on handle cycles the size
      onSnap(snap === 'peek' ? 'half' : snap === 'half' ? 'full' : 'peek');
      setDrag(null);
      return;
    }
    const hs = heights();
    if (cur < hs.peek * 0.6) { onSnap('closed'); return; }
    const best = (Object.entries(hs) as [SheetSnap, number][]).sort((a, b) => Math.abs(a[1] - cur) - Math.abs(b[1] - cur))[0][0];
    onSnap(best);
    setDrag(null);
  };

  return (
    <div ref={ref} className={`sheet${drag !== null ? ' dragging' : ''}`} style={{ height: h }} role="dialog" aria-modal="false">
      <div className="sheet-handle" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} aria-label="גרור להגדלה" />
      <div className="sheet-body">{children}</div>
    </div>
  );
}

/** Modal sheet with scrim (search, layers, settings…). */
export function ModalSheet({ title, onClose, children, full, headerExtra }: { title: ReactNode; onClose: () => void; children: ReactNode; full?: boolean; headerExtra?: ReactNode }) {
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className={`modal-sheet${full ? ' full' : ''}`} role="dialog" aria-modal="true">
        <div className="sheet-handle" onClick={onClose} />
        <div className="modal-head">
          <h2>{title}</h2>
          {headerExtra}
          <button className="back-btn" aria-label="סגור" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </>
  );
}
