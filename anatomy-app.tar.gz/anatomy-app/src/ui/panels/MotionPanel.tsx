/** "ניתוח תנועה" – analysis of a movement or exercise currently animated on the model. */
import { data } from '@/data';
import { controller } from '@/logic/controller';
import { useStore } from '../hooks/useStore';
import { ColorLegend, RoleGroups, SheetTop } from '../components/Common';

export function MotionPanel() {
  const detail = useStore((s) => s.detail);
  const motion = useStore((s) => s.motion);
  if (!detail) return null;
  const back = () => controller.closeMotionDetail();

  if (detail.kind === 'joint') return <JointPanel id={detail.id} />;

  if (detail.kind === 'movement') {
    const mv = data.movement(detail.id)!;
    const joint = data.joint(mv.jointId)!;
    const jm = joint.motions.find((x) => x.movementId === mv.id);
    const roles = motion?.source === 'custom' ? motion.roles : mv.roles;
    return (
      <div>
        <SheetTop onBack={back}>
          <div className="title">{motion?.source === 'custom' ? motion.title : mv.hebrewName}</div>
          <div className="subtitle"><span className="latin">{mv.englishName}</span> · {joint.hebrewName}</div>
        </SheetTop>
        <p style={{ margin: '4px 0 8px' }}>{mv.description}</p>
        <dl className="kv">
          <dt>מישור</dt><dd>{{ sagittal: 'סגיטלי', frontal: 'פרונטלי', transverse: 'רוחבי' }[mv.plane]}</dd>
          {jm && <><dt>טווח אופייני</dt><dd>{jm.typicalRange[0]}°–{jm.typicalRange[1]}° <span className="tag estimate">הערכה</span></dd></>}
        </dl>
        <ColorLegend />
        <RoleGroups roles={roles} />
        {mv.modelGaps && <div className="info-box">ℹ️ {mv.modelGaps}</div>}
        <div className="info-box">האנימציה היא מודל קינמטי מפושט <span className="tag model">מודל</span>; התפקידים לפי ספרות קינסיולוגית <span className="tag model">ביומכניקה</span>.</div>
      </div>
    );
  }

  const ex = data.exercise(detail.id)!;
  return (
    <div>
      <SheetTop onBack={back}>
        <div className="title">{ex.hebrewName}</div>
        <div className="subtitle"><span className="latin">{ex.englishName}</span> · ניתוח תנועה</div>
      </SheetTop>
      <div className="section-title" style={{ marginTop: 6 }}>מפרקים וטווח תנועה <span className="tag estimate">הערכה</span></div>
      <div className="list">
        {ex.joints.map((j) => (
          <div key={j.jointId} className="list-item" style={{ minHeight: 48 }}>
            <span className="main"><span className="t">{data.joint(j.jointId)?.hebrewName}</span><div className="s">{j.action}</div></span>
            <span style={{ fontWeight: 700, direction: 'rtl' }}>{j.range}</span>
          </div>
        ))}
      </div>
      <div className="section-title">שרירים לפי תפקיד</div>
      <ColorLegend />
      <RoleGroups roles={ex.roles} />
      <div className="info-box">{ex.phaseNote}</div>
      {ex.modelGaps && <div className="info-box">ℹ️ {ex.modelGaps}</div>}
      <div className="section-title">תנועות מפרקיות בתרגיל</div>
      <div className="pill-wrap">
        {ex.movementIds.map((id) => <button key={id} className="pill" onClick={() => controller.playMovement(id)}>▶ {data.movement(id)?.hebrewName}</button>)}
      </div>
      <button className="btn block" style={{ marginTop: 14 }} onClick={() => controller.openModal('compareExercises')}>⚖️ השווה לתרגיל אחר</button>
    </div>
  );
}

function JointPanel({ id }: { id: string }) {
  const j = data.joint(id)!;
  const ms = data.muscles.filter((m) => m.relatedJoints.includes(id));
  return (
    <div>
      <SheetTop onBack={() => controller.closeMotionDetail()}>
        <div className="title">{j.hebrewName}</div>
        <div className="subtitle"><span className="latin">{j.latinName}</span> · {j.jointType}</div>
      </SheetTop>
      <p>{j.summary}</p>
      <div className="section-title">תנועות</div>
      <div className="list">
        {j.motions.map((m) => (
          <button key={m.movementId} className="list-item" onClick={() => controller.playMovement(m.movementId)}>
            <span className="main"><span className="t">{data.movement(m.movementId)?.hebrewName}</span><div className="s">טווח אופייני {m.typicalRange[0]}°–{m.typicalRange[1]}°</div></span>
            <span className="chev">▶</span>
          </button>
        ))}
        {!j.motions.length && <div className="empty">אין תנועות מוגדרות</div>}
      </div>
      <div className="section-title">שרירים הפועלים על המפרק</div>
      <div className="pill-wrap">{ms.map((m) => <button key={m.id} className="pill" onClick={() => controller.select('muscle', m.id)}>{m.hebrewName}</button>)}</div>
    </div>
  );
}
