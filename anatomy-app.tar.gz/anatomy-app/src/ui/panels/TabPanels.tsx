/** Default sheet content of each bottom-nav tab, plus query results and the quiz. */
import { useMemo, useState } from 'react';
import { data, REGION_NAMES, type Muscle, type RegionId } from '@/data';
import { controller } from '@/logic/controller';
import { quizStats } from '@/logic/quiz';
import { useStore } from '../hooks/useStore';
import { Accordion, ColorLegend, MusclePill, SheetTop } from '../components/Common';

/* ───────────── אנטומיה ───────────── */
export function AnatomyPanel() {
  const byRegion = useMemo(() => {
    const m = new Map<RegionId, Muscle[]>();
    for (const x of data.muscles) m.set(x.region, [...(m.get(x.region) ?? []), x]);
    return [...m.entries()];
  }, []);
  return (
    <div>
      <div className="title">אנטומיה</div>
      <div className="subtitle">הקש על מבנה במודל או בחר מהרשימה</div>
      <div className="row wrap" style={{ gap: 8 }}>
        <button className="btn small" onClick={() => controller.openModal('layers')}>🧬 שכבות</button>
        <button className="btn small" onClick={() => controller.skeletonMode()}>🦴 שלד</button>
        <button className="btn small" onClick={() => controller.resetLayers()}>💪 שרירים</button>
        <button className="btn small" onClick={() => controller.openModal('section')}>✂️ חתך אנטומי</button>
      </div>
      <div className="section-title">שרירים לפי אזור</div>
      {byRegion.map(([r, ms]) => (
        <Accordion key={r} title={<>{REGION_NAMES[r]} <span className="tag model">{ms.length}</span></>}>
          <div className="list">
            {ms.map((m) => (
              <button key={m.id} className="list-item" onClick={() => controller.select('muscle', m.id)}>
                <span className="main"><span className="t">{m.hebrewName}</span><div className="s latin">{m.latinName}</div></span>
                <span className="chev">‹</span>
              </button>
            ))}
          </div>
        </Accordion>
      ))}
      <div className="section-title">עצמות</div>
      <div className="pill-wrap">
        {data.bones.map((b) => <button key={b.id} className="pill" onClick={() => controller.select('bone', b.id)}>{b.hebrewName}</button>)}
      </div>
      <div className="section-title">עצבים</div>
      <div className="pill-wrap">
        {data.nerves.map((n) => <button key={n.id} className="pill" onClick={() => controller.select('nerve', n.id)}>{n.hebrewName}</button>)}
      </div>
    </div>
  );
}

/* ───────────── תנועות ───────────── */
export function MovementsPanel() {
  return (
    <div>
      <div className="title">תנועות</div>
      <div className="subtitle">בחר תנועה כדי לראות אותה באנימציה עם צבעי התפקידים</div>
      <ColorLegend />
      <button className="btn block primary" style={{ margin: '12px 0 4px' }} onClick={() => controller.openModal('builder')}>🛠 בנה תנועה (מפרק → תנועה → זווית)</button>
      {data.joints.filter((j) => j.motions.length).map((j) => (
        <div key={j.id}>
          <div className="section-title">{j.hebrewName}</div>
          <div className="list">
            {data.movementsForJoint(j.id).map((mv) => (
              <button key={mv.id} className="list-item" onClick={() => controller.playMovement(mv.id)}>
                <span className="main"><span className="t">{mv.hebrewName}</span><div className="s">{mv.englishName}</div></span>
                <span className="chev">▶</span>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ───────────── תרגילים ───────────── */
const CAT: Record<string, string> = { lower: 'פלג גוף תחתון', 'upper-push': 'דחיקה – פלג גוף עליון', 'upper-pull': 'משיכה – פלג גוף עליון', arms: 'ידיים', full: 'גוף מלא' };
export function ExercisesPanel() {
  const cats = [...new Set(data.exercises.map((e) => e.category))];
  return (
    <div>
      <div className="title">ספריית תרגילים</div>
      <div className="subtitle">{data.exercises.length} תרגילים · בחירה מציגה ניתוח תנועה</div>
      <button className="btn block" style={{ marginBottom: 6 }} onClick={() => controller.openModal('compareExercises')}>⚖️ השוואת תרגילים</button>
      {cats.map((c) => (
        <div key={c}>
          <div className="section-title">{CAT[c]}</div>
          <div className="list">
            {data.exercises.filter((e) => e.category === c).map((e) => (
              <button key={e.id} className="list-item" onClick={() => controller.playExercise(e.id)}>
                <span className="main"><span className="t">{e.hebrewName}</span><div className="s">{e.englishName}</div></span>
                <span className="chev">▶</span>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ───────────── לימוד ───────────── */
export function LearnPanel() {
  const sel = useStore((s) => s.selection);
  const [id, setId] = useState<string>(sel?.kind === 'muscle' ? sel.id : 'biceps_brachii');
  const m = data.muscle(id)!;
  const moves = data.movementsForMuscle(m.id).filter((x) => x.role.role !== 'antagonist');
  const cards: { q: string; a: string }[] = [
    { q: 'מהו?', a: m.summary },
    { q: 'איפה נמצא?', a: m.location },
    { q: 'מה המוצא?', a: m.origin.map((o) => o.text).join(' · ') },
    { q: 'מה האחז?', a: m.insertion.map((o) => o.text).join(' · ') },
    { q: 'מה העצבוב?', a: m.innervation.map((i) => i.text).join(' · ') },
    { q: 'מה הפעולה?', a: m.primaryActions.map((a) => a.text).join(' · ') },
    { q: 'באילו תנועות משתתף?', a: moves.map((x) => x.movement.hebrewName).join(' · ') || '—' },
  ];
  return (
    <div>
      <div className="title">🧠 למד אותי</div>
      <div className="subtitle">כרטיסים קצרים על כל מבנה · החלק הצידה</div>
      <select className="select" value={id} onChange={(e) => { setId(e.target.value); controller.select('muscle', e.target.value); }} aria-label="בחר שריר">
        {data.muscles.map((x) => <option key={x.id} value={x.id}>{x.hebrewName} – {x.latinName}</option>)}
      </select>
      <div className="cards" style={{ marginTop: 12 }}>
        {cards.map((c) => (
          <div className="card" key={c.q}><h4>{c.q}</h4><p>{c.a}</p></div>
        ))}
      </div>
      <div className="row" style={{ marginTop: 6 }}>
        <button className="btn small" onClick={() => controller.select('muscle', id)}>📍 הראה במודל</button>
        <button className="btn small" onClick={() => { controller.select('muscle', id); controller.isolateSelected(); }}>◎ בודד</button>
      </div>
      <div className="section-title">תרגול</div>
      <button className="btn block primary" onClick={() => controller.startQuiz()}>📝 התחל מבחן (10 שאלות)</button>
      <button className="btn block" style={{ marginTop: 8 }} onClick={() => controller.openModal('compareMuscles')}>⚖️ השוואת שרירים</button>
    </div>
  );
}

/* ───────────── תוצאות שאילתה ───────────── */
export function QueryPanel() {
  const q = useStore((s) => s.query);
  if (!q) return null;
  return (
    <div>
      <SheetTop onBack={() => controller.closeQuery()}>
        <div className="title">{q.title}</div>
        <div className="subtitle">תוצאות חיפוש מתקדם</div>
      </SheetTop>
      {q.source?.kind === 'movement' && <button className="btn block primary" onClick={() => controller.playMovement(q.source!.id)}>▶ הצג את התנועה</button>}
      {q.source?.kind === 'exercise' && <button className="btn block primary" onClick={() => controller.playExercise(q.source!.id)}>▶ הצג את התרגיל</button>}
      {q.groups.map((g) => (
        <div className="role-group" key={g.label}>
          <div className="role-head">{g.label}</div>
          <div className="pill-wrap">{g.muscles.map((x) => <MusclePill key={x.id} id={x.id} />)}</div>
        </div>
      ))}
      {!q.groups.some((g) => g.muscles.length) && <div className="empty">לא נמצאו שרירים במאגר</div>}
    </div>
  );
}

/* ───────────── מבחן ───────────── */
export function QuizPanel() {
  const quiz = useStore((s) => s.quiz);
  if (!quiz) return null;
  const st = quizStats(quiz);
  const cur = quiz.questions[quiz.index];
  return (
    <div>
      <SheetTop onBack={() => controller.endQuiz()}>
        <div className="title">מבחן</div>
        <div className="subtitle">שאלה {Math.min(quiz.index + 1, st.total)} מתוך {st.total}</div>
      </SheetTop>
      <div className="progress"><i style={{ width: `${(st.answered / st.total) * 100}%` }} /></div>
      <div className="stats" style={{ margin: '10px 0' }}>
        <div><b>{st.score}</b><span>ניקוד</span></div>
        <div><b>{st.percent}%</b><span>הצלחה</span></div>
        <div><b style={{ color: 'var(--ok)' }}>{st.correct}</b><span>נכונות</span></div>
        <div><b style={{ color: 'var(--danger)' }}>{st.wrong}</b><span>שגויות</span></div>
      </div>
      {st.done || !cur ? (
        <div>
          <div className="title" style={{ fontSize: 20 }}>סיימת! {st.percent}% הצלחה</div>
          <div className="section-title">שאלות שגויות</div>
          <div className="list">
            {quiz.answers.filter((a) => !a.correct).map((a, i) => (
              <button key={i} className="list-item" onClick={() => controller.select('muscle', a.question.muscleId)}>
                <span className="main"><span className="t">{a.question.prompt}</span><div className="s">תשובתך: {a.given ?? '—'}</div></span>
              </button>
            ))}
            {!quiz.answers.some((a) => !a.correct) && <div className="empty">אין – כל הכבוד!</div>}
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="btn primary" onClick={() => controller.startQuiz()}>מבחן חדש</button>
            <button className="btn" onClick={() => controller.endQuiz()}>סיום</button>
          </div>
        </div>
      ) : (
        <div>
          <p style={{ fontWeight: 700, fontSize: 18, margin: '6px 0 10px' }}>{cur.prompt}</p>
          {cur.type === 'find' ? (
            <div className="info-box" style={{ marginTop: 0 }}>👆 הקש על השריר במודל. אפשר לסובב ולהגדיל.</div>
          ) : (
            cur.options!.map((o, i) => {
              const answered = !!quiz.feedback;
              const cls = answered ? (i === cur.correctIndex ? ' right' : quiz.answers[quiz.answers.length - 1]?.given === o ? ' wrong' : '') : '';
              return <button key={i} className={`opt${cls}`} disabled={answered} onClick={() => controller.answerChoice(i)}>{o}</button>;
            })
          )}
          {quiz.feedback && <div className={`feedback ${quiz.feedback.correct ? 'ok' : 'bad'}`}>{quiz.feedback.text}</div>}
          <div className="row" style={{ marginTop: 8 }}>
            {quiz.feedback
              ? <button className="btn primary block" onClick={() => controller.nextQuestion()}>הבא ←</button>
              : <button className="btn block" onClick={() => controller.skipQuestion()}>דלג / הראה תשובה</button>}
          </div>
        </div>
      )}
    </div>
  );
}
