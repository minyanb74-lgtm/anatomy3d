import { useEffect, useRef } from 'react';
import { controller } from '@/logic/controller';
import { useStore } from './hooks/useStore';
import { BottomSheet } from './components/BottomSheet';
import { BottomNav, Loader, SideTools, StatusChips, Timeline, Toast, TopBar } from './components/Chrome';
import { StructurePanel } from './panels/StructurePanel';
import { MotionPanel } from './panels/MotionPanel';
import { AnatomyPanel, ExercisesPanel, LearnPanel, MovementsPanel, QueryPanel, QuizPanel } from './panels/TabPanels';
import { Modals } from './panels/Modals';

/** Decides what the bottom sheet shows. Order = priority. */
function SheetContent() {
  const quiz = useStore((s) => !!s.quiz);
  const query = useStore((s) => !!s.query);
  const selection = useStore((s) => !!s.selection);
  const detail = useStore((s) => s.detail);
  const tab = useStore((s) => s.tab);
  if (quiz) return <QuizPanel />;
  if (tab === 'learn' && !query) return <LearnPanel />;
  if (selection) return <StructurePanel />;
  if (query) return <QueryPanel />;
  if (detail) return <MotionPanel />;
  switch (tab) {
    case 'anatomy': return <AnatomyPanel />;
    case 'movements': return <MovementsPanel />;
    case 'exercises': return <ExercisesPanel />;
    case 'learn': return <LearnPanel />;
    default: return null;
  }
}

/** Height of the bottom chrome (nav + timeline) that covers the canvas. */
function navAndTimelineHeight(hasMotion: boolean) {
  const nav = document.querySelector('.bottom-nav')?.clientHeight ?? 64;
  return nav + (hasMotion ? document.querySelector('.timeline')?.clientHeight ?? 76 : 0);
}

export function App() {
  const viewport = useRef<HTMLDivElement>(null);
  const sheet = useStore((s) => s.sheet);
  const theme = useStore((s) => s.theme);
  const hasMotion = useStore((s) => !!s.motion);
  const placeholder = useStore((s) => s.isPlaceholderModel && s.ready);

  useEffect(() => {
    controller.mount(viewport.current!);
    return () => controller.unmount();
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#0b0f14' : '#eef1f5');
  }, [theme]);

  return (
    <div className={`app${sheet !== 'closed' ? ' sheet-open' : ''}${hasMotion ? ' with-timeline' : ''}`}>
      <div className="viewport" ref={viewport} />
      <TopBar />
      <SideTools />
      <StatusChips />
      {placeholder && sheet === 'closed' && <div className="badge-model">מודל זמני לפיתוח</div>}
      <BottomSheet snap={sheet} onSnap={(s) => controller.setSheet(s)} onHeight={(h) => controller.setOcclusion(64, h + navAndTimelineHeight(hasMotion))}>
        <SheetContent />
      </BottomSheet>
      <Timeline />
      <BottomNav />
      <Modals />
      <Toast />
      <Loader />
    </div>
  );
}
