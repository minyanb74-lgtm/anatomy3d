/**
 * GltfAssetProvider – loads a real, licensed anatomical model (.glb/.gltf) and adapts it to the
 * AnatomyAsset contract via a JSON manifest. Nothing else in the app needs to change.
 *
 * ┌──────────────────────────── WHAT IS NEEDED TO USE IT ────────────────────────────┐
 * │ 1. A licensed anatomical model exported as glTF 2.0 (ideally Draco/Meshopt +      │
 * │    KTX2 compressed, one mesh per structure, LOD variants named *_LOD1, *_LOD2).    │
 * │ 2. A manifest (see `GltfManifest`) mapping glTF node names → data modelReference, │
 * │    layer and side, and mapping rig segment ids → skeleton bone names.             │
 * │ 3. In src/assets/index.ts, select this provider instead of the procedural one.    │
 * └────────────────────────────────────────────────────────────────────────────────────┘
 *
 * Deformation: a skinned model is deformed by its skeleton – the PoseDriver rotates the mapped
 * bones (the `segments` of the rig), so `updateDeformation` only has to refresh bounding spheres.
 */
import { Box3, LOD, Mesh, Object3D, SkinnedMesh, Vector3, type Group } from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import type { LayerId, StructureKind } from '@/data';
import type { AnatomyAsset, AnatomyAssetProvider, AnatomyPart, ContactPoint, SegmentId, Side } from '../types';

export interface GltfManifest {
  url: string;
  attribution: string;
  /** Rig segment → name of the glTF node / skeleton bone that represents it. */
  segments: Record<SegmentId, string>;
  /** Contact points for grounding, in the given segment's local space. */
  contacts: { segment: SegmentId; local: [number, number, number]; kind: 'foot' | 'hand'; side: Side }[];
  /** glTF node name (exact or RegExp source when wrapped in /…/) → part description. */
  parts: { node: string; ref: string; kind: StructureKind; layer: LayerId; side?: Side; subpart?: 'belly' | 'tendon' }[];
  /** Distances (m from camera) for LOD switching when *_LOD1/_LOD2 siblings exist. */
  lodDistances?: [number, number];
}

const matches = (pattern: string, name: string) =>
  pattern.startsWith('/') && pattern.endsWith('/') ? new RegExp(pattern.slice(1, -1)).test(name) : pattern === name;

export class GltfAssetProvider implements AnatomyAssetProvider {
  readonly id = 'gltf';
  constructor(private manifest: GltfManifest) {}

  async load(onProgress?: (f: number) => void): Promise<AnatomyAsset> {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync(this.manifest.url, (e) => e.total && onProgress?.(e.loaded / e.total));
    const scene = gltf.scene as Group;

    const find = (name: string) => {
      const o = scene.getObjectByName(name);
      if (!o) throw new Error(`[GltfAssetProvider] node "${name}" from manifest not found in model`);
      return o;
    };
    const segments = Object.fromEntries(
      Object.entries(this.manifest.segments).map(([k, v]) => [k, find(v)]),
    ) as Record<SegmentId, Object3D>;
    for (const s of Object.values(segments)) s.rotation.order = 'XZY';

    // Build LODs for meshes that have *_LOD1/_LOD2 siblings.
    this.applyLods(scene);

    const parts: AnatomyPart[] = [];
    scene.traverse((o) => {
      const mesh = o as Mesh;
      if (!mesh.isMesh || /_LOD\d$/.test(mesh.name)) return;
      const entry = this.manifest.parts.find((p) => matches(p.node, mesh.name));
      if (!entry) return;
      const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
      const m = mat.clone();
      mesh.material = m;
      mesh.userData.partIndex = parts.length;
      parts.push({
        ref: entry.ref, kind: entry.kind, side: entry.side, layer: entry.layer, subpart: entry.subpart,
        meshes: [mesh],
        baseColor: (m as { color?: { getHex(): number } }).color?.getHex() ?? 0xffffff,
        baseOpacity: m.opacity, pickable: true,
      });
    });

    const contacts: ContactPoint[] = this.manifest.contacts.map((c) => ({ ...c, local: new Vector3(...c.local) }));
    const root = segments.root;
    const bounds = new Box3().setFromObject(scene);

    return {
      scene,
      rig: { root, segments, contacts, restRootHeight: root.position.y || bounds.getCenter(new Vector3()).y },
      parts,
      attribution: this.manifest.attribution,
      isPlaceholder: false,
      updateDeformation: () => {
        scene.updateMatrixWorld(true);
        for (const p of parts) for (const m of p.meshes) if ((m as SkinnedMesh).isSkinnedMesh) (m as SkinnedMesh).computeBoundingSphere();
      },
      dispose: () => scene.traverse((o) => { const m = o as Mesh; if (m.isMesh) { m.geometry.dispose(); } }),
    };
  }

  private applyLods(scene: Object3D) {
    const [d1, d2] = this.manifest.lodDistances ?? [2.5, 5];
    const base: Mesh[] = [];
    scene.traverse((o) => { if ((o as Mesh).isMesh && !/_LOD\d$/.test(o.name)) base.push(o as Mesh); });
    for (const m of base) {
      const l1 = m.parent?.getObjectByName(`${m.name}_LOD1`);
      if (!l1 || !m.parent) continue;
      const l2 = m.parent.getObjectByName(`${m.name}_LOD2`);
      const lod = new LOD();
      lod.name = `${m.name}__lod`;
      m.parent.add(lod);
      lod.addLevel(m, 0);
      lod.addLevel(l1, d1);
      if (l2) lod.addLevel(l2, d2);
    }
  }
}
