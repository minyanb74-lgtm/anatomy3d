/**
 * Asset selection. To switch to a real anatomical model:
 *
 *   import { GltfAssetProvider } from './gltf/GltfAssetProvider';
 *   import manifest from './gltf/manifest.json';
 *   export const createAssetProvider = () => new GltfAssetProvider(manifest);
 */
import { ProceduralAssetProvider } from './procedural/ProceduralAssetProvider';
import type { AnatomyAssetProvider } from './types';

export * from './types';

export const createAssetProvider = (): AnatomyAssetProvider => new ProceduralAssetProvider();
