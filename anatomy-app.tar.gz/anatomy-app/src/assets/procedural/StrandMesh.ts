/**
 * StrandMesh – a deformable "fibre bundle" stretched along a path of rig anchors.
 *
 * Used by the procedural placeholder for muscles, tendons, nerves, vessels and ligaments.
 * The topology is fixed; on every pose change only the position/normal buffers are rewritten,
 * so it is cheap enough to update ~150 strands per frame on a mid-range phone.
 */
import {
  BufferAttribute, BufferGeometry, CatmullRomCurve3, Matrix4, Mesh, Object3D, Quaternion, Vector3,
  type Material,
} from 'three';

export interface Anchor {
  seg: Object3D;
  local: Vector3;
}

export type Profile = 'belly' | 'tube';

export interface StrandOptions {
  anchors: Anchor[];
  /** Half-width / half-depth of the cross-section at its thickest (m). */
  width: number;
  depth: number;
  /** Direction (in the first anchor's segment space) that the "depth" axis should face. */
  hint?: Vector3;
  /** Portion of the path [from, to] that this strand covers (0..1). */
  range?: [number, number];
  profile: Profile;
  /** Minimum radius factor at the ends of a belly. */
  endFactor?: number;
  rings?: number;
  radial?: number;
  /** Fatten when shortened (muscle bulge). */
  bulge?: boolean;
}

const _a = new Vector3();
const _b = new Vector3();
const _t = new Vector3();
const _d = new Vector3();
const _w = new Vector3();
const _q = new Quaternion();
const _inv = new Matrix4();

export class StrandMesh extends Mesh {
  readonly opts: Required<Omit<StrandOptions, 'hint'>> & { hint: Vector3 };
  private ringPoints: Vector3[] = [];
  private restLength = 0;
  private curve = new CatmullRomCurve3([], false, 'centripetal');

  constructor(opts: StrandOptions, material: Material) {
    super(new BufferGeometry(), material);
    this.opts = {
      range: [0, 1], endFactor: 0.25, rings: 18, radial: 10, bulge: false, hint: new Vector3(0, 0, 1),
      ...opts,
    } as StrandMesh['opts'];
    const { rings, radial } = this.opts;
    const vCount = rings * (radial + 1);
    this.geometry.setAttribute('position', new BufferAttribute(new Float32Array(vCount * 3), 3));
    this.geometry.setAttribute('normal', new BufferAttribute(new Float32Array(vCount * 3), 3));
    const idx: number[] = [];
    for (let i = 0; i < rings - 1; i++) {
      for (let j = 0; j < radial; j++) {
        const a = i * (radial + 1) + j;
        const b = a + radial + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
      }
    }
    this.geometry.setIndex(idx);
    for (let i = 0; i < rings; i++) this.ringPoints.push(new Vector3());
    this.matrixAutoUpdate = false;
    this.frustumCulled = true;
  }

  /** Rebuild vertices from the current world positions of the anchors. `parentInverse` maps world→this.parent. */
  update(parentInverse: Matrix4) {
    const { anchors, rings, radial, width, depth, range, profile, endFactor, bulge, hint } = this.opts;
    const pts = anchors.map((a) => a.seg.localToWorld(_a.copy(a.local)).applyMatrix4(parentInverse).clone());

    // Path length (polyline approximation) for bulge.
    let len = 0;
    for (let i = 1; i < pts.length; i++) len += pts[i].distanceTo(pts[i - 1]);
    if (!this.restLength) this.restLength = len;
    const bulgeK = bulge ? Math.min(1.35, Math.max(0.8, Math.sqrt(this.restLength / Math.max(len, 1e-4)))) : 1;

    const sample = (t: number, out: Vector3) => {
      if (pts.length === 2) return out.lerpVectors(pts[0], pts[1], t);
      return this.curve.getPoint(t, out);
    };
    if (pts.length > 2) this.curve.points = pts;

    // Hint direction in parent space (rotate with the first anchor's segment).
    anchors[0].seg.getWorldQuaternion(_q);
    const hintW = _b.copy(hint).applyQuaternion(_q).normalize();
    parentInverse.decompose(_a, _q, _t);
    hintW.applyQuaternion(_q);
    const hintP = hintW.clone();

    const pos = this.geometry.getAttribute('position') as BufferAttribute;
    const nor = this.geometry.getAttribute('normal') as BufferAttribute;
    const [r0, r1] = range;

    for (let i = 0; i < rings; i++) this.ringPoints[i].set(0, 0, 0);
    for (let i = 0; i < rings; i++) sample(r0 + ((r1 - r0) * i) / (rings - 1), this.ringPoints[i]);

    for (let i = 0; i < rings; i++) {
      const c = this.ringPoints[i];
      const prev = this.ringPoints[Math.max(0, i - 1)];
      const next = this.ringPoints[Math.min(rings - 1, i + 1)];
      _t.subVectors(next, prev).normalize();
      // depth axis = hint ⟂ tangent
      _d.copy(hintP).addScaledVector(_t, -hintP.dot(_t));
      if (_d.lengthSq() < 1e-6) _d.set(1, 0, 0).addScaledVector(_t, -_t.x);
      _d.normalize();
      _w.crossVectors(_t, _d).normalize();

      const u = i / (rings - 1);
      let k = 1;
      if (profile === 'belly') {
        k = endFactor + (1 - endFactor) * Math.pow(Math.sin(Math.PI * u), 0.65);
        k *= bulgeK;
      }
      const ww = width * k;
      const dd = depth * k;
      for (let j = 0; j <= radial; j++) {
        const th = (j / radial) * Math.PI * 2;
        const cs = Math.cos(th);
        const sn = Math.sin(th);
        const vi = i * (radial + 1) + j;
        pos.setXYZ(vi, c.x + _w.x * cs * ww + _d.x * sn * dd, c.y + _w.y * cs * ww + _d.y * sn * dd, c.z + _w.z * cs * ww + _d.z * sn * dd);
        const nx = (_w.x * cs) / ww + (_d.x * sn) / dd;
        const ny = (_w.y * cs) / ww + (_d.y * sn) / dd;
        const nz = (_w.z * cs) / ww + (_d.z * sn) / dd;
        const l = Math.hypot(nx, ny, nz) || 1;
        nor.setXYZ(vi, nx / l, ny / l, nz / l);
      }
    }
    pos.needsUpdate = true;
    nor.needsUpdate = true;
    this.geometry.computeBoundingSphere();
    this.matrix.identity();
    this.matrixWorldNeedsUpdate = true;
  }

  static parentInverse(parent: Object3D) {
    parent.updateWorldMatrix(true, false);
    return _inv.copy(parent.matrixWorld).invert();
  }
}
