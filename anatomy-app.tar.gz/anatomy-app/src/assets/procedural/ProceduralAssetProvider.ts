/**
 * ProceduralAssetProvider – development placeholder body built from primitives and StrandMeshes.
 * Licence: generated in code, no third-party assets.
 */
import {
  BoxGeometry, BufferGeometry, CylinderGeometry, DoubleSide, ExtrudeGeometry, Group, LatheGeometry, Mesh,
  MeshStandardMaterial, type MeshStandardMaterialParameters, Object3D, Quaternion, Shape, SphereGeometry, TorusGeometry, Vector2, Vector3,
  type Material,
} from 'three';
import { data, type LayerId, type StructureKind } from '@/data';
import type { AnatomyAsset, AnatomyAssetProvider, AnatomyPart, ContactPoint, Rig, SegmentId, Side } from '../types';
import { StrandMesh, type Anchor } from './StrandMesh';
import { DIM, LIGAMENT_SPECS, MUSCLE_SPECS, NERVE_SPECS, VESSEL_SPECS, type A, type BaseSeg } from './specs';

const COLORS = {
  muscle: 0xb8443d, muscleDeep: 0x9c3a35, tendon: 0xe6dcc4, bone: 0xe9e1c9, nerve: 0xf4d34a,
  artery: 0xd22b2b, vein: 0x3c62d6, ligament: 0xbfcab4, skin: 0xd7a07c, fat: 0xf0d27a, fascia: 0xa9d4f2,
};

/* ───────────── geometry helpers ───────────── */

const _up = new Vector3(0, 1, 0);
function cyl(from: [number, number, number], to: [number, number, number], r: number, r2 = r): BufferGeometry {
  const a = new Vector3(...from);
  const b = new Vector3(...to);
  const len = a.distanceTo(b);
  const g = new CylinderGeometry(r2, r, len, 10, 1);
  const q = new Quaternion().setFromUnitVectors(_up, b.clone().sub(a).normalize());
  g.applyQuaternion(q);
  const mid = a.add(b).multiplyScalar(0.5);
  g.translate(mid.x, mid.y, mid.z);
  return g;
}
function sph(at: [number, number, number], r: number, s: [number, number, number] = [1, 1, 1]): BufferGeometry {
  const g = new SphereGeometry(r, 16, 12);
  g.scale(...s);
  g.translate(...at);
  return g;
}
function box(at: [number, number, number], size: [number, number, number]): BufferGeometry {
  const g = new BoxGeometry(...size);
  g.translate(...at);
  return g;
}
/** Tapered capsule along -Y from 0 to -len. */
function taper(len: number, r1: number, r2: number, zScale = 1): BufferGeometry {
  const pts: Vector2[] = [];
  const n = 6;
  for (let i = 0; i <= n; i++) {
    const a = (Math.PI / 2) * (i / n);
    pts.push(new Vector2(r2 * Math.sin(a), -len - r2 * Math.cos(a) * 0.6));
  }
  for (let i = n; i >= 0; i--) {
    const a = (Math.PI / 2) * (i / n);
    pts.push(new Vector2(r1 * Math.sin(a), r1 * Math.cos(a) * 0.6));
  }
  const g = new LatheGeometry(pts, 20);
  g.scale(1, 1, zScale);
  return g;
}

/* ───────────── rig ───────────── */

function buildRig(): Rig {
  const mk = (name: string, parent: Object3D | null, x = 0, y = 0, z = 0) => {
    const o = new Object3D();
    o.name = name;
    o.position.set(x, y, z);
    o.rotation.order = 'XZY';
    parent?.add(o);
    return o;
  };
  const root = mk('root', null, 0, DIM.pelvisY, 0);
  const pelvis = mk('pelvis', root);
  const torso = mk('torso', pelvis, ...DIM.lumbar);
  const head = mk('head', torso, ...DIM.neck);
  const seg: Partial<Record<SegmentId, Object3D>> = { root, pelvis, torso, head };
  for (const s of ['L', 'R'] as Side[]) {
    const m = s === 'L' ? 1 : -1;
    const ua = mk('upperArm' + s, torso, DIM.shoulder[0] * m, DIM.shoulder[1], DIM.shoulder[2]);
    const fa = mk('forearm' + s, ua, 0, -DIM.upperArm, 0);
    const ha = mk('hand' + s, fa, 0, -DIM.forearm, 0);
    const th = mk('thigh' + s, pelvis, DIM.hip[0] * m, DIM.hip[1], DIM.hip[2]);
    const sh = mk('shank' + s, th, 0, -DIM.thigh, 0);
    const ft = mk('foot' + s, sh, 0, -DIM.shank, 0);
    Object.assign(seg, { ['upperArm' + s]: ua, ['forearm' + s]: fa, ['hand' + s]: ha, ['thigh' + s]: th, ['shank' + s]: sh, ['foot' + s]: ft });
  }
  const contacts: ContactPoint[] = [];
  for (const s of ['L', 'R'] as Side[]) {
    contacts.push({ segment: ('foot' + s) as SegmentId, local: new Vector3(0, -0.075, -0.06), kind: 'foot', side: s });
    contacts.push({ segment: ('foot' + s) as SegmentId, local: new Vector3(0, -0.075, 0.17), kind: 'foot', side: s });
    contacts.push({ segment: ('hand' + s) as SegmentId, local: new Vector3(0, -0.17, 0), kind: 'hand', side: s });
  }
  return { root, segments: seg as Record<SegmentId, Object3D>, contacts, restRootHeight: DIM.pelvisY };
}

/* ───────────── bones (left side; right is mirrored) ───────────── */

type BoneBuild = { ref: string; seg: BaseSeg; sided: boolean; geoms: () => BufferGeometry[] };

const BONE_BUILDS: BoneBuild[] = [
  { ref: 'bone.skull', seg: 'head', sided: false, geoms: () => [sph([0, 0.13, 0.005], 0.09, [0.86, 1.05, 1.05]), box([0, 0.055, 0.05], [0.09, 0.04, 0.07])] },
  {
    ref: 'bone.vertebrae', seg: 'torso', sided: false, geoms: () => {
      const g: BufferGeometry[] = [];
      for (let i = 0; i < 16; i++) g.push(cyl([0, -0.07 + i * 0.037, -0.06], [0, -0.07 + i * 0.037 + 0.026, -0.06], 0.016));
      for (let i = 0; i < 4; i++) g.push(cyl([0, 0.53 + i * 0.03, -0.035], [0, 0.55 + i * 0.03, -0.03], 0.012));
      return g;
    },
  },
  { ref: 'bone.sacrum', seg: 'pelvis', sided: false, geoms: () => [cyl([0, 0.06, -0.075], [0, -0.06, -0.09], 0.012, 0.035)] },
  {
    ref: 'bone.ribs', seg: 'torso', sided: false, geoms: () => {
      const g: BufferGeometry[] = [];
      for (let i = 0; i < 9; i++) {
        const y = 0.17 + i * 0.033;
        const rx = 0.11 + Math.sin((i / 8) * Math.PI * 0.9) * 0.035;
        const t = new TorusGeometry(1, 0.007 / rx, 6, 36, Math.PI * 1.75);
        t.rotateX(Math.PI / 2);
        t.rotateY(-Math.PI / 2 - Math.PI * 0.125);
        t.scale(rx, 1, rx * 0.72);
        t.translate(0, y, -0.005);
        g.push(t);
      }
      return g;
    },
  },
  { ref: 'bone.sternum', seg: 'torso', sided: false, geoms: () => [box([0, 0.34, 0.088], [0.03, 0.17, 0.014])] },
  { ref: 'bone.clavicle', seg: 'torso', sided: true, geoms: () => [cyl([0.02, 0.44, 0.075], [0.11, 0.455, 0.06], 0.0085), cyl([0.11, 0.455, 0.06], [0.195, 0.46, 0.0], 0.0085)] },
  {
    ref: 'bone.scapula', seg: 'torso', sided: true, geoms: () => {
      const sh = new Shape([new Vector2(0.06, 0.44), new Vector2(0.17, 0.44), new Vector2(0.09, 0.27)]);
      const g = new ExtrudeGeometry(sh, { depth: 0.008, bevelEnabled: false });
      g.translate(0, 0, -0.095);
      return [g, cyl([0.065, 0.42, -0.095], [0.2, 0.465, -0.04], 0.007), sph([0.18, 0.41, -0.02], 0.022, [0.6, 1, 1])];
    },
  },
  { ref: 'bone.humerus', seg: 'upperArm', sided: true, geoms: () => [sph([0, 0, -0.005], 0.028), cyl([0, -0.02, 0], [0, -0.275, 0], 0.012, 0.011), sph([0, -0.29, 0], 0.022, [1.6, 0.7, 0.8])] },
  { ref: 'bone.radius', seg: 'forearm', sided: true, geoms: () => [cyl([0.018, -0.01, 0.006], [0.024, -0.25, 0.0], 0.008, 0.012)] },
  { ref: 'bone.ulna', seg: 'forearm', sided: true, geoms: () => [cyl([-0.012, 0.015, -0.02], [-0.018, -0.25, 0.0], 0.011, 0.007), sph([-0.005, 0.015, -0.025], 0.014)] },
  {
    ref: 'bone.hand', seg: 'hand', sided: true, geoms: () => {
      const g = [box([0, -0.045, 0], [0.075, 0.08, 0.02])];
      for (let i = 0; i < 4; i++) { const x = -0.027 + i * 0.018; g.push(cyl([x, -0.085, 0], [x, -0.16 + Math.abs(i - 1.5) * 0.01, 0], 0.006, 0.0045)); }
      g.push(cyl([0.04, -0.03, 0.01], [0.06, -0.09, 0.02], 0.007, 0.005));
      return g;
    },
  },
  {
    ref: 'bone.pelvis', seg: 'pelvis', sided: true, geoms: () => [
      sph([0.1, 0.05, -0.02], 0.065, [1, 1.05, 0.32]).rotateY(-0.5),
      sph([0.09, -0.06, 0.0], 0.028),
      cyl([0.08, -0.05, 0.035], [0.008, -0.04, 0.075], 0.011),
      cyl([0.075, -0.07, -0.02], [0.06, -0.11, -0.05], 0.013),
    ],
  },
  {
    ref: 'bone.femur', seg: 'thigh', sided: true, geoms: () => [
      sph([0, 0, 0], 0.023), cyl([0, 0, 0], [0.05, -0.03, 0], 0.012), sph([0.058, -0.02, -0.005], 0.017),
      cyl([0.048, -0.04, 0], [0, -0.395, 0.005], 0.015, 0.014), sph([0, -0.415, -0.005], 0.024, [1.7, 0.75, 1.1]),
    ],
  },
  { ref: 'bone.patella', seg: 'thigh', sided: true, geoms: () => [sph([0, -0.42, 0.045], 0.02, [1, 1.2, 0.5])] },
  { ref: 'bone.tibia', seg: 'shank', sided: true, geoms: () => [cyl([0, -0.005, 0], [0, -0.03, 0], 0.04, 0.035), cyl([0, -0.03, 0.006], [0, -0.395, 0], 0.016, 0.013), sph([-0.02, -0.405, 0], 0.012)] },
  { ref: 'bone.fibula', seg: 'shank', sided: true, geoms: () => [cyl([0.042, -0.035, -0.012], [0.035, -0.41, -0.005], 0.006), sph([0.042, -0.03, -0.012], 0.01), sph([0.035, -0.41, -0.005], 0.011)] },
  { ref: 'bone.calcaneus', seg: 'foot', sided: true, geoms: () => [box([0, -0.05, -0.03], [0.045, 0.045, 0.075])] },
  {
    ref: 'bone.foot', seg: 'foot', sided: true, geoms: () => {
      const g = [box([0, -0.035, 0.0], [0.04, 0.03, 0.04]), box([-0.005, -0.055, 0.085], [0.07, 0.022, 0.1])];
      for (let i = 0; i < 5; i++) { const x = -0.03 + i * 0.015; g.push(cyl([x, -0.062, 0.135], [x, -0.065, 0.17 - i * 0.004], 0.0055, 0.0045)); }
      return g;
    },
  },
];

/* ───────────── shells (skin / fat / fascia) ───────────── */

type ShellBuild = { seg: BaseSeg; sided: boolean; geom: () => BufferGeometry };
const SHELLS: ShellBuild[] = [
  {
    seg: 'torso', sided: false, geom: () => {
      const prof: [number, number][] = [[0.0, -0.1], [0.14, -0.09], [0.135, 0.05], [0.15, 0.2], [0.17, 0.34], [0.205, 0.44], [0.13, 0.5], [0.055, 0.53], [0.0, 0.535]];
      const g = new LatheGeometry(prof.map(([r, y]) => new Vector2(r, y)), 28);
      g.scale(1, 1, 0.72);
      return g;
    },
  },
  { seg: 'torso', sided: false, geom: () => cyl([0, 0.5, -0.01], [0, 0.6, 0.0], 0.05, 0.048) },
  { seg: 'pelvis', sided: false, geom: () => sph([0, -0.03, -0.01], 1, [0.175, 0.13, 0.135]) },
  { seg: 'head', sided: false, geom: () => sph([0, 0.12, 0.01], 0.105, [0.88, 1.1, 1.05]) },
  { seg: 'upperArm', sided: true, geom: () => taper(0.3, 0.055, 0.042, 1) },
  { seg: 'forearm', sided: true, geom: () => taper(0.25, 0.045, 0.03, 0.8) },
  { seg: 'hand', sided: true, geom: () => box([0, -0.09, 0], [0.085, 0.17, 0.03]) },
  { seg: 'thigh', sided: true, geom: () => taper(0.43, 0.09, 0.055, 1) },
  { seg: 'shank', sided: true, geom: () => taper(0.42, 0.06, 0.035, 1) },
  { seg: 'foot', sided: true, geom: () => box([0, -0.045, 0.055], [0.08, 0.06, 0.25]) },
];

/* ───────────── provider ───────────── */

export class ProceduralAssetProvider implements AnatomyAssetProvider {
  readonly id = 'procedural-placeholder';

  async load(onProgress?: (f: number) => void): Promise<AnatomyAsset> {
    const scene = new Group();
    scene.name = 'anatomy-asset';
    const rig = buildRig();
    scene.add(rig.root);
    const deformables = new Group();
    deformables.name = 'deformables';
    scene.add(deformables);

    const parts: AnatomyPart[] = [];
    const strands: StrandMesh[] = [];
    const segOf = (base: BaseSeg, side: Side): Object3D => {
      const sided = ['upperArm', 'forearm', 'hand', 'thigh', 'shank', 'foot'].includes(base);
      return rig.segments[(sided ? base + side : base) as SegmentId];
    };
    const anchorsOf = (path: A[], side: Side): Anchor[] =>
      path.map(([seg, x, y, z]) => ({ seg: segOf(seg, side), local: new Vector3(side === 'L' ? x : -x, y, z) }));

    const mat = (color: number, opacity = 1, extra: MeshStandardMaterialParameters = {}) =>
      new MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.02, transparent: opacity < 1, opacity, depthWrite: opacity >= 1, ...extra });

    const addPart = (p: Omit<AnatomyPart, 'meshes'>, meshes: Mesh[]) => {
      for (const m of meshes) m.userData.partIndex = parts.length;
      parts.push({ ...p, meshes });
    };

    // Muscles + tendons
    for (const muscle of data.muscles) {
      const specs = MUSCLE_SPECS[muscle.id];
      if (!specs) continue;
      const layer: LayerId = muscle.depth === 'deep' ? 'deepMuscles' : 'superficialMuscles';
      const baseColor = muscle.depth === 'deep' ? COLORS.muscleDeep : COLORS.muscle;
      for (const side of ['L', 'R'] as Side[]) {
        const bellies: Mesh[] = [];
        const tendons: Mesh[] = [];
        const bm = mat(baseColor);
        const tm = mat(COLORS.tendon);
        for (const s of specs) {
          const anchors = anchorsOf(s.path, side);
          const hx = s.hint ? new Vector3(side === 'L' ? s.hint[0] : -s.hint[0], s.hint[1], s.hint[2]) : undefined;
          const ts = s.ts ?? 0.04;
          const te = s.te ?? 0.08;
          const belly = new StrandMesh({ anchors, width: s.w, depth: s.d, hint: hx, range: [ts, 1 - te], profile: 'belly', bulge: true }, bm);
          bellies.push(belly);
          strands.push(belly);
          const tr = Math.min(s.w, s.d) * 0.32;
          if (ts > 0.01) { const t = new StrandMesh({ anchors, width: tr * 1.4, depth: tr, hint: hx, range: [0, ts + 0.01], profile: 'tube', rings: 6, radial: 6 }, tm); tendons.push(t); strands.push(t); }
          if (te > 0.01) { const t = new StrandMesh({ anchors, width: tr * 1.4, depth: tr, hint: hx, range: [1 - te - 0.01, 1], profile: 'tube', rings: 8, radial: 6 }, tm); tendons.push(t); strands.push(t); }
        }
        deformables.add(...bellies, ...tendons);
        addPart({ ref: muscle.modelReference, kind: 'muscle', side, layer, subpart: 'belly', baseColor, baseOpacity: 1, pickable: true }, bellies);
        if (tendons.length) addPart({ ref: muscle.modelReference, kind: 'muscle', side, layer: 'tendons', subpart: 'tendon', baseColor: COLORS.tendon, baseOpacity: 1, pickable: true }, tendons);
      }
    }
    onProgress?.(0.4);

    // Nerves / vessels / ligaments (tubes)
    const tubes = (kind: StructureKind, ref: string, layer: LayerId, color: number, paths: A[][], r: number) => {
      for (const side of ['L', 'R'] as Side[]) {
        const m = mat(color, 1, { emissive: kind === 'nerve' ? color : 0x000000, emissiveIntensity: kind === 'nerve' ? 0.15 : 0 });
        const meshes = paths.map((p) => {
          const s = new StrandMesh({ anchors: anchorsOf(p, side), width: r, depth: r, profile: 'tube', rings: Math.max(6, p.length * 6), radial: 6 }, m);
          strands.push(s);
          return s;
        });
        deformables.add(...meshes);
        addPart({ ref, kind, side, layer, baseColor: color, baseOpacity: 1, pickable: true }, meshes);
      }
    };
    for (const n of data.nerves) { const p = NERVE_SPECS[n.id]; if (p) tubes('nerve', n.modelReference, 'nerves', COLORS.nerve, p, 0.0035); }
    for (const v of data.vessels) {
      const specs = VESSEL_SPECS[v.id];
      if (!specs) continue;
      if (v.id === 'aorta') {
        const m = mat(COLORS.artery);
        const s = new StrandMesh({ anchors: anchorsOf(specs[0].path, 'L'), width: specs[0].r, depth: specs[0].r, profile: 'tube', rings: 24, radial: 8 }, m);
        strands.push(s); deformables.add(s);
        addPart({ ref: v.modelReference, kind: 'vessel', layer: 'vessels', baseColor: COLORS.artery, baseOpacity: 1, pickable: true }, [s]);
      } else tubes('vessel', v.modelReference, 'vessels', v.vesselType === 'artery' ? COLORS.artery : COLORS.vein, specs.map((s) => s.path), specs[0].r);
    }
    for (const l of data.ligaments) { const s = LIGAMENT_SPECS[l.id]; if (s) tubes('ligament', l.modelReference, 'ligaments', COLORS.ligament, [s.path], s.r); }
    onProgress?.(0.7);

    // Bones (static, parented to segments; right side mirrored by negative scale)
    for (const b of BONE_BUILDS) {
      for (const side of (b.sided ? ['L', 'R'] : ['L']) as Side[]) {
        const holder = new Group();
        if (side === 'R') holder.scale.x = -1;
        segOf(b.seg, side).add(holder);
        const m = mat(COLORS.bone, 1, { roughness: 0.75 });
        const meshes = b.geoms().map((g) => new Mesh(g, m));
        holder.add(...meshes);
        addPart({ ref: b.ref, kind: 'bone', side: b.sided ? side : undefined, layer: 'bones', baseColor: COLORS.bone, baseOpacity: 1, pickable: true }, meshes);
      }
    }

    // Shells
    const shellLayers: { layer: LayerId; color: number; opacity: number; scale: number }[] = [
      { layer: 'skin', color: COLORS.skin, opacity: 0.28, scale: 1.0 },
      { layer: 'fat', color: COLORS.fat, opacity: 0.2, scale: 0.97 },
      { layer: 'fascia', color: COLORS.fascia, opacity: 0.14, scale: 0.94 },
    ];
    for (const sl of shellLayers) {
      const meshes: Mesh[] = [];
      const m = mat(sl.color, sl.opacity, { side: DoubleSide, roughness: 0.9 });
      for (const sh of SHELLS) {
        for (const side of (sh.sided ? ['L', 'R'] : ['L']) as Side[]) {
          const g = sh.geom();
          g.scale(sl.scale, 1, sl.scale);
          const mesh = new Mesh(g, m);
          mesh.renderOrder = 10 - shellLayers.indexOf(sl);
          if (side === 'R') mesh.scale.x = -1;
          segOf(sh.seg, side).add(mesh);
          meshes.push(mesh);
        }
      }
      addPart({ ref: `layer.${sl.layer}`, kind: 'shell', layer: sl.layer, baseColor: sl.color, baseOpacity: sl.opacity, pickable: false }, meshes);
    }
    onProgress?.(1);

    const updateDeformation = () => {
      scene.updateMatrixWorld(true);
      const inv = StrandMesh.parentInverse(deformables);
      for (const s of strands) s.update(inv);
    };
    updateDeformation();

    return {
      scene,
      rig,
      parts,
      updateDeformation,
      attribution: 'מודל זמני שנבנה בקוד לצורך פיתוח (ללא נכסי צד שלישי). אינו מדויק אנטומית.',
      isPlaceholder: true,
      dispose: () => {
        scene.traverse((o) => {
          const m = o as Mesh;
          if (m.isMesh) {
            m.geometry.dispose();
            (Array.isArray(m.material) ? m.material : [m.material]).forEach((x: Material) => x.dispose());
          }
        });
      },
    };
  }
}
