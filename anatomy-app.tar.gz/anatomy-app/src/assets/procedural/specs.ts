/**
 * Geometry specification of the PROCEDURAL PLACEHOLDER body.
 *
 * ⚠ This is NOT anatomical geometry. It only places simplified strands roughly where the real
 * structures are, so selection, layers, isolation, colouring and animation can be developed and
 * tested end-to-end. Replace with a licensed anatomical model via an AssetProvider.
 *
 * Coordinates: metres, +Y up, the figure faces +Z, LEFT side of the figure is +X.
 * Anchors are given for the LEFT side as [segment, x, y, z] in that segment's local space and
 * mirrored automatically for the right side.
 */

export type BaseSeg = 'pelvis' | 'torso' | 'head' | 'upperArm' | 'forearm' | 'hand' | 'thigh' | 'shank' | 'foot';
export type A = [BaseSeg, number, number, number];

export interface StrandSpec {
  path: A[];
  w: number; // half width
  d: number; // half depth
  hint?: [number, number, number];
  /** tendon fractions at start / end of the path */
  ts?: number;
  te?: number;
}

/** Rig dimensions (m). */
export const DIM = {
  pelvisY: 1.0,
  hip: [0.09, -0.06, 0] as const,
  lumbar: [0, 0.08, 0] as const,
  shoulder: [0.19, 0.42, 0] as const,
  neck: [0, 0.5, 0] as const,
  upperArm: 0.3,
  forearm: 0.26,
  hand: 0.18,
  thigh: 0.43,
  shank: 0.42,
};

/** Muscles – keyed by data id. */
export const MUSCLE_SPECS: Record<string, StrandSpec[]> = {
  biceps_brachii: [
    { path: [['torso', 0.165, 0.405, 0.045], ['upperArm', 0.0, -0.08, 0.045], ['upperArm', 0, -0.22, 0.045], ['forearm', 0, -0.04, 0.02]], w: 0.03, d: 0.026, ts: 0.18, te: 0.12, hint: [0, 0, 1] },
  ],
  brachialis: [
    { path: [['upperArm', 0, -0.14, 0.012], ['upperArm', 0, -0.25, 0.02], ['forearm', 0, -0.035, 0.0]], w: 0.032, d: 0.018, ts: 0.05, te: 0.15, hint: [0, 0, 1] },
  ],
  brachioradialis: [
    { path: [['upperArm', 0.032, -0.19, 0.0], ['forearm', 0.035, -0.05, 0.02], ['forearm', 0.025, -0.24, 0.015]], w: 0.02, d: 0.018, ts: 0.05, te: 0.4, hint: [1, 0, 0.3] },
  ],
  triceps_brachii: [
    { path: [['torso', 0.165, 0.385, -0.045], ['upperArm', -0.005, -0.1, -0.04], ['upperArm', 0, -0.26, -0.035], ['forearm', 0, 0.02, -0.03]], w: 0.024, d: 0.02, ts: 0.12, te: 0.18, hint: [0, 0, -1] },
    { path: [['upperArm', 0.028, -0.06, -0.02], ['upperArm', 0.02, -0.18, -0.038], ['forearm', 0, 0.02, -0.03]], w: 0.022, d: 0.02, ts: 0.02, te: 0.25, hint: [0.4, 0, -1] },
    { path: [['upperArm', -0.02, -0.13, -0.018], ['upperArm', -0.012, -0.22, -0.03], ['forearm', 0, 0.02, -0.03]], w: 0.02, d: 0.016, ts: 0.02, te: 0.2, hint: [-0.4, 0, -1] },
  ],
  deltoid: [
    { path: [['torso', 0.135, 0.455, 0.06], ['torso', 0.205, 0.43, 0.06], ['upperArm', 0.025, -0.14, 0.022]], w: 0.026, d: 0.014, ts: 0.02, te: 0.12, hint: [0.3, 0.2, 1] },
    { path: [['torso', 0.205, 0.475, 0.0], ['torso', 0.245, 0.43, 0.0], ['upperArm', 0.036, -0.14, 0.0]], w: 0.03, d: 0.015, ts: 0.02, te: 0.12, hint: [1, 0.2, 0] },
    { path: [['torso', 0.15, 0.455, -0.07], ['torso', 0.205, 0.43, -0.06], ['upperArm', 0.025, -0.14, -0.02]], w: 0.026, d: 0.014, ts: 0.02, te: 0.12, hint: [0.3, 0.2, -1] },
  ],
  supraspinatus: [
    { path: [['torso', 0.07, 0.43, -0.08], ['torso', 0.15, 0.45, -0.04], ['upperArm', 0.025, 0.01, 0.0]], w: 0.016, d: 0.012, ts: 0.0, te: 0.2, hint: [0, 1, 0] },
  ],
  pectoralis_major: [
    { path: [['torso', 0.05, 0.455, 0.085], ['torso', 0.13, 0.43, 0.085], ['upperArm', 0.012, -0.07, 0.03]], w: 0.03, d: 0.011, te: 0.12, hint: [0, 0.2, 1] },
    { path: [['torso', 0.02, 0.39, 0.105], ['torso', 0.11, 0.38, 0.1], ['upperArm', 0.01, -0.075, 0.03]], w: 0.035, d: 0.012, te: 0.12, hint: [0, 0, 1] },
    { path: [['torso', 0.03, 0.29, 0.105], ['torso', 0.12, 0.33, 0.085], ['upperArm', 0.008, -0.08, 0.028]], w: 0.032, d: 0.012, te: 0.12, hint: [0, 0, 1] },
  ],
  latissimus_dorsi: [
    { path: [['torso', 0.02, 0.26, -0.11], ['torso', 0.12, 0.3, -0.095], ['torso', 0.17, 0.35, -0.04], ['upperArm', -0.012, -0.07, 0.01]], w: 0.04, d: 0.01, te: 0.1, hint: [0, 0, -1] },
    { path: [['torso', 0.03, 0.1, -0.1], ['torso', 0.13, 0.22, -0.09], ['torso', 0.175, 0.34, -0.035], ['upperArm', -0.012, -0.075, 0.01]], w: 0.045, d: 0.01, te: 0.1, hint: [0, 0, -1] },
    { path: [['pelvis', 0.12, 0.08, -0.05], ['torso', 0.15, 0.15, -0.07], ['torso', 0.18, 0.33, -0.03], ['upperArm', -0.012, -0.08, 0.012]], w: 0.035, d: 0.01, te: 0.1, hint: [1, 0, -1] },
  ],
  trapezius: [
    { path: [['torso', 0.0, 0.6, -0.06], ['torso', 0.06, 0.5, -0.06], ['torso', 0.17, 0.46, -0.02]], w: 0.03, d: 0.011, hint: [0, 1, -0.6] },
    { path: [['torso', 0.0, 0.43, -0.11], ['torso', 0.08, 0.44, -0.1], ['torso', 0.16, 0.45, -0.06]], w: 0.035, d: 0.01, hint: [0, 0, -1] },
    { path: [['torso', 0.0, 0.2, -0.115], ['torso', 0.06, 0.32, -0.11], ['torso', 0.11, 0.42, -0.095]], w: 0.035, d: 0.01, hint: [0, 0, -1] },
  ],
  rectus_abdominis: [
    { path: [['pelvis', 0.025, 0.0, 0.1], ['torso', 0.04, 0.05, 0.115], ['torso', 0.045, 0.18, 0.12], ['torso', 0.05, 0.29, 0.115]], w: 0.034, d: 0.011, hint: [0, 0, 1] },
  ],
  erector_spinae: [
    { path: [['pelvis', 0.03, 0.03, -0.1], ['torso', 0.032, 0.08, -0.105], ['torso', 0.035, 0.25, -0.1], ['torso', 0.03, 0.47, -0.065]], w: 0.02, d: 0.018, ts: 0.05, te: 0.05, hint: [0, 0, -1] },
  ],
  gluteus_maximus: [
    { path: [['pelvis', 0.05, 0.08, -0.11], ['pelvis', 0.11, 0.0, -0.12], ['thigh', 0.055, -0.1, -0.03]], w: 0.05, d: 0.03, te: 0.1, hint: [0, 0, -1] },
    { path: [['pelvis', 0.02, -0.02, -0.11], ['pelvis', 0.08, -0.09, -0.115], ['thigh', 0.045, -0.14, -0.03]], w: 0.045, d: 0.028, te: 0.12, hint: [0, -0.2, -1] },
  ],
  gluteus_medius: [
    { path: [['pelvis', 0.11, 0.1, -0.04], ['pelvis', 0.135, 0.03, -0.02], ['thigh', 0.07, 0.0, 0.0]], w: 0.04, d: 0.016, te: 0.12, hint: [1, 0, -0.2] },
  ],
  iliopsoas: [
    { path: [['torso', 0.03, 0.1, -0.03], ['pelvis', 0.05, 0.0, 0.0], ['pelvis', 0.075, -0.05, 0.05], ['thigh', -0.02, -0.06, 0.0]], w: 0.02, d: 0.018, te: 0.15, hint: [0, 0, 1] },
  ],
  sartorius: [
    { path: [['pelvis', 0.125, 0.04, 0.06], ['thigh', 0.01, -0.14, 0.075], ['thigh', -0.05, -0.34, 0.03], ['shank', -0.04, -0.07, 0.025]], w: 0.014, d: 0.008, ts: 0.04, te: 0.12, hint: [0, 0, 1] },
  ],
  rectus_femoris: [
    { path: [['pelvis', 0.085, -0.02, 0.06], ['thigh', 0.005, -0.15, 0.07], ['thigh', 0, -0.36, 0.065], ['shank', 0, -0.065, 0.045]], w: 0.026, d: 0.022, ts: 0.08, te: 0.28, hint: [0, 0, 1] },
  ],
  vastus_lateralis: [
    { path: [['thigh', 0.055, -0.04, 0.0], ['thigh', 0.065, -0.22, 0.02], ['thigh', 0.025, -0.4, 0.05], ['shank', 0, -0.06, 0.045]], w: 0.03, d: 0.024, te: 0.25, hint: [1, 0, 0.4] },
  ],
  vastus_medialis: [
    { path: [['thigh', -0.015, -0.12, 0.02], ['thigh', -0.045, -0.33, 0.035], ['thigh', -0.01, -0.42, 0.055], ['shank', 0, -0.06, 0.045]], w: 0.028, d: 0.022, te: 0.22, hint: [-1, 0, 0.5] },
  ],
  vastus_intermedius: [
    { path: [['thigh', 0.012, -0.07, 0.025], ['thigh', 0.01, -0.3, 0.038], ['thigh', 0, -0.41, 0.05], ['shank', 0, -0.06, 0.04]], w: 0.025, d: 0.014, te: 0.25, hint: [0, 0, 1] },
  ],
  biceps_femoris: [
    { path: [['pelvis', 0.065, -0.11, -0.065], ['thigh', 0.03, -0.22, -0.065], ['thigh', 0.055, -0.4, -0.04], ['shank', 0.045, -0.035, -0.01]], w: 0.024, d: 0.022, ts: 0.06, te: 0.2, hint: [0.3, 0, -1] },
    { path: [['thigh', 0.03, -0.2, -0.03], ['thigh', 0.05, -0.33, -0.035], ['shank', 0.045, -0.035, -0.01]], w: 0.018, d: 0.014, te: 0.25, hint: [1, 0, -0.5] },
  ],
  semitendinosus: [
    { path: [['pelvis', 0.05, -0.11, -0.06], ['thigh', -0.01, -0.2, -0.065], ['thigh', -0.045, -0.39, -0.035], ['shank', -0.04, -0.075, 0.02]], w: 0.022, d: 0.02, ts: 0.05, te: 0.38, hint: [-0.3, 0, -1] },
  ],
  gastrocnemius: [
    { path: [['thigh', -0.03, -0.4, -0.03], ['shank', -0.03, -0.12, -0.055], ['shank', -0.005, -0.3, -0.045], ['foot', 0, -0.045, -0.065]], w: 0.025, d: 0.022, ts: 0.06, te: 0.38, hint: [-0.3, 0, -1] },
    { path: [['thigh', 0.03, -0.4, -0.03], ['shank', 0.028, -0.12, -0.052], ['shank', 0.005, -0.3, -0.045], ['foot', 0, -0.045, -0.065]], w: 0.023, d: 0.02, ts: 0.06, te: 0.38, hint: [0.3, 0, -1] },
  ],
  soleus: [
    { path: [['shank', 0.01, -0.06, -0.03], ['shank', 0, -0.22, -0.042], ['shank', 0, -0.34, -0.038], ['foot', 0, -0.045, -0.06]], w: 0.032, d: 0.014, te: 0.3, hint: [0, 0, -1] },
  ],
  tibialis_anterior: [
    { path: [['shank', 0.025, -0.05, 0.03], ['shank', 0.022, -0.24, 0.04], ['shank', 0.0, -0.4, 0.04], ['foot', -0.025, -0.035, 0.085]], w: 0.016, d: 0.015, te: 0.38, hint: [0.4, 0, 1] },
  ],
};

/** Nerve paths – keyed by data id. */
export const NERVE_SPECS: Record<string, A[][]> = {
  musculocutaneous: [[['torso', 0.13, 0.38, 0.0], ['upperArm', -0.012, -0.06, 0.01], ['upperArm', 0.0, -0.18, 0.022], ['forearm', 0.02, -0.03, 0.012], ['forearm', 0.025, -0.14, 0.015]]],
  radial: [[['torso', 0.12, 0.38, -0.02], ['upperArm', -0.012, -0.06, -0.022], ['upperArm', 0.0, -0.15, -0.028], ['upperArm', 0.03, -0.24, 0.0], ['forearm', 0.022, -0.05, 0.008], ['forearm', 0.028, -0.2, 0.0]]],
  axillary: [[['torso', 0.13, 0.38, -0.03], ['upperArm', 0.0, -0.05, -0.028], ['upperArm', 0.028, -0.07, 0.0]]],
  suprascapular: [[['torso', 0.1, 0.47, -0.02], ['torso', 0.12, 0.435, -0.065]]],
  pectoral: [[['torso', 0.12, 0.39, 0.03], ['torso', 0.09, 0.37, 0.085]]],
  thoracodorsal: [[['torso', 0.13, 0.37, -0.04], ['torso', 0.135, 0.22, -0.075]]],
  accessory: [[['torso', 0.03, 0.6, -0.03], ['torso', 0.08, 0.5, -0.06]]],
  thoracoabdominal: [[['torso', 0.11, 0.25, 0.04], ['torso', 0.06, 0.15, 0.105]], [['torso', 0.11, 0.18, 0.03], ['torso', 0.06, 0.08, 0.105]]],
  posterior_rami: [[['torso', 0.012, 0.22, -0.085], ['torso', 0.035, 0.22, -0.1]], [['torso', 0.012, 0.08, -0.085], ['torso', 0.035, 0.08, -0.1]]],
  lumbar_plexus: [[['torso', 0.02, 0.06, -0.04], ['torso', 0.04, 0.03, -0.02]]],
  femoral: [[['torso', 0.04, 0.05, -0.01], ['pelvis', 0.07, -0.02, 0.05], ['thigh', -0.005, -0.05, 0.06], ['thigh', 0.0, -0.16, 0.06]]],
  superior_gluteal: [[['pelvis', 0.05, 0.0, -0.07], ['pelvis', 0.1, 0.05, -0.05]]],
  inferior_gluteal: [[['pelvis', 0.05, -0.03, -0.08], ['pelvis', 0.08, -0.06, -0.1]]],
  sciatic: [[['pelvis', 0.04, 0.0, -0.08], ['pelvis', 0.07, -0.08, -0.075], ['thigh', 0.01, -0.1, -0.05], ['thigh', 0.0, -0.34, -0.045]]],
  tibial: [[['thigh', 0.0, -0.34, -0.045], ['shank', 0.0, -0.05, -0.035], ['shank', -0.005, -0.38, -0.02], ['foot', -0.02, -0.04, 0.0]]],
  common_fibular: [[['thigh', 0.0, -0.34, -0.045], ['thigh', 0.04, -0.41, -0.03], ['shank', 0.045, -0.06, -0.005]]],
  deep_fibular: [[['shank', 0.045, -0.06, -0.005], ['shank', 0.02, -0.15, 0.022], ['shank', 0.012, -0.38, 0.03], ['foot', 0.0, -0.04, 0.08]]],
};

export const VESSEL_SPECS: Record<string, { path: A[]; r: number }[]> = {
  aorta: [{ path: [['torso', 0.0, 0.4, 0.02], ['torso', 0.012, 0.3, -0.035], ['torso', 0.008, 0.05, -0.045], ['pelvis', 0.0, 0.08, -0.03]], r: 0.012 }],
  brachial_artery: [{ path: [['torso', 0.11, 0.38, 0.01], ['upperArm', -0.022, -0.06, 0.008], ['upperArm', -0.02, -0.22, 0.018], ['forearm', -0.005, -0.05, 0.022]], r: 0.004 }],
  femoral_artery: [{ path: [['pelvis', 0.05, -0.0, 0.06], ['thigh', -0.02, -0.06, 0.055], ['thigh', -0.04, -0.28, 0.0], ['thigh', -0.01, -0.4, -0.04], ['shank', 0.0, -0.08, -0.035]], r: 0.005 }],
  femoral_vein: [{ path: [['pelvis', 0.035, -0.0, 0.055], ['thigh', -0.032, -0.06, 0.05], ['thigh', -0.048, -0.28, -0.005], ['thigh', -0.02, -0.4, -0.045], ['shank', -0.01, -0.08, -0.04]], r: 0.0055 }],
};

export const LIGAMENT_SPECS: Record<string, { path: A[]; r: number }> = {
  patellar_ligament: { path: [['thigh', 0, -0.445, 0.062], ['shank', 0, -0.065, 0.045]], r: 0.009 },
  mcl: { path: [['thigh', -0.045, -0.4, 0.0], ['shank', -0.042, -0.09, 0.0]], r: 0.006 },
  lcl: { path: [['thigh', 0.048, -0.405, -0.005], ['shank', 0.05, -0.05, -0.008]], r: 0.005 },
  ucl_elbow: { path: [['upperArm', -0.032, -0.29, 0.0], ['forearm', -0.022, -0.035, 0.0]], r: 0.005 },
  rcl_elbow: { path: [['upperArm', 0.032, -0.29, 0.0], ['forearm', 0.024, -0.035, 0.0]], r: 0.005 },
};
