import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './ui/App';
import './ui/styles.css';
import { controller } from './logic/controller';
import { store } from './logic/store';

// Debug handle for automated tests / devtools: open the app with ?debug
if (new URLSearchParams(location.search).has('debug')) Object.assign(window, { __app: { controller, store } });

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// PWA: register the service worker in production builds served over http(s).
if ('serviceWorker' in navigator && import.meta.env.PROD && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}
