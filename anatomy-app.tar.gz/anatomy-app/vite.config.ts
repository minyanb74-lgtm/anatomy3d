import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import { fileURLToPath, URL } from 'node:url';

/**
 * `npm run build`         → regular PWA build (dist/) with code-split chunks.
 * `npm run build:single`  → a single self-contained HTML (dist-single/) for quick sharing/preview.
 */
export default defineConfig(({ mode }) => ({
  base: './',
  plugins: [react(), ...(mode === 'single' ? [viteSingleFile()] : [])],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  build: {
    outDir: mode === 'single' ? 'dist-single' : 'dist',
    target: 'es2020',
    chunkSizeWarningLimit: 1200,
    rollupOptions:
      mode === 'single'
        ? {}
        : { output: { manualChunks: { three: ['three'], react: ['react', 'react-dom'] } } },
  },
}));
