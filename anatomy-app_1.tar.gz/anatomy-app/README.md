# אנטומיה תלת־ממדית – Mobile-first

אפליקציית לימוד אנטומיה וביומכניקה לטלפון: גוף תלת־ממדי, שכבות, בחירה/הסתרה/בידוד שרירים,
חיפוש בעברית/אנגלית/לטינית, תנועות ותרגילים באנימציה עם מערכת צבעי תפקידים, Timeline, ניתוח תנועה,
השוואות, בנה־תנועה, שלד, עצבוב, חתכים, למד־אותי, מבחנים ותצוגות שמורות.

## Tech Stack – ולמה

| שכבה | טכנולוגיה | סיבה |
|---|---|---|
| UI | React 18 + TypeScript | רכיבים לשימוש חוזר, טיפוסים לכל ה־Data |
| 3D | three.js (WebGL) | המנוע התלת־ממדי הבשל ביותר במובייל: Picking, Clipping planes, LOD, glTF/Draco/KTX2 |
| Build | Vite | בנייה מהירה, Code-splitting |
| הפצה | PWA (manifest + Service Worker) | התקנה למסך הבית, עבודה אופליין |
| Native (שלב הבא) | Capacitor | עוטף את אותו קוד ל־Android/iOS בלי לשכתב |

**למה לא React Native?** פתרונות ה־3D ב־RN (expo-gl / react-three-fiber/native) פחות בשלים
ב־Raycasting, Clipping, טעינת glTF דחוס וביצועים עקביים. WebGL + PWA + Capacitor נותן קוד אחד
לשלוש פלטפורמות עם מנוע 3D מלא.

## ארכיטקטורה

```
UI (React)  ──actions──▶  Business Logic (controller, search, quiz…)  ──▶  3D Engine (three.js)
   ▲                             │   ▲                                         │
   └──── useStore(selector) ◀── Store ─┘                                       ▼
                                 │                                    AssetProvider (abstraction)
                              Data Layer (muscles, bones, joints,       ├─ ProceduralAssetProvider (זמני)
                              nerves, movements, exercises, clips)      └─ GltfAssetProvider (מודל אמיתי)
```

- **Data** (`src/data`) – עובדות בלבד, ללא UI. כל מבנה מקושר למודל רק דרך `modelReference`.
  סימון אפיסטמי: `certainty` (מבוסס / וריאציה / שנוי במחלוקת), ו־`involvement` מסומן תמיד כהערכה.
  `DataRepository` בונה אינדקסים ויחסים הפוכים (שריר→תנועות, עצם→שרירים, עצב→שרירים) ומאמת הפניות ב־DEV.
- **Logic** (`src/logic`) – Store, `controller` (כל הפעולות), חיפוש + שאילתות מתקדמות, מערכת צבעים,
  Playback, בנה־תנועה (`composeMotions` – מוכן לתנועות מורכבות), מבחנים, תצוגות שמורות.
- **Engine** (`src/engine`) – רינדור לפי דרישה, מגע (OrbitControls: אצבע=סיבוב, שתיים=Pan/Zoom),
  Tap/Double-tap, Picking, סגנון חזותי, בידוד, חתכים, PoseDriver + Grounding, מצלמה שמתחשבת ב־Bottom Sheet.
- **Assets** (`src/assets`) – חוזה `AnatomyAsset` (Rig + Parts מתויגים בשכבה/צד/מבנה).

### החלפה למודל אנטומי אמיתי
1. מודל glTF 2.0 מורשה, Mesh נפרד לכל מבנה (מומלץ Draco/Meshopt + KTX2, ווריאנטים `_LOD1/_LOD2`).
2. Manifest לפי `GltfManifest` (`src/assets/gltf/GltfAssetProvider.ts`): שם Node → `modelReference`, שכבה, צד; Segments → עצמות שלד.
3. ב־`src/assets/index.ts` להחליף ל־`new GltfAssetProvider(manifest)`. שום דבר אחר לא משתנה.

### המודל האנטומי
המודל הוא **BodyParts3D** (© DBCLS, רישיון CC BY-SA 2.1 Japan) – גאומטריה שנבנתה מסריקות של גוף אמיתי,
כל שריר ועצם כמבנה נפרד. נבחרו רק שרירים, עצמות, רקמות חיבור וכלי דם גדולים (697 מבנים), הוקטנו ל־~366 אלף
משולשים ונדחסו ל־2MB (`public/models/bp3d.glb`). פרטי הרישיון ב־`public/models/NOTICE.txt`.

- **תנועה:** המודל המקורי סטטי. `Bp3dAssetProvider` בונה את השלד של האפליקציה ממרכזי מפרקים שנמדדו על העצמות
  ומחבר אליו כל מבנה אוטומטית (עצמות – חיבור קשיח; שרירים – משקלות לפי מרחק). זהו קירוב גאומטרי, לא סימולציית שריר.
- **לא קיים עדיין במודל:** עצבים היקפיים, עור ושומן. השכבות האלה מסומנות "לא קיים במודל הנוכחי".
- **יצירה מחדש:** `python3 tools/bp3d/convert.py <stl_dir> <selection.json> <out_dir>` ואז
  `npx gltf-transform meshopt <out>/bp3d.raw.glb public/models/bp3d.glb`.
- אם הקובץ חסר, האפליקציה עוברת אוטומטית למודל הזמני שנבנה בקוד.

## מבנה קבצים
```
src/
  data/       types, muscles, bones, joints, nerves, movements, exercises, kinematics, layers, index
  assets/     types, index, procedural/{specs, StrandMesh, ProceduralAssetProvider}, gltf/GltfAssetProvider
  engine/     Engine, PoseDriver, visualState
  logic/      store, controller, search, visualState, playback, motionBuilder, quiz, savedViews
  ui/         App, styles.css, hooks/useStore, components/{Common, BottomSheet, Chrome}, panels/{Structure, Motion, TabPanels, Modals}
public/       manifest.webmanifest, sw.js, icon.svg
```

## הרצה

דרישות: Node.js 18+.

```bash
npm install
npm run dev          # שרת פיתוח – מודפסת כתובת רשת (Network) לפתיחה מהטלפון באותה רשת Wi-Fi
npm run build        # בנייה ל־dist/ (PWA)
npm run preview      # הגשת ה־build לבדיקה
npm run build:single # קובץ HTML יחיד ב־dist-single/ לשיתוף מהיר
npm run typecheck
```

התקנה כאפליקציה: לפתוח את הכתובת בטלפון (דרך HTTPS או localhost) → "הוסף למסך הבית".

אפליקציה נייטיב (שלב הבא):
```bash
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
npx cap init "Anatomy 3D" com.example.anatomy3d --web-dir dist
npm run build && npx cap add android && npx cap open android
```

## הוספת תוכן
- **שריר חדש**: רשומה ב־`data/muscles.ts` (+ גאומטריה זמנית ב־`assets/procedural/specs.ts`, או Node במודל ה־glTF).
- **תנועה/תרגיל**: רשומה ב־`movements.ts` / `exercises.ts` + Clip ב־`kinematics.ts`.
- החיפוש, המבחנים, ההשוואות והיחסים ההפוכים מתעדכנים אוטומטית.

## מה בשלב הבא
מודל אנטומי מורשה · שרירים נוספים (Serratus, Rhomboids, Adductors, אמה) · LOD אמיתי · Capacitor · בדיקות יחידה ל־search/quiz.
