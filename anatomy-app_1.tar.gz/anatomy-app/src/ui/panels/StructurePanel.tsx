/** Info for a selected 3D structure. Peek shows name + quick actions; swipe up for full info. */
import { data, REGION_NAMES, ROLE_META, type Muscle } from '@/data';
import { controller } from '@/logic/controller';
import { useStore } from '../hooks/useStore';
import { Accordion, Facts, MusclePill, SheetTop, certaintyTag } from '../components/Common';

export function StructurePanel() {
  const sel = useStore((s) => s.selection);
  const motion = useStore((s) => s.motion);
  if (!sel) return null;
  const back = motion ? () => controller.clearSelection() : undefined;
  switch (sel.kind) {
    case 'muscle': return <MuscleInfo m={data.muscle(sel.id)!} onBack={back} />;
    case 'bone': return <BoneInfo id={sel.id} onBack={back} />;
    case 'nerve': return <NerveInfo id={sel.id} onBack={back} />;
    case 'unlisted': return <UnlistedInfo onBack={back} />;
    default: return <SimpleInfo />;
  }
}

function QuickActions() {
  const isolated = useStore((s) => !!s.isolated);
  return (
    <div className="actions">
      <button className="btn" onClick={() => controller.hideSelected()}><span className="ico">👁</span>הסתר</button>
      {isolated
        ? <button className="btn primary" onClick={() => controller.exitIsolation()}><span className="ico">◎</span>בטל בידוד</button>
        : <button className="btn" onClick={() => controller.isolateSelected()}><span className="ico">◎</span>בודד</button>}
      <button className="btn" onClick={() => controller.setSheet('full')}><span className="ico">ℹ️</span>מידע מלא</button>
    </div>
  );
}

function MuscleInfo({ m, onBack }: { m: Muscle; onBack?: () => void }) {
  const motion = useStore((s) => s.motion);
  const role = motion?.roles.find((r) => r.muscleId === m.id);
  const movements = data.movementsForMuscle(m.id);
  const exercises = data.exercisesForMuscle(m.id);
  const rel = (label: string, ids: string[]) => ids.length ? (
    <div style={{ marginBottom: 10 }}>
      <div className="section-title" style={{ marginTop: 4 }}>{label}</div>
      <div className="pill-wrap">{ids.map((id) => <MusclePill key={id} id={id} />)}</div>
    </div>
  ) : null;
  return (
    <div>
      <SheetTop onBack={onBack}>
        <div className="title">{m.hebrewName}</div>
        <div className="subtitle"><span className="latin">{m.latinName}</span>{m.englishName !== m.latinName && <> · <span className="latin">{m.englishName}</span></>}</div>
      </SheetTop>
      {role && (
        <div className="info-box" style={{ marginTop: 0, display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="role-dot" style={{ background: ROLE_META[role.role].color }} />
          ב{motion!.title}: <b>{ROLE_META[role.role].single}</b> <span className="tag estimate">מעורבות משוערת {Math.round(role.involvement * 100)}%</span>
        </div>
      )}
      <QuickActions />

      <div className="section-title">פעולה עיקרית</div>
      <Facts items={m.primaryActions} />

      <Accordion title="📍 מוצא ואחז" open>
        <b>מוצא (Origin)</b><Facts items={m.origin} />
        <b>אחז (Insertion)</b><Facts items={m.insertion} />
      </Accordion>
      <Accordion title="⚡ עצבוב">
        {m.innervation.map((i, k) => <div className="fact" key={k}>• {i.text} {certaintyTag(i.certainty)}{i.note && <div className="note">{i.note}</div>}</div>)}
        <button className="btn small" style={{ marginTop: 8 }} onClick={() => controller.showInnervation(m.id)}>⚡ הצג עצבוב במודל</button>
      </Accordion>
      <Accordion title="↔️ פעולות משניות">
        <Facts items={m.secondaryActions} />
      </Accordion>
      <Accordion title={`🔄 משתתף בתנועות (${movements.length})`} open={!!movements.length}>
        <div className="list">
          {movements.map(({ movement, role: r }) => (
            <button key={movement.id} className="list-item" onClick={() => controller.playMovement(movement.id)}>
              <span className="role-dot" style={{ background: ROLE_META[r.role].color }} />
              <span className="main"><span className="t">{movement.hebrewName}</span><div className="s">{ROLE_META[r.role].single}</div></span>
              <span className="chev">▶</span>
            </button>
          ))}
          {!movements.length && <div className="empty">אין עדיין תנועות במאגר</div>}
        </div>
      </Accordion>
      <Accordion title={`🏋️ תרגילים (${exercises.length})`}>
        <div className="list">
          {exercises.map(({ exercise, role: r }) => (
            <button key={exercise.id} className="list-item" onClick={() => controller.playExercise(exercise.id)}>
              <span className="role-dot" style={{ background: ROLE_META[r.role].color }} />
              <span className="main"><span className="t">{exercise.hebrewName}</span><div className="s">{exercise.englishName} · {ROLE_META[r.role].single}</div></span>
              <span className="chev">▶</span>
            </button>
          ))}
        </div>
      </Accordion>
      <Accordion title="🤝 קשרים אנטומיים">
        {rel('אגוניסטים (פעולה משותפת)', m.agonists)}
        {rel('מסייעים / Synergists', m.synergists)}
        {rel('מייצבים / Stabilizers', m.stabilizers)}
        {rel('אנטגוניסטים / Antagonists', m.antagonists)}
        <div className="info-box" style={{ marginTop: 4 }}>הקשרים כאן הם ביחס לפעולה העיקרית. התפקיד המדויק משתנה לפי התנועה – ראה "משתתף בתנועות".</div>
      </Accordion>
      <Accordion title="🗂 מיקום ומפרקים">
        <dl className="kv">
          <dt>אזור</dt><dd>{REGION_NAMES[m.region]}</dd>
          <dt>עומק</dt><dd>{m.depth === 'deep' ? 'עמוק' : 'שטחי'}</dd>
          <dt>מיקום</dt><dd>{m.location}</dd>
          <dt>מפרקים</dt><dd>{m.relatedJoints.map((j) => data.joint(j)?.hebrewName).join(' · ')}</dd>
        </dl>
      </Accordion>
    </div>
  );
}

function BoneInfo({ id, onBack }: { id: string; onBack?: () => void }) {
  const b = data.bone(id)!;
  const att = data.musclesForBone(id);
  return (
    <div>
      <SheetTop onBack={onBack}>
        <div className="title">{b.hebrewName}</div>
        <div className="subtitle"><span className="latin">{b.latinName}</span></div>
      </SheetTop>
      <QuickActions />
      <p style={{ margin: '8px 0' }}>{b.summary}</p>
      <Facts items={b.facts} />
      <button className="btn block primary" style={{ marginTop: 12 }} onClick={() => controller.showBoneMuscles(id)}>💪 הצג שרירים המחוברים לעצם</button>
      <div className="section-title">שרירים המתחברים ({att.length})</div>
      <div className="pill-wrap">
        {att.map(({ muscle, via }) => (
          <button key={muscle.id} className="pill" onClick={() => controller.select('muscle', muscle.id)}>
            {muscle.hebrewName} <span className="tag model">{via.map((v) => (v === 'origin' ? 'מוצא' : 'אחז')).join('+')}</span>
          </button>
        ))}
        {!att.length && <div className="empty">אין שרירים במאגר שמתחברים לעצם זו</div>}
      </div>
      {!!b.ligaments.length && (
        <>
          <div className="section-title">רצועות</div>
          <div className="pill-wrap">
            {b.ligaments.map((l) => <button key={l} className="pill" onClick={() => controller.select('ligament', l)}>{data.ligament(l)?.hebrewName}</button>)}
          </div>
        </>
      )}
    </div>
  );
}

function NerveInfo({ id, onBack }: { id: string; onBack?: () => void }) {
  const n = data.nerve(id)!;
  const ms = data.musclesForNerve(id);
  return (
    <div>
      <SheetTop onBack={onBack}>
        <div className="title">{n.hebrewName}</div>
        <div className="subtitle"><span className="latin">{n.latinName}</span> · {n.roots}</div>
      </SheetTop>
      <QuickActions />
      <p>{n.summary}</p>
      {!controller.inModel(n.modelReference) && <div className="info-box" style={{ marginTop: 0 }}>העצב עדיין לא קיים במודל התלת־ממדי הנוכחי.</div>}
      <div className="section-title">שרירים שהוא מעצבב (מתוך המאגר)</div>
      <div className="pill-wrap">{ms.map((m) => <MusclePill key={m.id} id={m.id} />)}</div>
    </div>
  );
}

const UNLISTED_KIND: Record<string, string> = { muscle: 'שריר', bone: 'עצם', vessel: 'כלי דם', ligament: 'רקמת חיבור' };

/** A structure that is in the 3D model but has no data record yet. */
function UnlistedInfo({ onBack }: { onBack?: () => void }) {
  const sel = useStore((s) => s.selection)!;
  const u = sel.unlisted!;
  return (
    <div>
      <SheetTop onBack={onBack}>
        <div className="title"><span className="latin" style={{ fontStyle: 'normal' }}>{u.label}</span></div>
        <div className="subtitle">{UNLISTED_KIND[u.kind] ?? 'מבנה'}{sel.side ? ` · צד ${sel.side === 'L' ? 'שמאל' : 'ימין'}` : ''}</div>
      </SheetTop>
      <QuickActions />
      <div className="info-box">המבנה קיים במודל התלת־ממדי, אבל עדיין אין עליו מידע מפורט במאגר. אפשר להסתיר אותו, לבודד אותו ולסובב סביבו.</div>
    </div>
  );
}

function SimpleInfo() {
  const sel = useStore((s) => s.selection)!;
  if (sel.kind === 'unlisted') return null;
  const e = data.get(sel.kind, sel.id) as { hebrewName: string; latinName: string; summary?: string } | undefined;
  if (!e) return null;
  return (
    <div>
      <div className="title">{e.hebrewName}</div>
      <div className="subtitle"><span className="latin">{e.latinName}</span></div>
      <QuickActions />
      {e.summary && <p>{e.summary}</p>}
    </div>
  );
}
