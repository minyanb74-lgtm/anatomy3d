/** Modal sheets: search, layers, settings, menu, section, saved views, comparisons, motion builder. */
import { useEffect, useMemo, useRef, useState } from 'react';
import { data, LAYERS, ROLE_META, type Exercise, type Role } from '@/data';
import { controller } from '@/logic/controller';
import { advancedQuery, searchEntities } from '@/logic/search';
import { deleteView, listViews } from '@/logic/savedViews';
import { useStore } from '../hooks/useStore';
import { ModalSheet } from '../components/BottomSheet';

export function Modals() {
  const modal = useStore((s) => s.modal);
  const close = () => controller.closeModal();
  switch (modal) {
    case 'search': return <SearchModal onClose={close} />;
    case 'layers': return <LayersModal onClose={close} />;
    case 'settings': return <SettingsModal onClose={close} />;
    case 'menu': return <MenuModal onClose={close} />;
    case 'section': return <SectionModal onClose={close} />;
    case 'saved': return <SavedModal onClose={close} />;
    case 'compareExercises': return <CompareExercisesModal onClose={close} />;
    case 'compareMuscles': return <CompareMusclesModal onClose={close} />;
    case 'builder': return <BuilderModal onClose={close} />;
    default: return null;
  }
}

/* ───────────── חיפוש ───────────── */
const SUGGESTIONS = ['בייספס', 'כפיפת מרפק', 'Squat', 'מרפק', 'כל השרירים שעושים כפיפת ברך', 'שרירים שמתחברים לפמור', 'שרירים שעובדים ב־Deadlift', 'שרירי הכתף', 'שרירים שמבצעים הרחקת כתף', 'המסטרינג'];

function SearchModal({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState('');
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { setTimeout(() => input.current?.focus(), 80); }, []);
  const query = useMemo(() => (q.trim().length > 1 ? advancedQuery(q) : null), [q]);
  const hits = useMemo(() => searchEntities(q, 25), [q]);
  return (
    <ModalSheet title="חיפוש" onClose={onClose} full>
      <div className="search-field" style={{ padding: '0 0 10px' }}>
        <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="שריר, עצם, תנועה, תרגיל… (עברית / English / Latin)" enterKeyHint="search" aria-label="חיפוש"
          onKeyDown={(e) => { if (e.key === 'Enter') { if (query) controller.showQuery(query); else if (hits[0]) controller.select(hits[0].kind, hits[0].id); } }} />
      </div>
      {!q && (
        <>
          <div className="section-title" style={{ marginTop: 0 }}>נסה לחפש</div>
          <div className="suggest">{SUGGESTIONS.map((s) => <button key={s} className="pill" onClick={() => setQ(s)}>{s}</button>)}</div>
        </>
      )}
      {query && (
        <button className="list-item" style={{ background: 'var(--accent)', color: 'var(--accent-ink)', marginBottom: 10 }} onClick={() => controller.showQuery(query)}>
          <span className="main"><span className="t">🔎 {query.title}</span><div className="s" style={{ color: 'inherit', opacity: 0.85 }}>{query.groups.reduce((n, g) => n + g.muscles.length, 0)} שרירים · הצג מסווג</div></span>
          <span className="chev" style={{ color: 'inherit' }}>‹</span>
        </button>
      )}
      <div className="list">
        {hits.map((h) => (
          <button key={h.kind + h.id} className="list-item" onClick={() => controller.select(h.kind, h.id)}>
            <span className="main"><span className="t">{h.title}</span><div className="s">{h.subtitle}</div></span>
            <span className="chev">‹</span>
          </button>
        ))}
        {q && !hits.length && !query && <div className="empty">לא נמצאו תוצאות עבור "{q}"</div>}
      </div>
    </ModalSheet>
  );
}

/* ───────────── שכבות ───────────── */
const LAYER_COLORS: Record<string, string> = { skin: '#d7a07c', fat: '#f0d27a', fascia: '#a9d4f2', superficialMuscles: '#b8443d', deepMuscles: '#9c3a35', tendons: '#e6dcc4', ligaments: '#bfcab4', bones: '#e9e1c9', nerves: '#f4d34a', vessels: '#d22b2b' };
function LayersModal({ onClose }: { onClose: () => void }) {
  const layers = useStore((s) => s.layers);
  const available = useStore((s) => s.availableLayers);
  return (
    <ModalSheet title="🧬 שכבות" onClose={onClose}>
      {LAYERS.map((l) => {
        const has = available.includes(l.id);
        return (
          <button key={l.id} className="toggle-row" disabled={!has} style={has ? undefined : { opacity: 0.45 }} onClick={() => controller.toggleLayer(l.id)} role="switch" aria-checked={layers[l.id]}>
            <span className={`check${layers[l.id] && has ? ' on' : ''}`}>{layers[l.id] && has ? '✓' : ''}</span>
            <span className="swatch" style={{ background: LAYER_COLORS[l.id] }} />
            {l.hebrewName}
            {!has && <span className="tag model" style={{ marginInlineStart: 'auto' }}>לא קיים במודל הנוכחי</span>}
          </button>
        );
      })}
      <div className="row" style={{ marginTop: 12 }}>
        <button className="btn small" onClick={() => controller.resetLayers()}>ברירת מחדל</button>
        <button className="btn small" onClick={() => controller.skeletonMode()}>🦴 שלד בלבד</button>
        <button className="btn small" onClick={() => controller.setLayers(Object.fromEntries(LAYERS.map((l) => [l.id, true])) as never)}>הכול</button>
      </div>
      <div className="info-box">הסתרת שכבה חושפת את המבנים שמתחתיה.</div>
    </ModalSheet>
  );
}

/* ───────────── חתך אנטומי ───────────── */
function SectionModal({ onClose }: { onClose: () => void }) {
  const sec = useStore((s) => s.section);
  const axes = [{ id: 'sagittal', l: 'Sagittal' }, { id: 'coronal', l: 'Coronal' }, { id: 'transverse', l: 'Transverse' }] as const;
  return (
    <ModalSheet title="✂️ חתך אנטומי" onClose={onClose}>
      <button className="toggle-row" onClick={() => controller.setSection({ ...sec, enabled: !sec.enabled })} role="switch" aria-checked={sec.enabled}>
        <span className={`check${sec.enabled ? ' on' : ''}`}>{sec.enabled ? '✓' : ''}</span>הפעל חתך
      </button>
      <div className="section-title">מישור</div>
      <div className="seg">
        {axes.map((a) => <button key={a.id} className={sec.axis === a.id ? 'on' : ''} onClick={() => controller.setSection({ ...sec, axis: a.id, enabled: true })}><span className="latin" style={{ fontStyle: 'normal' }}>{a.l}</span></button>)}
      </div>
      <div className="section-title">מיקום המישור</div>
      <input className="big" type="range" min={-100} max={100} value={Math.round(sec.position * 100)} aria-label="מיקום מישור החיתוך"
        onChange={(e) => controller.setSection({ ...sec, enabled: true, position: Number(e.target.value) / 100 })} />
      <div className="info-box">
        Sagittal – חיתוך ימין/שמאל · Coronal – חיתוך קדמי/אחורי · Transverse – חיתוך רוחבי.
        הזז את המחוון כדי לחשוף מבנים בעומקים שונים.
      </div>
    </ModalSheet>
  );
}

/* ───────────── הגדרות ───────────── */
function SettingsModal({ onClose }: { onClose: () => void }) {
  const theme = useStore((s) => s.theme);
  const low = useStore((s) => s.lowPower);
  const attribution = useStore((s) => s.modelAttribution);
  return (
    <ModalSheet title="הגדרות" onClose={onClose}>
      <div className="section-title" style={{ marginTop: 0 }}>ערכת נושא</div>
      <div className="seg">
        <button className={theme === 'dark' ? 'on' : ''} onClick={() => controller.setTheme('dark')}>🌙 כהה</button>
        <button className={theme === 'light' ? 'on' : ''} onClick={() => controller.setTheme('light')}>☀️ בהיר</button>
      </div>
      <div className="section-title">ביצועים</div>
      <button className="toggle-row" onClick={() => controller.setLowPower(!low)} role="switch" aria-checked={low}>
        <span className={`check${low ? ' on' : ''}`}>{low ? '✓' : ''}</span>מצב חיסכון (רזולוציה נמוכה יותר)
      </button>
      <div className="section-title">על המודל והמידע</div>
      <div className="info-box" style={{ marginTop: 0 }}>
        {attribution}
        <br />המידע האנטומי מבוסס על ספרות אנטומית מקובלת. וריאציות ומחלוקות מסומנות בתגיות; עוצמות המעורבות הן הערכות להמחשה בלבד.
      </div>
    </ModalSheet>
  );
}

/* ───────────── תפריט ───────────── */
function MenuModal({ onClose }: { onClose: () => void }) {
  const items: [string, string, () => void][] = [
    ['💾', 'תצוגות שמורות', () => controller.openModal('saved')],
    ['🛠', 'בנה תנועה', () => controller.openModal('builder')],
    ['⚖️', 'השוואת תרגילים', () => controller.openModal('compareExercises')],
    ['⚖️', 'השוואת שרירים', () => controller.openModal('compareMuscles')],
    ['🦴', 'מצב שלד', () => { controller.skeletonMode(); onClose(); }],
    ['✂️', 'חתך אנטומי', () => controller.openModal('section')],
    ['📝', 'מבחן', () => { controller.startQuiz(); }],
    ['↺', 'הצג הכול ואפס', () => { controller.showAll(); controller.resetLayers(); controller.stopMotion(); controller.clearSelection(); controller.resetCamera(); onClose(); }],
  ];
  return (
    <ModalSheet title="תפריט" onClose={onClose}>
      <div className="list">
        {items.map(([i, t, f]) => (
          <button key={t} className="list-item" onClick={f}><span style={{ fontSize: 22 }}>{i}</span><span className="main"><span className="t">{t}</span></span><span className="chev">‹</span></button>
        ))}
      </div>
    </ModalSheet>
  );
}

/* ───────────── תצוגות שמורות ───────────── */
function SavedModal({ onClose }: { onClose: () => void }) {
  const [views, setViews] = useState(listViews);
  const [name, setName] = useState('');
  return (
    <ModalSheet title="💾 תצוגות שמורות" onClose={onClose}>
      <div className="row">
        <input className="select" style={{ flex: 1 }} placeholder='שם, למשל "שרירי הכתף העמוקים"' value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn primary" disabled={!name.trim()} onClick={() => { controller.saveCurrentView(name.trim()); setName(''); setViews(listViews()); }}>שמור</button>
      </div>
      <div className="info-box">נשמרים: שכבות, שרירים מוסתרים ומבודדים, בחירה, זווית מצלמה, תנועה ומיקום ב־Timeline.</div>
      <div className="list" style={{ marginTop: 12 }}>
        {views.map((v) => (
          <div key={v.id} className="list-item">
            <button className="main" style={{ textAlign: 'start' }} onClick={() => controller.loadView(v)}>
              <span className="t">{v.name}</span>
              <div className="s">{new Date(v.createdAt).toLocaleDateString('he-IL')}{v.motion ? ' · כולל תנועה' : ''}</div>
            </button>
            <button className="back-btn" aria-label="מחק" onClick={() => { deleteView(v.id); setViews(listViews()); }}>🗑</button>
          </div>
        ))}
        {!views.length && <div className="empty">עדיין אין תצוגות שמורות</div>}
      </div>
    </ModalSheet>
  );
}

/* ───────────── השוואות ───────────── */
const names = (ids: string[]) => ids.map((id) => data.muscle(id)?.hebrewName).filter(Boolean).join(', ') || '—';
const rolesOf = (e: Exercise, r: Role) => names(e.roles.filter((x) => x.role === r).map((x) => x.muscleId));

function CompareExercisesModal({ onClose }: { onClose: () => void }) {
  const [a, setA] = useState('squat');
  const [b, setB] = useState('leg_press');
  const A = data.exercise(a)!;
  const B = data.exercise(b)!;
  const joints = (e: Exercise) => e.joints.map((j) => data.joint(j.jointId)?.hebrewName).join(', ');
  const rom = (e: Exercise) => e.joints.map((j) => `${data.joint(j.jointId)?.hebrewName.replace('מפרק ', '')}: ${j.range}`).join(' · ');
  const sel = (v: string, set: (s: string) => void) => (
    <select className="select" value={v} onChange={(e) => set(e.target.value)}>{data.exercises.map((x) => <option key={x.id} value={x.id}>{x.hebrewName}</option>)}</select>
  );
  return (
    <ModalSheet title="⚖️ השוואת תרגילים" onClose={onClose} full>
      <div className="row">{sel(a, setA)}<b>מול</b>{sel(b, setB)}</div>
      <table className="cmp">
        <tbody>
          <tr><th>מפרקים</th><td>{joints(A)}</td><td>{joints(B)}</td></tr>
          <tr><th>טווח תנועה <span className="tag estimate">הערכה</span></th><td>{rom(A)}</td><td>{rom(B)}</td></tr>
          {(Object.keys(ROLE_META) as Role[]).map((r) => (
            <tr key={r}><th><span className="role-dot" style={{ display: 'inline-block', background: ROLE_META[r].color }} /> {ROLE_META[r].hebrew}</th><td>{rolesOf(A, r)}</td><td>{rolesOf(B, r)}</td></tr>
          ))}
          <tr><th>הערות</th><td>{A.phaseNote}</td><td>{B.phaseNote}</td></tr>
        </tbody>
      </table>
      <div className="row">
        <button className="btn small block" onClick={() => controller.playExercise(a)}>▶ {A.hebrewName}</button>
        <button className="btn small block" onClick={() => controller.playExercise(b)}>▶ {B.hebrewName}</button>
      </div>
    </ModalSheet>
  );
}

function CompareMusclesModal({ onClose }: { onClose: () => void }) {
  const [a, setA] = useState('biceps_brachii');
  const [b, setB] = useState('brachialis');
  const A = data.muscle(a)!;
  const B = data.muscle(b)!;
  const sel = (v: string, set: (s: string) => void) => (
    <select className="select" value={v} onChange={(e) => set(e.target.value)}>{data.muscles.map((x) => <option key={x.id} value={x.id}>{x.hebrewName}</option>)}</select>
  );
  const rows: [string, (m: typeof A) => string][] = [
    ['מיקום', (m) => m.location],
    ['מוצא', (m) => m.origin.map((x) => x.text).join(' · ')],
    ['אחז', (m) => m.insertion.map((x) => x.text).join(' · ')],
    ['עצבוב', (m) => m.innervation.map((x) => x.text).join(' · ')],
    ['פעולות', (m) => [...m.primaryActions, ...m.secondaryActions].map((x) => x.text).join(' · ')],
    ['תנועות', (m) => data.movementsForMuscle(m.id).map((x) => `${x.movement.hebrewName} (${ROLE_META[x.role.role].single})`).join(', ') || '—'],
    ['תרגילים', (m) => data.exercisesForMuscle(m.id).filter((x) => x.role.role !== 'antagonist').map((x) => x.exercise.hebrewName).join(', ') || '—'],
  ];
  return (
    <ModalSheet title="⚖️ השוואת שרירים" onClose={onClose} full>
      <div className="row">{sel(a, setA)}<b>VS</b>{sel(b, setB)}</div>
      <table className="cmp"><tbody>{rows.map(([l, f]) => <tr key={l}><th>{l}</th><td>{f(A)}</td><td>{f(B)}</td></tr>)}</tbody></table>
      <button className="btn block" onClick={() => { controller.isolate([A.modelReference, B.modelReference]); onClose(); }}>◎ בודד את שניהם במודל</button>
    </ModalSheet>
  );
}

/* ───────────── בנה תנועה ───────────── */
function BuilderModal({ onClose }: { onClose: () => void }) {
  const joints = data.joints.filter((j) => j.motions.length);
  const [jointId, setJoint] = useState(joints[0].id);
  const joint = data.joint(jointId)!;
  const [mvId, setMv] = useState(joint.motions[0].movementId);
  const motion = joint.motions.find((m) => m.movementId === mvId) ?? joint.motions[0];
  const [angle, setAngle] = useState(90);
  const clamped = Math.min(motion.typicalRange[1], Math.max(motion.typicalRange[0], angle));
  return (
    <ModalSheet title="🛠 בנה תנועה" onClose={onClose}>
      <div className="section-title" style={{ marginTop: 0 }}>1 · מפרק</div>
      <select className="select" value={jointId} onChange={(e) => { const j = data.joint(e.target.value)!; setJoint(j.id); setMv(j.motions[0].movementId); }}>
        {joints.map((j) => <option key={j.id} value={j.id}>{j.hebrewName}</option>)}
      </select>
      <div className="section-title">2 · תנועה</div>
      <div className="seg" style={{ flexWrap: 'wrap' }}>
        {joint.motions.map((m) => <button key={m.movementId} className={m.movementId === motion.movementId ? 'on' : ''} onClick={() => setMv(m.movementId)}>{m.hebrewLabel}</button>)}
      </div>
      <div className="section-title">3 · זווית: {clamped}° <span className="tag estimate">טווח אופייני {motion.typicalRange[0]}°–{motion.typicalRange[1]}°</span></div>
      <input className="big" type="range" min={motion.typicalRange[0]} max={motion.typicalRange[1]} value={clamped} onChange={(e) => setAngle(Number(e.target.value))} aria-label="זווית" />
      <button className="btn primary block" style={{ marginTop: 8 }} onClick={() => controller.playCustom(jointId, motion.movementId, clamped)}>▶ הצג תנועה ושרירים</button>
      <div className="info-box">המערכת בנויה כך שניתן לצרף כמה תנועות מפרקיות לתנועה מורכבת אחת (composeMotions).</div>
    </ModalSheet>
  );
}
