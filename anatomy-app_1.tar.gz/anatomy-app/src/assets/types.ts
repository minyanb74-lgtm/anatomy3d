/**
 * Asset abstraction (requirement #34).
 *
 * The app never talks to a concrete model. It asks an `AnatomyAssetProvider` for an
 * `AnatomyAsset`, which exposes:
 *   - a rig (named segments the PoseDriver can rotate),
 *   - a flat list of `AnatomyPart`s – each mesh tagged with a data `modelReference`, a layer and a side.
 *
 * Swapping the placeholder for a licensed, detailed anatomical model means writing (or configuring)
 * another provider – see `gltf/GltfAssetProvider.ts` – without touching UI, data or business logic.
 */
import type { Group, Mesh, Object3D, Vector3 } from 'three';
import type { LayerId, StructureKind } from '@/data';

export type Side = 'L' | 'R';

export type SegmentId =
  | 'root' | 'pelvis' | 'torso' | 'head'
  | 'upperArmL' | 'forearmL' | 'handL' | 'upperArmR' | 'forearmR' | 'handR'
  | 'thighL' | 'shankL' | 'footL' | 'thighR' | 'shankR' | 'footR';

export interface ContactPoint {
  segment: SegmentId;
  local: Vector3;
  kind: 'foot' | 'hand';
  side: Side;
}

export interface Rig {
  root: Object3D;
  segments: Record<SegmentId, Object3D>;
  /** Points used for grounding (feet on the floor, hands on a bar). */
  contacts: ContactPoint[];
  /** Rest height of the root above the floor (m). */
  restRootHeight: number;
}

export interface AnatomyPart {
  /** Data model reference, e.g. "muscle.biceps_brachii". */
  ref: string;
  /** 'shell' = skin/fat/fascia envelopes (not data entities). */
  kind: StructureKind | 'shell';
  side?: Side;
  layer: LayerId;
  /** 'tendon' meshes belong to a muscle but live on the tendons layer. */
  subpart?: 'belly' | 'tendon';
  meshes: Mesh[];
  /** Default colour (hex) of this part. */
  baseColor: number;
  baseOpacity: number;
  pickable: boolean;
  /** Name from the model source, used for structures that have no record in the data layer yet. */
  label?: string;
}

/** Unique key of one instance of a structure (e.g. left biceps). */
export const instanceKey = (ref: string, side?: Side) => (side ? `${ref}#${side}` : ref);

export interface AnatomyAsset {
  /** Everything to add to the scene. */
  scene: Group;
  rig: Rig;
  parts: AnatomyPart[];
  /** Called after the rig pose changed – lets deforming geometry follow (muscles, nerves…). */
  updateDeformation(): void;
  /** Human readable licence / provenance line shown in "about". */
  attribution: string;
  /** True for development placeholders (shown as a badge in the UI). */
  isPlaceholder: boolean;
  dispose(): void;
}

export interface AnatomyAssetProvider {
  readonly id: string;
  load(onProgress?: (fraction: number) => void): Promise<AnatomyAsset>;
}
