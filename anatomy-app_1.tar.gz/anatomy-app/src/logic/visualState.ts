/**
 * Business rules that translate AppState → engine VisualState.
 * Colour system (requirement #11): role → colour, involvement → intensity.
 */
import { data, ROLE_META, type LayerId, type Role } from '@/data';
import { instanceKey } from '@/assets';
import type { Tint, VisualState } from '@/engine/visualState';
import type { AppState } from './store';

const hex = (s: string) => parseInt(s.slice(1), 16);
const ROLE_OPACITY: Record<Role, number | undefined> = { agonist: undefined, synergist: undefined, stabilizer: undefined, antagonist: 0.38 };

export function roleTint(role: Role, involvement: number): Tint {
  const strength = role === 'antagonist' ? 0.85 : 0.35 + 0.65 * Math.max(0, Math.min(1, involvement));
  return { color: hex(ROLE_META[role].color), strength, opacity: ROLE_OPACITY[role] };
}

export function selectionKeys(s: AppState): string[] {
  const sel = s.selection;
  if (!sel) return [];
  if (sel.ref) return [sel.side ? instanceKey(sel.ref, sel.side) : sel.ref];
  if (sel.kind === 'unlisted') return [];
  const e = data.get(sel.kind, sel.id) as { modelReference?: string } | undefined;
  return e?.modelReference ? [e.modelReference] : [];
}

export function buildVisualState(s: AppState): VisualState {
  const tints = new Map<string, Tint>();
  if (s.motion) {
    for (const r of s.motion.roles) {
      const m = data.muscle(r.muscleId);
      if (m) tints.set(m.modelReference, roleTint(r.role, r.involvement));
    }
  }
  const forceLayers = new Set<LayerId>(s.highlight?.forceLayers ?? []);
  return {
    layers: s.layers,
    hidden: new Set(s.hidden),
    isolate: s.isolated ? new Set(s.isolated) : null,
    isolateMode: 'ghost',
    selected: new Set(s.quiz ? [] : selectionKeys(s)),
    tints,
    dimUntinted: !!s.motion,
    highlight: new Set(s.highlight?.keys ?? []),
    forceLayers,
  };
}
