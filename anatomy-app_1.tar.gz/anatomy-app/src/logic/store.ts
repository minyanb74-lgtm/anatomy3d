/**
 * Application state – a tiny framework-agnostic store (subscribe / getState / setState).
 * React binds through `useStore(selector)` (src/ui/hooks/useStore.ts); the engine binds through
 * `subscribe`. No business logic lives in UI components.
 */
import { LAYERS, type Clip, type EntityKind, type Id, type LayerId, type RoleEntry } from '@/data';
import type { Side } from '@/assets';
import type { CameraState, SectionState } from '@/engine/visualState';
import type { QuizState } from './quiz';

export type Tab = 'home' | 'anatomy' | 'movements' | 'exercises' | 'learn';
export type SheetSnap = 'closed' | 'peek' | 'half' | 'full';
export type Modal = null | 'search' | 'layers' | 'settings' | 'menu' | 'section' | 'saved' | 'compareExercises' | 'compareMuscles' | 'builder';

/** A structure that exists in the 3D model but has no record in the data layer yet. */
export interface UnlistedStructure {
  ref: string;
  label: string;
  kind: string;
}

export interface Selection {
  kind: EntityKind | 'unlisted';
  id: Id;
  /** Model reference & side of the instance the user tapped (if any). */
  ref?: string;
  side?: Side;
  /** Set when kind = 'unlisted'. */
  unlisted?: UnlistedStructure;
}

export interface ActiveMotion {
  source: 'movement' | 'exercise' | 'custom';
  id: Id;
  title: string;
  clip: Clip;
  roles: RoleEntry[];
}

export interface Playback {
  time: number; // 0..1
  playing: boolean;
  speed: 0.25 | 0.5 | 1 | 1.5;
}

export interface Highlight {
  label: string;
  keys: string[];
  forceLayers?: LayerId[];
}

export interface AppState {
  ready: boolean;
  loadProgress: number;
  tab: Tab;
  sheet: SheetSnap;
  modal: Modal;
  selection: Selection | null;
  hidden: string[];
  layers: Record<LayerId, boolean>;
  isolated: string[] | null;
  motion: ActiveMotion | null;
  playback: Playback;
  highlight: Highlight | null;
  section: SectionState;
  theme: 'dark' | 'light';
  lowPower: boolean;
  quiz: QuizState | null;
  /** Detail panel for an entity that isn't a 3D structure (movement / exercise / joint). */
  detail: { kind: 'movement' | 'exercise' | 'joint' | 'query'; id: Id } | null;
  /** Result of an advanced query (shown in the sheet). */
  query: import('./search').QueryResult | null;
  toast: string | null;
  pendingCamera: CameraState | null;
  isPlaceholderModel: boolean;
  modelAttribution: string;
  /** Layers the loaded model actually contains. */
  availableLayers: LayerId[];
}

export const defaultLayers = (): Record<LayerId, boolean> =>
  Object.fromEntries(LAYERS.map((l) => [l.id, l.defaultVisible])) as Record<LayerId, boolean>;

const prefersLight = () => typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: light)').matches;
const storedTheme = (): 'dark' | 'light' | null => {
  try { return (localStorage.getItem('anatomy.theme') as 'dark' | 'light' | null) ?? null; } catch { return null; }
};

export const initialState = (): AppState => ({
  ready: false,
  loadProgress: 0,
  tab: 'home',
  sheet: 'closed',
  modal: null,
  selection: null,
  hidden: [],
  layers: defaultLayers(),
  isolated: null,
  motion: null,
  playback: { time: 0, playing: false, speed: 1 },
  highlight: null,
  section: { enabled: false, axis: 'sagittal', position: 0 },
  theme: storedTheme() ?? (prefersLight() ? 'light' : 'dark'),
  lowPower: false,
  quiz: null,
  detail: null,
  query: null,
  toast: null,
  pendingCamera: null,
  isPlaceholderModel: true,
  modelAttribution: '',
  availableLayers: [],
});

type Listener = (s: AppState, prev: AppState) => void;

export function createStore(init: AppState) {
  let state = init;
  const listeners = new Set<Listener>();
  return {
    getState: () => state,
    setState(patch: Partial<AppState> | ((s: AppState) => Partial<AppState>)) {
      const prev = state;
      const p = typeof patch === 'function' ? patch(state) : patch;
      state = { ...state, ...p };
      for (const l of listeners) l(state, prev);
    },
    subscribe(l: Listener) {
      listeners.add(l);
      return () => listeners.delete(l);
    },
  };
}

export const store = createStore(initialState());
export type Store = typeof store;
