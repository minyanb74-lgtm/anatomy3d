/**
 * Bp3dAssetProvider – real anatomical geometry from BodyParts3D (DBCLS, CC BY-SA 2.1 Japan).
 *
 * The source meshes are static (not rigged). To keep movement animations working, this provider
 * builds the app's standard rig from joint centres measured on the bones (tools/bp3d/convert.py)
 * and skins every mesh to it automatically:
 *   • bones are attached rigidly to their segment (spine vertebrae blend between pelvis and torso);
 *   • muscles, tendons and vessels get per-vertex weights from their distance to the segments,
 *     so muscles that cross a joint stretch with it.
 * This is a geometric approximation (KnowledgeKind 'model'), not a biomechanical muscle simulation.
 */
import {
  Bone, BufferAttribute, BufferGeometry, Color, Group, Matrix4, MeshStandardMaterial, Skeleton, SkinnedMesh, Vector3, type Mesh,
} from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import type { LayerId, StructureKind } from '@/data';
import type { AnatomyAsset, AnatomyAssetProvider, AnatomyPart, ContactPoint, SegmentId, Side } from '../types';
import manifestJson from './bp3d.manifest.json';

interface ManifestPart {
  node: string;
  ref: string;
  kind: StructureKind;
  layer: LayerId;
  side: Side | null;
  seg: string | null;
  label: string;
}
interface Manifest {
  source: string;
  joints: Record<string, [number, number, number]>;
  parts: ManifestPart[];
}
const manifest = manifestJson as unknown as Manifest;

const MODEL_URL = './models/bp3d.glb';

const COLORS = {
  muscle: 0xa8463d,
  bone: 0xe6dcc3,
  tendon: 0xc9a497,
  fascia: 0xc9d6de,
  ligament: 0xbcc6ad,
  artery: 0xc42f2b,
  vein: 0x3a5bc2,
};

/** Segment capsules used for skin weights: [segment, from-joint, to-joint, radius]. */
type Cap = { seg: SegmentId; a: Vector3; b: Vector3; r: number; side?: Side };

export class Bp3dAssetProvider implements AnatomyAssetProvider {
  readonly id = 'bodyparts3d';
  constructor(private url = MODEL_URL) {}

  async load(onProgress?: (f: number) => void): Promise<AnatomyAsset> {
    const loader = new GLTFLoader();
    loader.setMeshoptDecoder(MeshoptDecoder);
    // A self-contained build (single HTML page) may embed the model as base64 in window.__BP3D_B64.
    const inline = (globalThis as { __BP3D_B64?: string }).__BP3D_B64;
    const gltf = inline
      ? await loader.parseAsync(base64ToBuffer(inline), '')
      : await loader.loadAsync(this.url, (e) => e.total && onProgress?.(0.85 * (e.loaded / e.total)));

    const J = Object.fromEntries(Object.entries(manifest.joints).map(([k, v]) => [k, new Vector3(...v)])) as Record<string, Vector3>;

    /* ───── rig (Bones positioned at measured joint centres) ───── */
    const segments = {} as Record<SegmentId, Bone>;
    const mk = (id: SegmentId, parent: Bone | null, world: Vector3, parentWorld: Vector3 | null) => {
      const b = new Bone();
      b.name = id;
      b.rotation.order = 'XZY';
      b.position.copy(parentWorld ? world.clone().sub(parentWorld) : world);
      parent?.add(b);
      segments[id] = b;
      return b;
    };
    const root = mk('root', null, J.pelvis, null);
    const pelvis = mk('pelvis', root, J.pelvis, J.pelvis);
    const torso = mk('torso', pelvis, J.lumbar, J.pelvis);
    mk('head', torso, J.neck, J.lumbar);
    for (const s of ['L', 'R'] as Side[]) {
      const ua = mk(`upperArm${s}`, torso, J[`shoulder${s}`], J.lumbar);
      const fa = mk(`forearm${s}`, ua, J[`elbow${s}`], J[`shoulder${s}`]);
      mk(`hand${s}`, fa, J[`wrist${s}`], J[`elbow${s}`]);
      const th = mk(`thigh${s}`, pelvis, J[`hip${s}`], J.pelvis);
      const sh = mk(`shank${s}`, th, J[`knee${s}`], J[`hip${s}`]);
      mk(`foot${s}`, sh, J[`ankle${s}`], J[`knee${s}`]);
    }
    root.updateMatrixWorld(true);
    const boneList = Object.values(segments);
    const boneIndex = new Map<SegmentId, number>(boneList.map((b, i) => [b.name as SegmentId, i]));
    const skeleton = new Skeleton(boneList);

    const contacts: ContactPoint[] = [];
    for (const s of ['L', 'R'] as Side[]) {
      contacts.push({ segment: `foot${s}`, local: J[`heel${s}`].clone().sub(J[`ankle${s}`]), kind: 'foot', side: s });
      contacts.push({ segment: `foot${s}`, local: J[`toe${s}`].clone().sub(J[`ankle${s}`]), kind: 'foot', side: s });
      contacts.push({ segment: `hand${s}`, local: J[`handTip${s}`].clone().sub(J[`wrist${s}`]), kind: 'hand', side: s });
    }

    /* ───── capsules for automatic skin weights ───── */
    const caps: Cap[] = [
      { seg: 'pelvis', a: J.pelvis.clone().setY(J.pelvis.y - 0.06), b: J.lumbar, r: 0.12 },
      { seg: 'torso', a: J.lumbar, b: J.neck, r: 0.15 },
      { seg: 'head', a: J.neck, b: J.headTop, r: 0.09 },
    ];
    for (const s of ['L', 'R'] as Side[]) {
      caps.push(
        { seg: `upperArm${s}`, a: J[`shoulder${s}`], b: J[`elbow${s}`], r: 0.045, side: s },
        { seg: `forearm${s}`, a: J[`elbow${s}`], b: J[`wrist${s}`], r: 0.038, side: s },
        { seg: `hand${s}`, a: J[`wrist${s}`], b: J[`handTip${s}`], r: 0.035, side: s },
        { seg: `thigh${s}`, a: J[`hip${s}`], b: J[`knee${s}`], r: 0.075, side: s },
        { seg: `shank${s}`, a: J[`knee${s}`], b: J[`ankle${s}`], r: 0.05, side: s },
        { seg: `foot${s}`, a: J[`ankle${s}`], b: J[`toe${s}`], r: 0.04, side: s },
      );
    }

    /* ───── parts ───── */
    const scene = new Group();
    scene.name = 'anatomy-asset';
    scene.add(root);
    const meshes = new Map<string, Mesh>();
    gltf.scene.traverse((o) => { if ((o as Mesh).isMesh) meshes.set(o.name, o as Mesh); });

    const parts: AnatomyPart[] = [];
    let i = 0;
    for (const mp of manifest.parts) {
      const src = meshes.get(mp.node);
      if (!src) continue;
      src.updateWorldMatrix(true, false);
      const geo = dequantize(src.geometry).applyMatrix4(src.matrixWorld);
      if (!geo.getAttribute('normal')) geo.computeVertexNormals();
      this.skin(geo, mp, caps, boneIndex, J);

      const baseColor = colorFor(mp, i++);
      const mat = new MeshStandardMaterial({ color: baseColor, roughness: mp.kind === 'bone' ? 0.72 : 0.55, metalness: 0.0 });
      const mesh = new SkinnedMesh(geo, mat);
      mesh.name = mp.label;
      mesh.frustumCulled = false; // bounds change with the pose
      mesh.bind(skeleton, new Matrix4());
      mesh.userData.partIndex = parts.length;
      scene.add(mesh);
      parts.push({
        ref: mp.ref, kind: mp.kind, side: mp.side ?? undefined, layer: mp.layer, meshes: [mesh],
        baseColor, baseOpacity: 1, pickable: true, label: mp.label,
        subpart: mp.ref.startsWith('tendon.') ? 'tendon' : undefined,
      });
    }
    onProgress?.(1);

    return {
      scene,
      rig: { root, segments, contacts, restRootHeight: J.pelvis.y },
      parts,
      updateDeformation: () => scene.updateMatrixWorld(true),
      attribution: 'מודל: BodyParts3D, © The Database Center for Life Science (DBCLS), רישיון CC BY-SA 2.1 Japan. המודל עובד והוקטן לשימוש במובייל; התנועה מבוססת על חיבור אוטומטי לשלד ואינה סימולציה ביומכנית.',
      isPlaceholder: false,
      dispose: () => {
        for (const p of parts) for (const m of p.meshes) { m.geometry.dispose(); (m.material as MeshStandardMaterial).dispose(); }
      },
    };
  }

  /** Writes skinIndex / skinWeight attributes (up to 2 influences per vertex). */
  private skin(geo: BufferGeometry, mp: ManifestPart, caps: Cap[], boneIndex: Map<SegmentId, number>, J: Record<string, Vector3>) {
    const pos = geo.getAttribute('position');
    const n = pos.count;
    const idx = new Uint16Array(n * 4);
    const wts = new Float32Array(n * 4);
    const v = new Vector3();
    const sideSeg = (base: string) => (`${base}${mp.side ?? 'L'}`) as SegmentId;

    // Rigid bones (spine blends pelvis ↔ torso around the lumbar joint).
    if (mp.kind === 'bone' && mp.seg) {
      const limb = ['upperArm', 'forearm', 'hand', 'thigh', 'shank', 'foot'].includes(mp.seg);
      if (mp.seg === 'spine') {
        const pi = boneIndex.get('pelvis')!;
        const ti = boneIndex.get('torso')!;
        for (let k = 0; k < n; k++) {
          const y = pos.getY(k);
          const t = Math.min(1, Math.max(0, (y - (J.lumbar.y - 0.03)) / 0.06));
          idx[k * 4] = ti; wts[k * 4] = t;
          idx[k * 4 + 1] = pi; wts[k * 4 + 1] = 1 - t;
        }
      } else {
        const bi = boneIndex.get(limb ? sideSeg(mp.seg) : (mp.seg as SegmentId)) ?? 0;
        for (let k = 0; k < n; k++) { idx[k * 4] = bi; wts[k * 4] = 1; }
      }
    } else {
      const usable = caps.filter((c) => !c.side || !mp.side || c.side === mp.side);
      const score = new Float64Array(usable.length);
      const ab = new Vector3();
      const av = new Vector3();
      for (let k = 0; k < n; k++) {
        v.fromBufferAttribute(pos, k);
        for (let c = 0; c < usable.length; c++) {
          const cap = usable[c];
          ab.subVectors(cap.b, cap.a);
          av.subVectors(v, cap.a);
          const t = Math.max(0, Math.min(1, av.dot(ab) / ab.lengthSq()));
          const d = av.addScaledVector(ab, -t).length();
          const s = Math.max(0, d - cap.r);
          score[c] = 1 / Math.pow(s + 0.01, 3);
        }
        let b1 = 0, b2 = -1;
        for (let c = 1; c < usable.length; c++) {
          if (score[c] > score[b1]) { b2 = b1; b1 = c; } else if (b2 < 0 || score[c] > score[b2]) b2 = c;
        }
        const w1 = score[b1];
        const w2 = b2 >= 0 ? score[b2] : 0;
        const sum = w1 + w2;
        idx[k * 4] = boneIndex.get(usable[b1].seg)!; wts[k * 4] = w1 / sum;
        if (b2 >= 0) { idx[k * 4 + 1] = boneIndex.get(usable[b2].seg)!; wts[k * 4 + 1] = w2 / sum; }
      }
    }
    geo.setAttribute('skinIndex', new BufferAttribute(idx, 4));
    geo.setAttribute('skinWeight', new BufferAttribute(wts, 4));
  }
}

function base64ToBuffer(b64: string): ArrayBuffer {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

/**
 * Meshopt-compressed files store positions/normals as normalized integers with the scale on the node.
 * Skinning bakes the node transform into the vertices, so convert to Float32 first.
 */
function dequantize(src: BufferGeometry): BufferGeometry {
  const geo = new BufferGeometry();
  for (const name of ['position', 'normal'] as const) {
    const a = src.getAttribute(name);
    if (!a) continue;
    const out = new Float32Array(a.count * 3);
    for (let i = 0; i < a.count; i++) {
      out[i * 3] = a.getX(i);
      out[i * 3 + 1] = a.getY(i);
      out[i * 3 + 2] = a.getZ(i);
    }
    geo.setAttribute(name, new BufferAttribute(out, 3));
  }
  if (src.index) geo.setIndex(src.index.clone());
  return geo;
}

/** Base colour with a slight per-structure variation so neighbouring muscles stay distinguishable. */
function colorFor(mp: ManifestPart, i: number): number {
  let base: number;
  if (mp.kind === 'muscle') base = COLORS.muscle;
  else if (mp.kind === 'bone') base = COLORS.bone;
  else if (mp.kind === 'vessel') base = /vein|vena/.test(mp.label) ? COLORS.vein : COLORS.artery;
  // The linea alba sits between the two rectus muscles; a muted flesh tone keeps it from reading as a gap.
  else if (mp.label === 'linea alba') base = 0xb9837a;
  else if (mp.layer === 'tendons') base = COLORS.tendon;
  else if (mp.layer === 'fascia') base = COLORS.fascia;
  else base = COLORS.ligament;
  if (mp.kind !== 'muscle') return base;
  const c = new Color(base);
  const hsl = { h: 0, s: 0, l: 0 };
  c.getHSL(hsl);
  const j = (((i * 2654435761) >>> 0) % 1000) / 1000 - 0.5; // deterministic jitter
  c.setHSL(hsl.h + j * 0.015, hsl.s, Math.min(0.6, Math.max(0.28, hsl.l + j * 0.07)));
  return c.getHex();
}
